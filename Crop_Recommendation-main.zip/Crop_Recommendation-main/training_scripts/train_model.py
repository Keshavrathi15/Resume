"""
🌾 Crop Recommendation Model Training Pipeline
===============================================
Train machine learning models for crop recommendation using soil and climate features.

This module implements:
- Feature engineering (7 → 21 features)
- Multi-model training (CatBoost, XGBoost, RandomForest)
- Priority-based model selection
- Model persistence with metadata

Author: Smart Crop Detection System
Date: 2025
"""

import argparse
import pickle
import sys
import warnings
from pathlib import Path
from typing import Dict, List, Tuple, Any

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from catboost import CatBoostClassifier
from xgboost import XGBClassifier

warnings.filterwarnings('ignore')




def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """
     Engineer additional features from basic soil inputs
    
    Creates 14 new features from 7 original features:
    - NPK ratios (3 features): N_P_ratio, N_K_ratio, P_K_ratio
    - Climate indices (2 features): temp_humidity_index, water_stress_index
    - Fertility scores (3 features): NPK_sum, NPK_balance, soil_fertility_score
    - Stress indicators (2 features): heat_stress, moisture_deficit
    - Polynomial features (4 features): temp_squared, humidity_squared, rainfall_squared, pH_squared
    
    Args:
        df: DataFrame with columns [N, P, K, temperature, humidity, pH, rainfall, label]
        
    Returns:
        DataFrame with original + 14 engineered features (21 total features)
        
    Examples:
        >>> df = pd.DataFrame({'N': [90], 'P': [42], 'K': [43], 
        ...                    'temperature': [20.8], 'humidity': [82], 
        ...                    'pH': [6.5], 'rainfall': [202], 'label': ['rice']})
        >>> engineered = engineer_features(df)
        >>> len(engineered.columns)  # 7 original + 14 engineered + 1 label
        22
    """
    print(" Engineering features...")
    
    df_eng = df.copy()
    
    # Extract base features
    N = df_eng['N']
    P = df_eng['P']
    K = df_eng['K']
    temp = df_eng['temperature']
    humidity = df_eng['humidity']
    pH = df_eng['pH']
    rainfall = df_eng['rainfall']
    
    # 1. NPK Ratios (3 features)
    print("    Creating NPK ratios...")
    df_eng['N_P_ratio'] = N / (P + 1)  # +1 to avoid division by zero
    df_eng['N_K_ratio'] = N / (K + 1)
    df_eng['P_K_ratio'] = P / (K + 1)
    
    # 2. Climate indices (2 features)
    print("     Creating climate indices...")
    df_eng['temp_humidity_index'] = temp * humidity / 100
    df_eng['water_stress_index'] = rainfall / (temp + 1)
    
    # 3. Fertility scores (3 features)
    print("    Creating fertility scores...")
    df_eng['NPK_sum'] = N + P + K
    df_eng['NPK_balance'] = df_eng.apply(
        lambda row: np.std([row['N'], row['P'], row['K']]), axis=1
    )
    df_eng['soil_fertility_score'] = (N * 0.4 + P * 0.3 + K * 0.3) * (pH / 7.0)
    
    # 4. Stress indicators (2 features)
    print("     Creating stress indicators...")
    df_eng['heat_stress'] = np.maximum(0, temp - 35)
    df_eng['moisture_deficit'] = np.maximum(0, 60 - humidity)
    
    # 5. Polynomial features (4 features)
    print("    Creating polynomial features...")
    df_eng['temp_squared'] = temp ** 2
    df_eng['humidity_squared'] = humidity ** 2
    df_eng['rainfall_squared'] = rainfall ** 2
    df_eng['pH_squared'] = pH ** 2
    
    print(f" Feature engineering complete: {len(df.columns)-1} → {len(df_eng.columns)-1} features")
    
    return df_eng



def load_and_prepare_data(dataset_path: str) -> Tuple[pd.DataFrame, pd.Series, List[str]]:
    """
    Load dataset and prepare features and labels
    
    Args:
        dataset_path: Path to CSV file with crop data
        
    Returns:
        Tuple of (features_df, labels_series, feature_names)
        
    Raises:
        FileNotFoundError: If dataset file doesn't exist
        ValueError: If required columns are missing
    """
    print(f" Loading dataset from: {dataset_path}")
    
    # Check if file exists
    if not Path(dataset_path).exists():
        raise FileNotFoundError(f" Dataset not found: {dataset_path}")
    
    # Load data
    df = pd.read_csv(dataset_path)
    print(f"Loaded {len(df)} samples")
    
    # Normalize column names (handle 'ph' vs 'pH')
    df.columns = df.columns.str.lower()
    if 'ph' in df.columns:
        df.rename(columns={'ph': 'pH'}, inplace=True)
    
    # Check required columns
    required_cols = ['n', 'p', 'k', 'temperature', 'humidity', 'pH', 'rainfall']
    label_col = 'label' if 'label' in df.columns else 'crop'
    
    missing_cols = [col for col in required_cols if col not in df.columns]
    if missing_cols:
        raise ValueError(f" Missing required columns: {missing_cols}")
    
    if label_col not in df.columns:
        raise ValueError(" Missing label column (expected 'label' or 'crop')")
    
    # Normalize column names
    df.rename(columns={
        'n': 'N',
        'p': 'P',
        'k': 'K',
        label_col: 'label'
    }, inplace=True)
    
    print(f" Dataset info:")
    print(f"   • Features: {', '.join(required_cols)}")
    print(f"   • Target: {label_col} ({df['label'].nunique()} unique crops)")
    print(f"   • Shape: {df.shape}")
    
    # Engineer features
    df_engineered = engineer_features(df)
    
    # Separate features and labels
    feature_cols = [col for col in df_engineered.columns if col != 'label']
    X = df_engineered[feature_cols]
    y = df_engineered['label']
    
    return X, y, feature_cols




def create_crop_yield_map(y: pd.Series) -> Dict[str, float]:
    """
    🌾 Create a mapping of crops to their typical yield scores
    
    This is a simplified yield estimation based on crop types.
    In production, this should be replaced with actual yield data.
    
    Args:
        y: Series of crop labels
        
    Returns:
        Dictionary mapping crop names to yield scores (0-100)
    """
    print(" Creating crop yield mapping...")
    
    # Get unique crops
    unique_crops = sorted(y.unique())
    
    # Predefined yield scores for common crops (tons/hectare normalized to 0-100)
    # These are approximate values and should be calibrated with real data
    yield_defaults = {
        'rice': 75.0,
        'wheat': 65.0,
        'maize': 80.0,
        'chickpea': 45.0,
        'kidneybeans': 50.0,
        'pigeonpeas': 42.0,
        'mothbeans': 38.0,
        'mungbean': 40.0,
        'blackgram': 43.0,
        'lentil': 47.0,
        'pomegranate': 70.0,
        'banana': 85.0,
        'mango': 72.0,
        'grapes': 68.0,
        'watermelon': 78.0,
        'muskmelon': 75.0,
        'apple': 65.0,
        'orange': 70.0,
        'papaya': 80.0,
        'coconut': 55.0,
        'cotton': 48.0,
        'jute': 52.0,
        'coffee': 60.0
    }
    
    # Create yield map
    crop_yield_map = {}
    for crop in unique_crops:
        crop_lower = crop.lower()
        if crop_lower in yield_defaults:
            crop_yield_map[crop] = yield_defaults[crop_lower]
        else:
            # Default yield for unknown crops
            crop_yield_map[crop] = 50.0
    
    print(f" Created yield mapping for {len(crop_yield_map)} crops")
    
    return crop_yield_map



def train_catboost(X_train: pd.DataFrame, y_train: pd.Series, 
                   X_test: pd.DataFrame, y_test: pd.Series) -> Tuple[Any, float]:
    """
     Train CatBoost classifier with cross-validation
    
    Args:
        X_train: Training features
        y_train: Training labels
        X_test: Test features
        y_test: Test labels
        
    Returns:
        Tuple of (trained_model, test_accuracy_score)
    """
    print("\n🐱 Training CatBoost Classifier...")
    
    model = CatBoostClassifier(
        iterations=500,
        learning_rate=0.1,
        depth=8,
        loss_function='MultiClass',
        random_seed=42,
        verbose=False
    )
    
    # 5-fold cross-validation on training data
    print("   Running 5-fold cross-validation...")
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    cv_scores = cross_val_score(model, X_train, y_train, cv=cv, scoring='accuracy')
    
    print(f"   CV Scores: {' '.join([f'{s*100:.1f}%' for s in cv_scores])}")
    print(f"   CV Mean: {cv_scores.mean()*100:.2f}% (±{cv_scores.std()*100:.2f}%)")
    
    # Train on full training set
    model.fit(X_train, y_train)
    
    # Evaluate on training and test sets
    train_pred = model.predict(X_train)
    train_accuracy = accuracy_score(y_train, train_pred)
    
    y_pred = model.predict(X_test)
    test_accuracy = accuracy_score(y_test, y_pred)
    
    print(f"   ✓ Train Accuracy: {train_accuracy*100:.2f}%")
    print(f"   ✓ Test Accuracy: {test_accuracy*100:.2f}%")
    
    if train_accuracy - test_accuracy > 0.05:
        print(f"   ⚠️ Warning: {(train_accuracy - test_accuracy)*100:.1f}% gap suggests overfitting")
    
    return model, test_accuracy


def train_xgboost(X_train: pd.DataFrame, y_train: pd.Series, 
                  X_test: pd.DataFrame, y_test: pd.Series) -> Tuple[Any, float]:
    """
     Train XGBoost classifier with cross-validation
    
    Args:
        X_train: Training features
        y_train: Training labels
        X_test: Test features
        y_test: Test labels
        
    Returns:
        Tuple of (trained_model, test_accuracy_score)
    """
    print("\n🚀 Training XGBoost Classifier...")
    
    # Encode labels
    from sklearn.preprocessing import LabelEncoder
    le = LabelEncoder()
    y_train_encoded = le.fit_transform(y_train)
    y_test_encoded = le.transform(y_test)
    
    model = XGBClassifier(
        n_estimators=300,
        learning_rate=0.1,
        max_depth=8,
        random_state=42,
        n_jobs=-1,
        eval_metric='mlogloss'
    )
    
    # 5-fold cross-validation on training data
    print("   Running 5-fold cross-validation...")
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    cv_scores = cross_val_score(model, X_train, y_train_encoded, cv=cv, scoring='accuracy')
    
    print(f"   CV Scores: {' '.join([f'{s*100:.1f}%' for s in cv_scores])}")
    print(f"   CV Mean: {cv_scores.mean()*100:.2f}% (±{cv_scores.std()*100:.2f}%)")
    
    # Train on full training set
    model.fit(X_train, y_train_encoded)
    
    # Evaluate on training and test sets
    train_pred = model.predict(X_train)
    train_accuracy = accuracy_score(y_train_encoded, train_pred)
    
    y_pred = model.predict(X_test)
    test_accuracy = accuracy_score(y_test_encoded, y_pred)
    
    print(f"   ✓ Train Accuracy: {train_accuracy*100:.2f}%")
    print(f"   ✓ Test Accuracy: {test_accuracy*100:.2f}%")
    
    if train_accuracy - test_accuracy > 0.05:
        print(f"   ⚠️ Warning: {(train_accuracy - test_accuracy)*100:.1f}% gap suggests overfitting")
    
    # Store label encoder in model for later use
    model.label_encoder = le
    model.classes_ = le.classes_
    
    # Override predict and predict_proba to handle string labels
    original_predict = model.predict
    original_predict_proba = model.predict_proba
    
    model.predict = lambda X: le.inverse_transform(original_predict(X))
    model._predict_proba = original_predict_proba
    model.predict_proba = original_predict_proba
    
    return model, test_accuracy


def train_random_forest(X_train: pd.DataFrame, y_train: pd.Series, 
                       X_test: pd.DataFrame, y_test: pd.Series) -> Tuple[Any, float]:
    """
   Train Random Forest classifier with cross-validation
    
    Args:
        X_train: Training features
        y_train: Training labels
        X_test: Test features
        y_test: Test labels
        
    Returns:
        Tuple of (trained_model, test_accuracy_score)
    """
    print("\n🌲 Training Random Forest Classifier...")
    
    model = RandomForestClassifier(
        n_estimators=300,
        max_depth=15,
        min_samples_split=5,
        min_samples_leaf=2,
        random_state=42,
        n_jobs=-1
    )
    
    # 5-fold cross-validation on training data
    print("   Running 5-fold cross-validation...")
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    cv_scores = cross_val_score(model, X_train, y_train, cv=cv, scoring='accuracy')
    
    print(f"   CV Scores: {' '.join([f'{s*100:.1f}%' for s in cv_scores])}")
    print(f"   CV Mean: {cv_scores.mean()*100:.2f}% (±{cv_scores.std()*100:.2f}%)")
    
    # Train on full training set
    model.fit(X_train, y_train)
    
    # Evaluate on training and test sets
    train_pred = model.predict(X_train)
    train_accuracy = accuracy_score(y_train, train_pred)
    
    y_pred = model.predict(X_test)
    test_accuracy = accuracy_score(y_test, y_pred)
    
    print(f"   ✓ Train Accuracy: {train_accuracy*100:.2f}%")
    print(f"   ✓ Test Accuracy: {test_accuracy*100:.2f}%")
    
    if train_accuracy - test_accuracy > 0.05:
        print(f"   ⚠️ Warning: {(train_accuracy - test_accuracy)*100:.1f}% gap suggests overfitting")
    
    return model, test_accuracy



def select_best_model(models: Dict[str, Tuple[Any, float]], 
                     priority_threshold: float = 0.005) -> Tuple[str, Any, float]:
    """
   Select best model based on accuracy with priority rules
    
    Priority: CatBoost > XGBoost > RandomForest
    If accuracies are within threshold (0.5%), use priority order
    
    Args:
        models: Dictionary mapping model_name to (model, accuracy)
        priority_threshold: Threshold for considering accuracies as equal
        
    Returns:
        Tuple of (best_model_name, best_model, best_accuracy)
    """
    print("\n Selecting best model...")
    print(f"   Priority order: CatBoost > XGBoost > Random Forest")
    print(f"   Accuracy threshold: {priority_threshold*100:.2f}%\n")
    
    # Sort by accuracy (descending)
    sorted_models = sorted(models.items(), key=lambda x: x[1][1], reverse=True)
    
    # Get highest accuracy
    best_accuracy = sorted_models[0][1][1]
    
    # Priority order
    priority_order = ['CatBoost', 'XGBoost', 'RandomForest']
    
    # Find models within threshold of best accuracy
    candidates = []
    for name, (model, acc) in sorted_models:
        if best_accuracy - acc <= priority_threshold:
            candidates.append(name)
            print(f"  {name}: {acc*100:.2f}% (within threshold)")
    
    # Select based on priority
    for priority_model in priority_order:
        if priority_model in candidates:
            selected_model = priority_model
            break
    else:
        # Fallback to highest accuracy
        selected_model = sorted_models[0][0]
    
    model_obj, accuracy = models[selected_model]
    
    print(f"\n   Selected: {selected_model} ({accuracy*100:.2f}% accuracy)")
    
    return selected_model, model_obj, accuracy


def print_feature_importance(model: Any, model_name: str, 
                            feature_names: List[str], top_n: int = 10):
    """
     Print feature importance from trained model
    
    Args:
        model: Trained model
        model_name: Name of the model
        feature_names: List of feature names
        top_n: Number of top features to display
    """
    print(f"\n Top {top_n} Feature Importances ({model_name}):")
    print("=" * 60)
    
    try:
        if model_name == 'CatBoost':
            importances = model.feature_importances_
        elif model_name == 'XGBoost':
            importances = model.feature_importances_
        elif model_name == 'RandomForest':
            importances = model.feature_importances_
        else:
            print("   Feature importance not available for this model")
            return
        
        # Create feature importance dataframe
        feature_importance_df = pd.DataFrame({
            'feature': feature_names,
            'importance': importances
        }).sort_values('importance', ascending=False)
        
        # Print top N features
        for idx, row in feature_importance_df.head(top_n).iterrows():
            bar_length = int(row['importance'] * 50)
            bar = '█' * bar_length
            print(f"   {row['feature']:25s} {'│'} {bar} {row['importance']:.4f}")
        
    except Exception as e:
        print(f"   Could not extract feature importance: {str(e)}")




def save_model(model: Any, model_name: str, accuracy: float, 
               feature_names: List[str], crop_yield_map: Dict[str, float],
               output_path: str):
    """
     Save trained model with metadata to pickle file
    
    Args:
        model: Trained model object
        model_name: Name of the model
        accuracy: Model accuracy on test set
        feature_names: List of feature names
        crop_yield_map: Dictionary mapping crops to yield scores
        output_path: Path to save the pickle file
    """
    print(f"\n Saving model to: {output_path}")
    
    model_data = {
        'model': model,
        'model_name': model_name,
        'accuracy': accuracy,
        'feature_names': feature_names,
        'crop_yield_map': crop_yield_map,
        'n_features': len(feature_names),
        'training_date': pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    
    try:
        with open(output_path, 'wb') as f:
            pickle.dump(model_data, f, protocol=pickle.HIGHEST_PROTOCOL)
        
        print(f" Model saved successfully!")
        print(f"   • Model: {model_name}")
        print(f"   • Accuracy: {accuracy*100:.2f}%")
        print(f"   • Features: {len(feature_names)}")
        print(f"   • Crops: {len(crop_yield_map)}")
        print(f"   • File size: {Path(output_path).stat().st_size / 1024:.2f} KB")
        
    except Exception as e:
        print(f" Error saving model: {str(e)}")
        raise



def main():
    """
     Main training pipeline
    """
    # Parse command line arguments
    parser = argparse.ArgumentParser(
        description='🌾 Train crop recommendation models with feature engineering',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Train with default dataset
  python train_model.py
  
  # Train with custom dataset
  python train_model.py --dataset ../data/my_crops.csv
  
  # Train and save to custom location
  python train_model.py --dataset data.csv --output models/crop_model.pkl
  
Features:
  • Trains 3 models: CatBoost, XGBoost, Random Forest
  • Creates 14 engineered features from 7 base features
  • Priority-based model selection (CatBoost > XGBoost > RF)
  • Saves best model with metadata and crop yield mapping
        """
    )
    
    parser.add_argument(
        '--dataset',
        type=str,
        default='../smartcrop_cleaned.csv',
        help='Path to training dataset CSV file (default: ../smartcrop_cleaned.csv)'
    )
    
    parser.add_argument(
        '--output',
        type=str,
        default='crop_model.pkl',
        help='Output path for trained model (default: crop_model.pkl)'
    )
    
    parser.add_argument(
        '--test-size',
        type=float,
        default=0.2,
        help='Test set size as fraction (default: 0.2)'
    )
    
    parser.add_argument(
        '--random-state',
        type=int,
        default=42,
        help='Random state for reproducibility (default: 42)'
    )
    
    args = parser.parse_args()
    
    # Print header
    print("=" * 70)
    print("🌾 CROP RECOMMENDATION MODEL TRAINING PIPELINE")
    print("=" * 70)
    print()
    
    try:
        # Step 1: Load and prepare data
        X, y, feature_names = load_and_prepare_data(args.dataset)
        
        # Step 2: Split data
        print(f"\n  Splitting data (train: {1-args.test_size:.0%}, test: {args.test_size:.0%})...")
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, 
            test_size=args.test_size, 
            random_state=args.random_state,
            stratify=y
        )
        print(f"   • Training samples: {len(X_train)}")
        print(f"   • Test samples: {len(X_test)}")
        
        # Step 3: Create crop yield map
        crop_yield_map = create_crop_yield_map(y)
        
        # Step 4: Train models
        print("\n" + "=" * 70)
        print(" TRAINING MODELS")
        print("=" * 70)
        
        models = {}
        
        # Train CatBoost
        try:
            cb_model, cb_accuracy = train_catboost(X_train, y_train, X_test, y_test)
            models['CatBoost'] = (cb_model, cb_accuracy)
        except Exception as e:
            print(f"     CatBoost training failed: {str(e)}")
        
        # Train XGBoost
        try:
            xgb_model, xgb_accuracy = train_xgboost(X_train, y_train, X_test, y_test)
            models['XGBoost'] = (xgb_model, xgb_accuracy)
        except Exception as e:
            print(f"     XGBoost training failed: {str(e)}")
        
        # Train Random Forest
        try:
            rf_model, rf_accuracy = train_random_forest(X_train, y_train, X_test, y_test)
            models['RandomForest'] = (rf_model, rf_accuracy)
        except Exception as e:
            print(f"    Random Forest training failed: {str(e)}")
        
        if not models:
            raise RuntimeError(" All model training attempts failed!")
        
        # Step 5: Select best model
        print("\n" + "=" * 70)
        print(" MODEL SELECTION")
        print("=" * 70)
        
        best_model_name, best_model, best_accuracy = select_best_model(models)
        
        # Step 6: Print feature importance
        print_feature_importance(best_model, best_model_name, feature_names)
        
        # Step 7: Save model
        print("\n" + "=" * 70)
        print(" SAVING MODEL")
        print("=" * 70)
        
        save_model(
            best_model, 
            best_model_name, 
            best_accuracy, 
            feature_names,
            crop_yield_map,
            args.output
        )
        
        # Print final summary
        print("\n" + "=" * 70)
        print(" TRAINING COMPLETE")
        print("=" * 70)
        print(f"    Best Model: {best_model_name}")
        print(f"    Accuracy: {best_accuracy*100:.2f}%")
        print(f"    Saved to: {args.output}")
        print(f"    Crops: {len(crop_yield_map)}")
        print(f"    Features: {len(feature_names)}")
        print()
        print(" You can now use the model with:")
        print(f"   python recommender.py")
        print("=" * 70)
        
    except Exception as e:
        print(f"\n ERROR: {str(e)}")
        sys.exit(1)


if __name__ == '__main__':
    main()
