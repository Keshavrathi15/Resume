"""
Fast Model Training Script
Optimized for speed with basic validation
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import pickle
from datetime import datetime
import json
import warnings
warnings.filterwarnings('ignore')

def engineer_features(df):
    """Fast feature engineering"""
    print("🔧 Engineering features...")
    
    # Basic engineered features only (most important ones)
    df['NPK_sum'] = df['n'] + df['p'] + df['k']
    df['N_P_ratio'] = df['n'] / (df['p'] + 1)
    df['soil_fertility_score'] = (df['n'] + df['p'] + df['k']) / 3
    
    # Rename to match model expectations
    df = df.rename(columns={
        'n': 'N', 'p': 'P', 'k': 'K', 'ph': 'pH'
    })
    
    return df

def calculate_optimal_ranges(df):
    """Calculate optimal ranges for each crop and feature"""
    print("📊 Calculating optimal ranges...")
    
    ranges = {}
    features = ['N', 'P', 'K', 'temperature', 'humidity', 'pH', 'rainfall']
    
    for crop in df['crop'].unique():
        crop_data = df[df['crop'] == crop]
        ranges[crop] = {}
        
        for feature in features:
            if feature in crop_data.columns:
                q25 = crop_data[feature].quantile(0.25)
                q75 = crop_data[feature].quantile(0.75)
                ranges[crop][feature] = {
                    'min': float(q25),
                    'max': float(q75),
                    'mean': float(crop_data[feature].mean())
                }
    
    return ranges

def main():
    print("=" * 60)
    print("🚀 FAST MODEL TRAINING")
    print("=" * 60)
    
    # Load dataset
    print("📁 Loading dataset...")
    df = pd.read_csv('../smartcrop_cleaned.csv')
    print(f"Dataset size: {len(df)} samples, {len(df.columns)} features")
    
    # Feature engineering
    df = engineer_features(df)
    
    # Calculate optimal ranges
    optimal_ranges = calculate_optimal_ranges(df)
    
    # Save optimal ranges
    with open('crop_optimal_ranges.json', 'w') as f:
        json.dump(optimal_ranges, f, indent=2)
    print("💾 Saved crop optimal ranges")
    
    # Prepare features
    feature_columns = ['N', 'P', 'K', 'temperature', 'humidity', 'pH', 'rainfall', 
                      'NPK_sum', 'N_P_ratio', 'soil_fertility_score']
    
    X = df[feature_columns]
    y = df['crop']
    
    print(f"Features: {len(feature_columns)}")
    print(f"Crops: {len(y.unique())}")
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print(f"Training samples: {len(X_train)}")
    print(f"Test samples: {len(X_test)}")
    
    # Train Random Forest (faster than CatBoost)
    print("\n🌳 Training Random Forest...")
    
    model = RandomForestClassifier(
        n_estimators=50,  # Reduced from default 100
        max_depth=10,     # Limit depth for speed
        random_state=42,
        n_jobs=-1         # Use all cores
    )
    
    model.fit(X_train, y_train)
    
    # Evaluate
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"\n📊 Results:")
    print(f"Test Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    
    # Create crop yield map
    crop_yield_map = {
        'rice': 42.8, 'wheat': 35.0, 'maize': 55.0, 'cotton': 15.0,
        'jute': 29.7, 'coffee': 34.3, 'tea': 25.0, 'sugarcane': 700.0,
        'chickpea': 18.0, 'kidneybeans': 25.0, 'pigeonpeas': 12.0,
        'mothbeans': 8.0, 'mungbean': 10.0, 'blackgram': 9.0,
        'lentil': 13.0, 'pomegranate': 120.0, 'banana': 400.0,
        'mango': 150.0, 'grapes': 180.0, 'watermelon': 250.0,
        'muskmelon': 200.0, 'apple': 300.0, 'orange': 250.0,
        'papaya': 450.0, 'coconut': 150.0
    }
    
    # Save model
    model_data = {
        'model': model,
        'model_name': 'Random Forest (Fast)',
        'accuracy': accuracy,
        'feature_names': feature_columns,
        'crop_yield_map': crop_yield_map,
        'n_features': len(feature_columns),
        'training_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    
    with open('crop_model.pkl', 'wb') as f:
        pickle.dump(model_data, f)
    
    print(f"💾 Model saved successfully!")
    print(f"📅 Training completed at {model_data['training_date']}")
    
    # Show feature importance
    print(f"\n🔍 Top 5 Feature Importances:")
    feature_importance = zip(feature_columns, model.feature_importances_)
    sorted_features = sorted(feature_importance, key=lambda x: x[1], reverse=True)
    
    for feature, importance in sorted_features[:5]:
        print(f"  {feature}: {importance:.4f}")

if __name__ == "__main__":
    main()