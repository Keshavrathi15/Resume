"""
ML-Based Crop Yield Prediction Model Training

This script trains regression models to predict crop yields based on:
- Soil nutrients (N, P, K)
- Climate conditions (temperature, humidity, rainfall)
- Soil pH
- Crop type

Dataset: Crop Yield Prediction Dataset (Kaggle-style synthetic + real patterns)
"""

import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from xgboost import XGBRegressor
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

print("🌾 CROP YIELD PREDICTION MODEL TRAINING")
print("="*70)

# ============================================================================
# STEP 1: CREATE COMPREHENSIVE YIELD DATASET
# ============================================================================
print("\n📊 Creating comprehensive crop yield dataset...")

# Base yield data with realistic ranges (quintals per hectare)
# Based on FAO agricultural statistics and Indian crop yields
crop_yield_ranges = {
    'rice': {'min': 35, 'max': 75, 'optimal': 55, 'variance': 8},
    'wheat': {'min': 25, 'max': 55, 'optimal': 40, 'variance': 6},
    'maize': {'min': 35, 'max': 70, 'optimal': 50, 'variance': 7},
    'cotton': {'min': 15, 'max': 45, 'optimal': 30, 'variance': 5},
    'jute': {'min': 20, 'max': 40, 'optimal': 28, 'variance': 4},
    'coconut': {'min': 40, 'max': 90, 'optimal': 65, 'variance': 10},
    'papaya': {'min': 100, 'max': 250, 'optimal': 175, 'variance': 25},
    'orange': {'min': 80, 'max': 180, 'optimal': 130, 'variance': 20},
    'apple': {'min': 60, 'max': 150, 'optimal': 100, 'variance': 15},
    'muskmelon': {'min': 120, 'max': 250, 'optimal': 180, 'variance': 20},
    'watermelon': {'min': 150, 'max': 350, 'optimal': 250, 'variance': 35},
    'grapes': {'min': 80, 'max': 200, 'optimal': 140, 'variance': 18},
    'mango': {'min': 50, 'max': 120, 'optimal': 80, 'variance': 12},
    'banana': {'min': 200, 'max': 500, 'optimal': 350, 'variance': 50},
    'pomegranate': {'min': 70, 'max': 150, 'optimal': 110, 'variance': 15},
    'lentil': {'min': 8, 'max': 18, 'optimal': 12, 'variance': 2},
    'blackgram': {'min': 6, 'max': 14, 'optimal': 9, 'variance': 1.5},
    'mungbean': {'min': 5, 'max': 12, 'optimal': 8, 'variance': 1.5},
    'mothbeans': {'min': 4, 'max': 10, 'optimal': 6, 'variance': 1.2},
    'pigeonpeas': {'min': 10, 'max': 25, 'optimal': 17, 'variance': 3},
    'kidneybeans': {'min': 12, 'max': 28, 'optimal': 20, 'variance': 3},
    'chickpea': {'min': 15, 'max': 30, 'optimal': 22, 'variance': 3},
    'coffee': {'min': 8, 'max': 18, 'optimal': 12, 'variance': 2}
}

# Optimal growing conditions for each crop
crop_optimal_conditions = {
    'rice': {'N': 90, 'P': 42, 'K': 43, 'temp': 25, 'humidity': 80, 'pH': 6.5, 'rainfall': 200},
    'wheat': {'N': 50, 'P': 30, 'K': 40, 'temp': 18, 'humidity': 65, 'pH': 6.8, 'rainfall': 80},
    'maize': {'N': 80, 'P': 40, 'K': 20, 'temp': 22, 'humidity': 65, 'pH': 6.2, 'rainfall': 90},
    'cotton': {'N': 120, 'P': 70, 'K': 80, 'temp': 27, 'humidity': 70, 'pH': 7.0, 'rainfall': 70},
    'jute': {'N': 78, 'P': 45, 'K': 50, 'temp': 26, 'humidity': 85, 'pH': 6.5, 'rainfall': 180},
    'coconut': {'N': 20, 'P': 10, 'K': 30, 'temp': 28, 'humidity': 80, 'pH': 6.0, 'rainfall': 150},
    'papaya': {'N': 50, 'P': 60, 'K': 50, 'temp': 28, 'humidity': 70, 'pH': 6.5, 'rainfall': 120},
    'orange': {'N': 20, 'P': 10, 'K': 10, 'temp': 25, 'humidity': 75, 'pH': 6.5, 'rainfall': 100},
    'apple': {'N': 20, 'P': 125, 'K': 200, 'temp': 22, 'humidity': 60, 'pH': 6.0, 'rainfall': 110},
    'muskmelon': {'N': 100, 'P': 10, 'K': 50, 'temp': 28, 'humidity': 65, 'pH': 6.5, 'rainfall': 30},
    'watermelon': {'N': 100, 'P': 10, 'K': 50, 'temp': 27, 'humidity': 70, 'pH': 6.5, 'rainfall': 40},
    'grapes': {'N': 22, 'P': 130, 'K': 200, 'temp': 24, 'humidity': 65, 'pH': 6.5, 'rainfall': 90},
    'mango': {'N': 20, 'P': 20, 'K': 30, 'temp': 30, 'humidity': 65, 'pH': 6.5, 'rainfall': 95},
    'banana': {'N': 100, 'P': 75, 'K': 50, 'temp': 28, 'humidity': 80, 'pH': 6.5, 'rainfall': 120},
    'pomegranate': {'N': 20, 'P': 10, 'K': 40, 'temp': 25, 'humidity': 60, 'pH': 6.5, 'rainfall': 50},
    'lentil': {'N': 20, 'P': 60, 'K': 80, 'temp': 24, 'humidity': 65, 'pH': 6.8, 'rainfall': 60},
    'blackgram': {'N': 40, 'P': 60, 'K': 20, 'temp': 28, 'humidity': 70, 'pH': 7.0, 'rainfall': 65},
    'mungbean': {'N': 20, 'P': 40, 'K': 20, 'temp': 29, 'humidity': 75, 'pH': 6.8, 'rainfall': 70},
    'mothbeans': {'N': 20, 'P': 40, 'K': 20, 'temp': 28, 'humidity': 65, 'pH': 7.2, 'rainfall': 50},
    'pigeonpeas': {'N': 20, 'P': 60, 'K': 20, 'temp': 27, 'humidity': 65, 'pH': 6.5, 'rainfall': 80},
    'kidneybeans': {'N': 20, 'P': 60, 'K': 20, 'temp': 22, 'humidity': 70, 'pH': 6.5, 'rainfall': 75},
    'chickpea': {'N': 40, 'P': 60, 'K': 80, 'temp': 23, 'humidity': 65, 'pH': 6.8, 'rainfall': 70},
    'coffee': {'N': 100, 'P': 20, 'K': 30, 'temp': 24, 'humidity': 75, 'pH': 6.5, 'rainfall': 150}
}

def calculate_yield(crop, N, P, K, temp, humidity, pH, rainfall):
    """
    Calculate realistic yield based on how close conditions are to optimal
    """
    if crop not in crop_yield_ranges:
        return 50.0  # Default yield
    
    yield_info = crop_yield_ranges[crop]
    optimal_conditions = crop_optimal_conditions[crop]
    
    # Start with optimal yield
    base_yield = yield_info['optimal']
    
    # Calculate deviation from optimal conditions (normalized 0-1)
    deviations = []
    
    # Nutrient deviations (more critical)
    n_dev = abs(N - optimal_conditions['N']) / optimal_conditions['N']
    p_dev = abs(P - optimal_conditions['P']) / (optimal_conditions['P'] + 1)
    k_dev = abs(K - optimal_conditions['K']) / (optimal_conditions['K'] + 1)
    deviations.extend([n_dev * 1.2, p_dev * 1.2, k_dev * 1.2])  # Nutrients weighted higher
    
    # Climate deviations
    temp_dev = abs(temp - optimal_conditions['temp']) / 10  # Temperature sensitivity
    humidity_dev = abs(humidity - optimal_conditions['humidity']) / 30
    rainfall_dev = abs(rainfall - optimal_conditions['rainfall']) / optimal_conditions['rainfall']
    deviations.extend([temp_dev, humidity_dev, rainfall_dev])
    
    # pH deviation
    ph_dev = abs(pH - optimal_conditions['pH']) / 2
    deviations.append(ph_dev)
    
    # Average deviation (0 = perfect, 1+ = very bad)
    avg_deviation = np.mean(deviations)
    
    # Yield reduction based on deviation (exponential decay)
    # Perfect conditions = 100% yield
    # 0.5 deviation = ~85% yield
    # 1.0 deviation = ~60% yield
    # 2.0 deviation = ~30% yield
    yield_factor = np.exp(-0.5 * avg_deviation)
    
    # Calculate final yield
    calculated_yield = base_yield * yield_factor
    
    # Add some random variance to make it realistic
    variance = yield_info['variance']
    noise = np.random.normal(0, variance * 0.3)
    final_yield = calculated_yield + noise
    
    # Ensure within min/max bounds
    final_yield = np.clip(final_yield, yield_info['min'], yield_info['max'])
    
    return round(final_yield, 2)

# Generate synthetic dataset with realistic patterns
print("Generating synthetic yield dataset with real agricultural patterns...")

n_samples_per_crop = 500  # 500 samples per crop
data = []

for crop in crop_yield_ranges.keys():
    optimal = crop_optimal_conditions[crop]
    
    for _ in range(n_samples_per_crop):
        # Generate conditions with varying distances from optimal
        # Mix of good (70%), medium (20%), and poor (10%) conditions
        condition_quality = np.random.choice(['good', 'medium', 'poor'], p=[0.7, 0.2, 0.1])
        
        if condition_quality == 'good':
            # Near optimal conditions (±20%)
            N = optimal['N'] * np.random.uniform(0.8, 1.2)
            P = optimal['P'] * np.random.uniform(0.8, 1.2)
            K = optimal['K'] * np.random.uniform(0.8, 1.2)
            temp = optimal['temp'] + np.random.uniform(-3, 3)
            humidity = optimal['humidity'] + np.random.uniform(-10, 10)
            pH = optimal['pH'] + np.random.uniform(-0.5, 0.5)
            rainfall = optimal['rainfall'] * np.random.uniform(0.8, 1.2)
        elif condition_quality == 'medium':
            # Medium conditions (±40%)
            N = optimal['N'] * np.random.uniform(0.6, 1.4)
            P = optimal['P'] * np.random.uniform(0.6, 1.4)
            K = optimal['K'] * np.random.uniform(0.6, 1.4)
            temp = optimal['temp'] + np.random.uniform(-6, 6)
            humidity = optimal['humidity'] + np.random.uniform(-20, 20)
            pH = optimal['pH'] + np.random.uniform(-1, 1)
            rainfall = optimal['rainfall'] * np.random.uniform(0.6, 1.4)
        else:
            # Poor conditions (±60%)
            N = optimal['N'] * np.random.uniform(0.4, 1.6)
            P = optimal['P'] * np.random.uniform(0.4, 1.6)
            K = optimal['K'] * np.random.uniform(0.4, 1.6)
            temp = optimal['temp'] + np.random.uniform(-10, 10)
            humidity = optimal['humidity'] + np.random.uniform(-30, 30)
            pH = optimal['pH'] + np.random.uniform(-1.5, 1.5)
            rainfall = optimal['rainfall'] * np.random.uniform(0.4, 1.6)
        
        # Ensure realistic bounds
        N = np.clip(N, 0, 150)
        P = np.clip(P, 5, 150)
        K = np.clip(K, 5, 210)
        temp = np.clip(temp, 8, 45)
        humidity = np.clip(humidity, 14, 100)
        pH = np.clip(pH, 3.5, 10)
        rainfall = np.clip(rainfall, 20, 300)
        
        # Calculate realistic yield
        yield_value = calculate_yield(crop, N, P, K, temp, humidity, pH, rainfall)
        
        data.append({
            'crop': crop,
            'N': round(N, 2),
            'P': round(P, 2),
            'K': round(K, 2),
            'temperature': round(temp, 2),
            'humidity': round(humidity, 2),
            'pH': round(pH, 2),
            'rainfall': round(rainfall, 2),
            'yield': yield_value
        })

# Create DataFrame
df = pd.DataFrame(data)

print(f"✅ Dataset created: {len(df):,} samples")
print(f"   • Crops: {df['crop'].nunique()}")
print(f"   • Samples per crop: ~{len(df) // df['crop'].nunique()}")
print(f"   • Yield range: {df['yield'].min():.2f} - {df['yield'].max():.2f} q/ha")
print(f"   • Mean yield: {df['yield'].mean():.2f} q/ha")

# Save dataset
df.to_csv('crop_yield_dataset.csv', index=False)
print("✅ Dataset saved: crop_yield_dataset.csv")

# Display sample statistics
print("\n📊 Yield Statistics by Crop:")
print("="*70)
yield_stats = df.groupby('crop')['yield'].agg(['mean', 'std', 'min', 'max'])
print(yield_stats.round(2))

# ============================================================================
# STEP 2: FEATURE ENGINEERING
# ============================================================================
print("\n🔧 Creating engineered features...")

def engineer_features(df):
    """Create advanced features for yield prediction"""
    df = df.copy()
    
    # NPK ratios
    df['NPK_sum'] = df['N'] + df['P'] + df['K']
    df['N_P_ratio'] = df['N'] / (df['P'] + 1e-6)
    df['N_K_ratio'] = df['N'] / (df['K'] + 1e-6)
    df['P_K_ratio'] = df['P'] / (df['K'] + 1e-6)
    
    # Climate indices
    df['temp_humidity_index'] = df['temperature'] * df['humidity'] / 100
    df['water_availability'] = df['rainfall'] / (df['temperature'] + 1)
    
    # Soil fertility
    df['soil_fertility_score'] = (df['N'] + df['P'] + df['K']) / 3
    df['nutrient_balance'] = df[['N', 'P', 'K']].std(axis=1)
    
    # Stress indicators
    df['heat_stress'] = (df['temperature'] > 35).astype(int)
    df['moisture_deficit'] = (df['humidity'] < 40).astype(int)
    df['pH_stress'] = ((df['pH'] < 5.5) | (df['pH'] > 8.0)).astype(int)
    
    # Interaction features
    df['nutrient_climate_interaction'] = df['soil_fertility_score'] * df['temp_humidity_index'] / 100
    df['water_stress_index'] = df['rainfall'] * df['humidity'] / 100
    
    return df

df_engineered = engineer_features(df)
print(f"✅ Engineered features added")
print(f"   • Total features: {len(df_engineered.columns) - 2} (original + engineered)")

# ============================================================================
# STEP 3: PREPARE DATA FOR TRAINING
# ============================================================================
print("\n📋 Preparing data for model training...")

# Encode crop names
label_encoder = LabelEncoder()
df_engineered['crop_encoded'] = label_encoder.fit_transform(df_engineered['crop'])

# Features for training (include crop as a feature)
feature_cols = [col for col in df_engineered.columns if col not in ['crop', 'yield']]
X = df_engineered[feature_cols]
y = df_engineered['yield']

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=df_engineered['crop']
)

print(f"✅ Data split complete")
print(f"   • Training samples: {len(X_train):,}")
print(f"   • Testing samples: {len(X_test):,}")
print(f"   • Features: {X_train.shape[1]}")

# ============================================================================
# STEP 4: TRAIN MULTIPLE REGRESSION MODELS
# ============================================================================
print("\n🤖 Training regression models...")
print("="*70)

models = {
    'Random Forest': RandomForestRegressor(
        n_estimators=200, max_depth=20, min_samples_split=5,
        min_samples_leaf=2, random_state=42, n_jobs=-1
    ),
    'XGBoost': XGBRegressor(
        n_estimators=200, max_depth=15, learning_rate=0.1,
        random_state=42, n_jobs=-1
    ),
    'Gradient Boosting': GradientBoostingRegressor(
        n_estimators=200, max_depth=12, learning_rate=0.1,
        random_state=42
    )
}

results = []
trained_models = {}

for name, model in models.items():
    print(f"\n[{list(models.keys()).index(name)+1}/{len(models)}] Training {name}...")
    
    # Train
    model.fit(X_train, y_train)
    
    # Predictions
    y_train_pred = model.predict(X_train)
    y_test_pred = model.predict(X_test)
    
    # Metrics
    train_r2 = r2_score(y_train, y_train_pred)
    test_r2 = r2_score(y_test, y_test_pred)
    train_rmse = np.sqrt(mean_squared_error(y_train, y_train_pred))
    test_rmse = np.sqrt(mean_squared_error(y_test, y_test_pred))
    train_mae = mean_absolute_error(y_train, y_train_pred)
    test_mae = mean_absolute_error(y_test, y_test_pred)
    
    # Cross-validation
    cv_scores = cross_val_score(model, X_train, y_train, cv=5, scoring='r2')
    cv_mean = cv_scores.mean()
    cv_std = cv_scores.std()
    
    results.append({
        'Model': name,
        'Train R²': train_r2,
        'Test R²': test_r2,
        'CV R² Mean': cv_mean,
        'CV R² Std': cv_std,
        'Train RMSE': train_rmse,
        'Test RMSE': test_rmse,
        'Train MAE': train_mae,
        'Test MAE': test_mae
    })
    
    trained_models[name] = model
    
    print(f"   ✓ Test R²: {test_r2:.4f}")
    print(f"   ✓ Test RMSE: {test_rmse:.2f} q/ha")
    print(f"   ✓ Test MAE: {test_mae:.2f} q/ha")
    print(f"   ✓ CV R²: {cv_mean:.4f} ± {cv_std:.4f}")

# ============================================================================
# STEP 5: SELECT BEST MODEL AND ANALYZE
# ============================================================================
print("\n" + "="*70)
print("📊 MODEL COMPARISON RESULTS")
print("="*70)

results_df = pd.DataFrame(results)
results_df = results_df.sort_values('Test R²', ascending=False)

for _, row in results_df.iterrows():
    print(f"\n{row['Model']}:")
    print(f"   R² Score: {row['Test R²']:.4f} (CV: {row['CV R² Mean']:.4f} ± {row['CV R² Std']:.4f})")
    print(f"   RMSE: {row['Test RMSE']:.2f} q/ha")
    print(f"   MAE: {row['Test MAE']:.2f} q/ha")

best_model_name = results_df.iloc[0]['Model']
best_model = trained_models[best_model_name]
best_r2 = results_df.iloc[0]['Test R²']
best_rmse = results_df.iloc[0]['Test RMSE']

print("\n" + "="*70)
print(f"🏆 BEST MODEL: {best_model_name}")
print(f"   • R² Score: {best_r2:.4f} ({best_r2*100:.2f}% variance explained)")
print(f"   • RMSE: {best_rmse:.2f} q/ha")
print(f"   • MAE: {results_df.iloc[0]['Test MAE']:.2f} q/ha")
print("="*70)

# ============================================================================
# STEP 6: FEATURE IMPORTANCE ANALYSIS
# ============================================================================
if hasattr(best_model, 'feature_importances_'):
    print(f"\n🎯 FEATURE IMPORTANCE - {best_model_name}")
    print("="*70)
    
    feature_importance = best_model.feature_importances_
    importance_df = pd.DataFrame({
        'Feature': feature_cols,
        'Importance': feature_importance
    }).sort_values('Importance', ascending=False)
    
    print("\nTop 10 Most Important Features:")
    for i, row in importance_df.head(10).iterrows():
        print(f"  {importance_df.index.get_loc(i)+1:2d}. {row['Feature']:<30} {row['Importance']:.4f}")

# ============================================================================
# STEP 7: SAVE MODEL
# ============================================================================
print("\n💾 Saving model...")

model_package = {
    'model': best_model,
    'model_name': best_model_name,
    'label_encoder': label_encoder,
    'feature_columns': feature_cols,
    'r2_score': best_r2,
    'rmse': best_rmse,
    'mae': results_df.iloc[0]['Test MAE'],
    'crop_names': label_encoder.classes_.tolist(),
    'all_results': results_df.to_dict('records')
}

with open('yield_model.pkl', 'wb') as f:
    pickle.dump(model_package, f)

print("✅ Model saved: yield_model.pkl")
print(f"   • Model: {best_model_name}")
print(f"   • Performance: R²={best_r2:.4f}, RMSE={best_rmse:.2f} q/ha")
print(f"   • Features: {len(feature_cols)}")

# ============================================================================
# STEP 8: VISUALIZATIONS
# ============================================================================
print("\n📊 Generating visualizations...")

# 1. Actual vs Predicted
y_test_pred = best_model.predict(X_test)

fig, axes = plt.subplots(2, 2, figsize=(15, 12))

# Plot 1: Actual vs Predicted
ax1 = axes[0, 0]
ax1.scatter(y_test, y_test_pred, alpha=0.5, s=20)
ax1.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
ax1.set_xlabel('Actual Yield (q/ha)')
ax1.set_ylabel('Predicted Yield (q/ha)')
ax1.set_title(f'Actual vs Predicted Yield - {best_model_name}\nR² = {best_r2:.4f}')
ax1.grid(True, alpha=0.3)

# Plot 2: Residuals
ax2 = axes[0, 1]
residuals = y_test - y_test_pred
ax2.scatter(y_test_pred, residuals, alpha=0.5, s=20)
ax2.axhline(y=0, color='r', linestyle='--', lw=2)
ax2.set_xlabel('Predicted Yield (q/ha)')
ax2.set_ylabel('Residuals')
ax2.set_title('Residual Plot')
ax2.grid(True, alpha=0.3)

# Plot 3: Feature Importance
ax3 = axes[1, 0]
top_features = importance_df.head(10)
ax3.barh(range(len(top_features)), top_features['Importance'])
ax3.set_yticks(range(len(top_features)))
ax3.set_yticklabels(top_features['Feature'])
ax3.set_xlabel('Importance')
ax3.set_title('Top 10 Feature Importance')
ax3.invert_yaxis()

# Plot 4: Yield distribution by crop (sample)
ax4 = axes[1, 1]
sample_crops = df.groupby('crop')['yield'].mean().sort_values(ascending=False).head(10)
ax4.barh(range(len(sample_crops)), sample_crops.values, color='steelblue')
ax4.set_yticks(range(len(sample_crops)))
ax4.set_yticklabels(sample_crops.index)
ax4.set_xlabel('Average Yield (q/ha)')
ax4.set_title('Top 10 Crops by Average Yield')
ax4.invert_yaxis()

plt.tight_layout()
plt.savefig('yield_model_analysis.png', dpi=300, bbox_inches='tight')
print("✅ Visualizations saved: yield_model_analysis.png")

# ============================================================================
# STEP 9: TEST PREDICTIONS
# ============================================================================
print("\n🧪 Testing model with sample conditions...")
print("="*70)

test_cases = [
    {'crop': 'rice', 'N': 90, 'P': 42, 'K': 43, 'temperature': 25, 
     'humidity': 80, 'pH': 6.5, 'rainfall': 200},
    {'crop': 'wheat', 'N': 50, 'P': 30, 'K': 40, 'temperature': 18, 
     'humidity': 65, 'pH': 6.8, 'rainfall': 80},
    {'crop': 'maize', 'N': 80, 'P': 40, 'K': 20, 'temperature': 22, 
     'humidity': 65, 'pH': 6.2, 'rainfall': 90},
]

for i, case in enumerate(test_cases, 1):
    crop = case.pop('crop')
    
    # Create feature dict
    test_df = pd.DataFrame([case])
    test_df = engineer_features(test_df)
    test_df['crop_encoded'] = label_encoder.transform([crop])
    
    # Predict
    X_test_sample = test_df[feature_cols]
    predicted_yield = best_model.predict(X_test_sample)[0]
    
    print(f"\n{i}. {crop.upper()}")
    print(f"   Conditions: N={case['N']}, P={case['P']}, K={case['K']}, "
          f"T={case['temperature']}°C, H={case['humidity']}%, pH={case['pH']}, R={case['rainfall']}mm")
    print(f"   → Predicted Yield: {predicted_yield:.2f} q/ha")

print("\n" + "="*70)
print("🎉 YIELD PREDICTION MODEL TRAINING COMPLETE!")
print("="*70)
print(f"✅ Best Model: {best_model_name} (R² = {best_r2:.4f})")
print(f"✅ Model saved: yield_model.pkl")
print(f"✅ Dataset saved: crop_yield_dataset.csv")
print(f"✅ Visualizations saved: yield_model_analysis.png")
print("="*70)
