"""
Robust Model Training with Proper Validation
Addresses overfitting and provides realistic performance metrics
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import pickle
from datetime import datetime
import json
import warnings
warnings.filterwarnings('ignore')

def realistic_feature_engineering(df):
    """Conservative feature engineering to avoid overfitting"""
    print("🔧 Engineering features (conservative approach)...")
    
    # Only essential engineered features
    df['NPK_sum'] = df['n'] + df['p'] + df['k']
    df['N_P_ratio'] = df['n'] / (df['p'] + 1)
    df['soil_fertility_score'] = (df['n'] + df['p'] + df['k']) / 3
    
    # Simple climate index
    df['temp_humidity_index'] = df['temperature'] * df['humidity'] / 100
    
    # Rename to match model expectations
    df = df.rename(columns={'n': 'N', 'p': 'P', 'k': 'K', 'ph': 'pH'})
    
    return df

def calculate_optimal_ranges(df):
    """Calculate optimal ranges for explainability"""
    print("📊 Calculating optimal ranges...")
    
    ranges = {}
    features = ['N', 'P', 'K', 'temperature', 'humidity', 'pH', 'rainfall']
    
    for crop in df['crop'].unique():
        crop_data = df[df['crop'] == crop]
        ranges[crop] = {}
        
        for feature in features:
            if feature in crop_data.columns:
                q25 = crop_data[feature].quantile(0.25)
                q75 = crop_data[feature].quantile(0.75)
                ranges[crop][feature] = {
                    'min': float(q25),
                    'max': float(q75),
                    'mean': float(crop_data[feature].mean())
                }
    
    return ranges

def train_robust_model(X_train, y_train, X_test, y_test):
    """Train model with regularization to prevent overfitting"""
    print("\n🌲 Training Robust Random Forest...")
    
    # Conservative parameters to prevent overfitting
    model = RandomForestClassifier(
        n_estimators=50,        # Reduced from 200+
        max_depth=8,            # Limited depth
        min_samples_split=10,   # Higher minimum splits
        min_samples_leaf=5,     # Higher minimum leaves
        max_features='sqrt',    # Use subset of features
        random_state=42,
        n_jobs=-1
    )
    
    # Cross-validation BEFORE final training
    print("   Performing 5-fold cross-validation...")
    cv_scores = cross_val_score(model, X_train, y_train, cv=5, scoring='accuracy')
    
    print(f"   CV Scores: {[f'{s:.3f}' for s in cv_scores]}")
    print(f"   CV Mean: {cv_scores.mean():.3f} (±{cv_scores.std():.3f})")
    
    # Train on full training set
    model.fit(X_train, y_train)
    
    # Evaluate on separate test set
    y_pred = model.predict(X_test)
    test_accuracy = accuracy_score(y_test, y_pred)
    
    print(f"   ✓ Test Accuracy: {test_accuracy:.4f} ({test_accuracy*100:.2f}%)")
    
    # Check for overfitting
    train_accuracy = accuracy_score(y_train, model.predict(X_train))
    overfitting_gap = train_accuracy - test_accuracy
    
    print(f"   ✓ Train Accuracy: {train_accuracy:.4f} ({train_accuracy*100:.2f}%)")
    print(f"   ✓ Overfitting Gap: {overfitting_gap:.4f} ({overfitting_gap*100:.2f}%)")
    
    if overfitting_gap > 0.05:
        print(f"   ⚠️  WARNING: Significant overfitting detected!")
    else:
        print(f"   ✅ Overfitting under control")
    
    return model, test_accuracy, cv_scores

def validate_data_leakage(df):
    """Check for potential data leakage issues"""
    print("\n🔍 Checking for data quality issues...")
    
    # Check for duplicate rows
    duplicates = df.duplicated().sum()
    print(f"   Duplicate rows: {duplicates}")
    
    # Check class distribution
    class_counts = df['crop'].value_counts()
    print(f"   Classes: {len(class_counts)} crops")
    print(f"   Min class size: {class_counts.min()}")
    print(f"   Max class size: {class_counts.max()}")
    
    # Check for perfect separability
    for crop in df['crop'].unique():
        crop_data = df[df['crop'] == crop]
        if len(crop_data) < 20:  # Very small classes are suspicious
            print(f"   ⚠️  Small class '{crop}': only {len(crop_data)} samples")
    
    return duplicates == 0

def main():
    print("=" * 70)
    print("🛡️  ROBUST MODEL TRAINING (Anti-Overfitting)")
    print("=" * 70)
    
    # Load dataset
    print("📁 Loading dataset...")
    df = pd.read_csv('../smartcrop_cleaned.csv')
    print(f"Dataset size: {len(df)} samples, {len(df.columns)} features")
    
    # Validate data quality
    is_clean = validate_data_leakage(df)
    
    # CRITICAL: Remove duplicates to prevent overfitting
    print(f"\n🧹 Removing duplicate samples...")
    original_size = len(df)
    df = df.drop_duplicates()
    duplicates_removed = original_size - len(df)
    print(f"   Removed {duplicates_removed} duplicate rows")
    print(f"   Clean dataset size: {len(df)} samples")
    
    # Conservative feature engineering
    df = realistic_feature_engineering(df)
    
    # Calculate optimal ranges
    optimal_ranges = calculate_optimal_ranges(df)
    
    # Save ranges
    with open('crop_optimal_ranges.json', 'w') as f:
        json.dump(optimal_ranges, f, indent=2)
    print("💾 Saved crop optimal ranges")
    
    # Use minimal features to prevent overfitting
    feature_columns = [
        'N', 'P', 'K', 'temperature', 'humidity', 'pH', 'rainfall',
        'NPK_sum', 'N_P_ratio', 'soil_fertility_score', 'temp_humidity_index'
    ]
    
    X = df[feature_columns]
    y = df['crop']
    
    print(f"Features used: {len(feature_columns)} (conservative)")
    print(f"Crops: {len(y.unique())}")
    
    # Proper train/test split with more test data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42, stratify=y  # 30% test instead of 20%
    )
    
    print(f"Training samples: {len(X_train)}")
    print(f"Test samples: {len(X_test)}")
    
    # Train robust model
    model, test_accuracy, cv_scores = train_robust_model(X_train, y_train, X_test, y_test)
    
    # Additional validation - predictions on test set
    y_pred = model.predict(X_test)
    print(f"\n📊 Detailed Performance Analysis:")
    print(f"   Cross-validation mean: {cv_scores.mean():.4f}")
    print(f"   Cross-validation std: {cv_scores.std():.4f}")
    print(f"   Test accuracy: {test_accuracy:.4f}")
    
    # Classification report for per-class metrics
    report = classification_report(y_test, y_pred, output_dict=True, zero_division=0)
    macro_avg = report['macro avg']
    print(f"   Macro Precision: {macro_avg['precision']:.4f}")
    print(f"   Macro Recall: {macro_avg['recall']:.4f}")
    print(f"   Macro F1-Score: {macro_avg['f1-score']:.4f}")
    
    # Create crop yield map
    crop_yield_map = {
        'rice': 42.8, 'wheat': 35.0, 'maize': 55.0, 'cotton': 15.0,
        'jute': 29.7, 'coffee': 34.3, 'tea': 25.0, 'sugarcane': 700.0,
        'chickpea': 18.0, 'kidneybeans': 25.0, 'pigeonpeas': 12.0,
        'mothbeans': 8.0, 'mungbean': 10.0, 'blackgram': 9.0,
        'lentil': 13.0, 'pomegranate': 120.0, 'banana': 400.0,
        'mango': 150.0, 'grapes': 180.0, 'watermelon': 250.0,
        'muskmelon': 200.0, 'apple': 300.0, 'orange': 250.0,
        'papaya': 450.0, 'coconut': 150.0
    }
    
    # Save realistic model
    model_data = {
        'model': model,
        'model_name': 'RandomForest',
        'accuracy': test_accuracy,
        'cv_scores': cv_scores.tolist(),
        'cv_mean': cv_scores.mean(),
        'cv_std': cv_scores.std(),
        'feature_names': feature_columns,
        'crop_yield_map': crop_yield_map,
        'n_features': len(feature_columns),
        'training_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'validation_metrics': {
            'precision': macro_avg['precision'],
            'recall': macro_avg['recall'],
            'f1_score': macro_avg['f1-score']
        }
    }
    
    with open('crop_model.pkl', 'wb') as f:
        pickle.dump(model_data, f)
    
    print(f"\n💾 Realistic model saved!")
    print(f"📅 Training completed at {model_data['training_date']}")
    
    # Feature importance
    print(f"\n🔍 Top 5 Feature Importances:")
    importances = model.feature_importances_
    feature_importance = list(zip(feature_columns, importances))
    sorted_features = sorted(feature_importance, key=lambda x: x[1], reverse=True)
    
    for feature, importance in sorted_features[:5]:
        print(f"  {feature}: {importance:.4f}")
    
    # Reality check
    if test_accuracy > 0.98:
        print(f"\n⚠️  WARNING: Accuracy still suspiciously high!")
        print(f"   This may indicate data leakage or overfitting")
        print(f"   Consider:")
        print(f"   - Checking for duplicate samples")
        print(f"   - Validating feature engineering")
        print(f"   - Using more diverse test data")
    elif test_accuracy < 0.85:
        print(f"\n⚠️  WARNING: Accuracy quite low")
        print(f"   This may indicate underfitting")
        print(f"   Consider adding more relevant features")
    else:
        print(f"\n✅ Realistic performance achieved!")
        print(f"   Model shows good generalization capability")

if __name__ == "__main__":
    main()