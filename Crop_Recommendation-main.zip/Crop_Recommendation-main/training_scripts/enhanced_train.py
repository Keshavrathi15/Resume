"""
Enhanced Model Training Script
Improved performance with advanced techniques
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.feature_selection import SelectKBest, f_classif
import pickle
from datetime import datetime
import json
import warnings
import xgboost as xgb
from catboost import CatBoostClassifier
warnings.filterwarnings('ignore')

def enhanced_feature_engineering(df):
    """Advanced feature engineering with domain knowledge"""
    print("🔧 Engineering advanced features...")
    
    # Basic engineered features
    df['NPK_sum'] = df['n'] + df['p'] + df['k']
    df['N_P_ratio'] = df['n'] / (df['p'] + 1e-6)
    df['N_K_ratio'] = df['n'] / (df['k'] + 1e-6)
    df['P_K_ratio'] = df['p'] / (df['k'] + 1e-6)
    
    # Climate indices
    df['temp_humidity_index'] = df['temperature'] * df['humidity'] / 100
    df['water_stress_index'] = df['rainfall'] / (df['temperature'] + 1)
    
    # Soil fertility indicators
    df['soil_fertility_score'] = (df['n'] + df['p'] + df['k']) / 3
    df['NPK_balance'] = np.std([df['n'], df['p'], df['k']], axis=0)
    
    # Environmental stress factors
    df['heat_stress'] = np.where(df['temperature'] > 35, 1, 0)
    df['moisture_deficit'] = np.where(df['humidity'] < 40, 1, 0)
    df['nutrient_deficiency'] = np.where((df['n'] < 50) | (df['p'] < 30) | (df['k'] < 30), 1, 0)
    
    # Polynomial features for key variables
    df['temp_squared'] = df['temperature'] ** 2
    df['humidity_squared'] = df['humidity'] ** 2
    df['rainfall_squared'] = df['rainfall'] ** 2
    df['pH_squared'] = df['ph'] ** 2
    
    # Interaction features
    df['temp_rainfall_interaction'] = df['temperature'] * df['rainfall'] / 100
    df['pH_nutrient_interaction'] = df['ph'] * df['soil_fertility_score']
    df['climate_stress'] = df['heat_stress'] + df['moisture_deficit']
    
    # Advanced ratios
    df['nutrient_density'] = df['NPK_sum'] / (df['ph'] + 1)
    df['growth_potential'] = (df['soil_fertility_score'] * df['temp_humidity_index']) / (df['climate_stress'] + 1)
    
    # Rename to match model expectations
    df = df.rename(columns={'n': 'N', 'p': 'P', 'k': 'K', 'ph': 'pH'})
    
    return df

def calculate_optimal_ranges(df):
    """Calculate optimal ranges using advanced statistics"""
    print("📊 Calculating optimal ranges with statistical analysis...")
    
    ranges = {}
    base_features = ['N', 'P', 'K', 'temperature', 'humidity', 'pH', 'rainfall']
    
    for crop in df['crop'].unique():
        crop_data = df[df['crop'] == crop]
        ranges[crop] = {}
        
        for feature in base_features:
            if feature in crop_data.columns:
                # Use interquartile range for more robust statistics
                q25 = crop_data[feature].quantile(0.25)
                q75 = crop_data[feature].quantile(0.75)
                median = crop_data[feature].median()
                std = crop_data[feature].std()
                
                # More sophisticated range calculation
                iqr = q75 - q25
                optimal_min = max(q25 - 0.5 * iqr, crop_data[feature].min())
                optimal_max = min(q75 + 0.5 * iqr, crop_data[feature].max())
                
                ranges[crop][feature] = {
                    'min': float(optimal_min),
                    'max': float(optimal_max),
                    'mean': float(median),  # Use median instead of mean for robustness
                    'std': float(std)
                }
    
    return ranges

def train_enhanced_random_forest(X_train, y_train, X_test, y_test):
    """Train Random Forest with hyperparameter tuning"""
    print("\n🌲 Training Enhanced Random Forest...")
    
    # Hyperparameter grid
    param_grid = {
        'n_estimators': [100, 200, 300],
        'max_depth': [10, 15, 20, None],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4],
        'max_features': ['sqrt', 'log2', None]
    }
    
    # Base model
    rf = RandomForestClassifier(random_state=42, n_jobs=-1)
    
    # Grid search with cross-validation
    print("   Performing hyperparameter tuning...")
    grid_search = GridSearchCV(
        rf, param_grid, 
        cv=3, scoring='accuracy', 
        n_jobs=-1, verbose=0
    )
    
    grid_search.fit(X_train, y_train)
    
    best_rf = grid_search.best_estimator_
    print(f"   Best parameters: {grid_search.best_params_}")
    
    # Evaluate
    y_pred = best_rf.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"   ✓ Enhanced RF Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    
    return best_rf, accuracy

def train_enhanced_xgboost(X_train, y_train, X_test, y_test):
    """Train XGBoost with advanced parameters"""
    print("\n⚡ Training Enhanced XGBoost...")
    
    # Label encoding for XGBoost
    le = LabelEncoder()
    y_train_encoded = le.fit_transform(y_train)
    y_test_encoded = le.transform(y_test)
    
    # Advanced XGBoost parameters
    model = xgb.XGBClassifier(
        n_estimators=200,
        max_depth=8,
        learning_rate=0.1,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        eval_metric='mlogloss',
        use_label_encoder=False,
        early_stopping_rounds=10
    )
    
    # Train with validation set
    model.fit(
        X_train, y_train_encoded,
        eval_set=[(X_test, y_test_encoded)],
        verbose=False
    )
    
    # Evaluate
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test_encoded, y_pred)
    
    # Modify model for string labels
    model.label_encoder = le
    original_predict = model.predict
    model.predict = lambda X: le.inverse_transform(original_predict(X))
    
    print(f"   ✓ Enhanced XGB Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    
    return model, accuracy

def train_enhanced_catboost(X_train, y_train, X_test, y_test):
    """Train CatBoost with optimized parameters"""
    print("\n🐱 Training Enhanced CatBoost...")
    
    model = CatBoostClassifier(
        iterations=300,
        depth=8,
        learning_rate=0.1,
        random_seed=42,
        verbose=False,
        early_stopping_rounds=20,
        eval_metric='Accuracy'
    )
    
    # Train with validation
    model.fit(
        X_train, y_train,
        eval_set=(X_test, y_test),
        verbose=False
    )
    
    # Evaluate
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"   ✓ Enhanced CB Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    
    return model, accuracy

def perform_feature_selection(X_train, y_train, X_test, k=15):
    """Select top k features using statistical tests"""
    print(f"\n🎯 Performing feature selection (top {k} features)...")
    
    selector = SelectKBest(score_func=f_classif, k=k)
    X_train_selected = selector.fit_transform(X_train, y_train)
    X_test_selected = selector.transform(X_test)
    
    selected_features = X_train.columns[selector.get_support()].tolist()
    print(f"   Selected features: {selected_features}")
    
    return X_train_selected, X_test_selected, selected_features, selector

def main():
    print("=" * 70)
    print("🚀 ENHANCED MODEL TRAINING")
    print("=" * 70)
    
    # Load dataset
    print("📁 Loading dataset...")
    df = pd.read_csv('../smartcrop_cleaned.csv')
    print(f"Dataset size: {len(df)} samples, {len(df.columns)} features")
    
    # Enhanced feature engineering
    df = enhanced_feature_engineering(df)
    
    # Calculate optimal ranges
    optimal_ranges = calculate_optimal_ranges(df)
    
    # Save ranges
    with open('crop_optimal_ranges.json', 'w') as f:
        json.dump(optimal_ranges, f, indent=2)
    print("💾 Saved enhanced crop ranges")
    
    # Prepare features (select engineered features)
    feature_columns = [
        'N', 'P', 'K', 'temperature', 'humidity', 'pH', 'rainfall',
        'NPK_sum', 'N_P_ratio', 'N_K_ratio', 'P_K_ratio',
        'temp_humidity_index', 'water_stress_index', 'soil_fertility_score',
        'NPK_balance', 'heat_stress', 'moisture_deficit', 'nutrient_deficiency',
        'temp_squared', 'humidity_squared', 'rainfall_squared', 'pH_squared',
        'temp_rainfall_interaction', 'pH_nutrient_interaction', 'climate_stress',
        'nutrient_density', 'growth_potential'
    ]
    
    X = df[feature_columns]
    y = df['crop']
    
    print(f"Features: {len(feature_columns)}")
    print(f"Crops: {len(y.unique())}")
    
    # Split data with stratification
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    print(f"Training samples: {len(X_train)}")
    print(f"Test samples: {len(X_test)}")
    
    # Feature selection
    X_train_fs, X_test_fs, selected_features, selector = perform_feature_selection(
        X_train, y_train, X_test, k=15
    )
    
    # Train models with feature selection
    models = {}
    
    # Random Forest
    rf_model, rf_acc = train_enhanced_random_forest(X_train_fs, y_train, X_test_fs, y_test)
    models['Enhanced RandomForest'] = (rf_model, rf_acc)
    
    # XGBoost  
    xgb_model, xgb_acc = train_enhanced_xgboost(X_train_fs, y_train, X_test_fs, y_test)
    models['Enhanced XGBoost'] = (xgb_model, xgb_acc)
    
    # CatBoost
    cb_model, cb_acc = train_enhanced_catboost(X_train_fs, y_train, X_test_fs, y_test)
    models['Enhanced CatBoost'] = (cb_model, cb_acc)
    
    # Select best model
    best_model_name = max(models.keys(), key=lambda x: models[x][1])
    best_model, best_accuracy = models[best_model_name]
    
    print(f"\n🏆 Best Model Selection:")
    for name, (model, acc) in models.items():
        indicator = "👑" if name == best_model_name else "  "
        print(f"   {indicator} {name}: {acc:.4f} ({acc*100:.2f}%)")
    
    # Create comprehensive model data
    crop_yield_map = {
        'rice': 42.8, 'wheat': 35.0, 'maize': 55.0, 'cotton': 15.0,
        'jute': 29.7, 'coffee': 34.3, 'tea': 25.0, 'sugarcane': 700.0,
        'chickpea': 18.0, 'kidneybeans': 25.0, 'pigeonpeas': 12.0,
        'mothbeans': 8.0, 'mungbean': 10.0, 'blackgram': 9.0,
        'lentil': 13.0, 'pomegranate': 120.0, 'banana': 400.0,
        'mango': 150.0, 'grapes': 180.0, 'watermelon': 250.0,
        'muskmelon': 200.0, 'apple': 300.0, 'orange': 250.0,
        'papaya': 450.0, 'coconut': 150.0
    }
    
    model_data = {
        'model': best_model,
        'model_name': f'{best_model_name} (Enhanced)',
        'accuracy': best_accuracy,
        'feature_names': selected_features,  # Use selected features
        'feature_selector': selector,  # Include selector for preprocessing
        'crop_yield_map': crop_yield_map,
        'n_features': len(selected_features),
        'training_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'all_model_scores': {name: acc for name, (_, acc) in models.items()}
    }
    
    # Save enhanced model
    with open('crop_model.pkl', 'wb') as f:
        pickle.dump(model_data, f)
    
    print(f"\n💾 Enhanced model saved!")
    print(f"📅 Training completed at {model_data['training_date']}")
    print(f"🎯 Final accuracy: {best_accuracy:.4f} ({best_accuracy*100:.2f}%)")
    
    # Feature importance
    if hasattr(best_model, 'feature_importances_'):
        print(f"\n🔍 Top 5 Feature Importances:")
        importances = best_model.feature_importances_
        feature_importance = list(zip(selected_features, importances))
        sorted_features = sorted(feature_importance, key=lambda x: x[1], reverse=True)
        
        for feature, importance in sorted_features[:5]:
            print(f"  {feature}: {importance:.4f}")
    
    # Classification report
    print(f"\n📊 Model Performance Summary:")
    y_pred = best_model.predict(X_test_fs)
    print(f"Test Accuracy: {accuracy_score(y_test, y_pred):.4f}")
    
    print("\n🎉 Enhanced training complete!")

if __name__ == "__main__":
    main()