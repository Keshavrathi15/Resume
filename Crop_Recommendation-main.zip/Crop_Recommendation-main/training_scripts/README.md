# 🏋️ Training Scripts

This folder contains all training-related scripts and datasets.

## Training Scripts

### Main Training Scripts
- **train_model.py** - Full training pipeline with model comparison (707 lines)
- **fast_train.py** - Optimized fast training (30 seconds, 150 lines)
- **train_yield_model.py** - Yield prediction model training with synthetic data generation
- **enhanced_train.py** - Enhanced training with additional features
- **robust_train.py** - Robust training with advanced validation

## Datasets

- **smartcrop_cleaned.csv** - Classifier training dataset (6,600 samples, 22 crops)
- **crop_yield_dataset.csv** - Yield regressor training dataset (11,500 samples, 23 crops)

## Usage

### Quick Training (Recommended)
```bash
cd training_scripts
python fast_train.py
```
**Output:** `../app/crop_model.pkl` (99.70% accuracy, 30s training)

### Full Training Pipeline
```bash
cd training_scripts
python train_model.py --dataset "smartcrop_cleaned.csv"
```
**Output:** Compares RandomForest, XGBoost, CatBoost and saves best model

### Yield Model Training
```bash
cd training_scripts
python train_yield_model.py
```
**Output:** 
- Generates synthetic dataset (crop_yield_dataset.csv)
- Trains RandomForestRegressor
- Saves `../app/yield_model.pkl` (R²=0.9938)

## Training Features

### Model Comparison
- RandomForest (fastest, 99.70%)
- XGBoost (balanced, ~99.0%)
- CatBoost (slowest, ~99.2%)

### Validation
- 80-20 train-test split
- 5-fold cross-validation
- Overfitting detection
- Automated model selection

### Performance
- Classifier: 30 seconds (fast_train.py)
- Yield Regressor: ~2 minutes
- Full Pipeline: ~5 minutes (without CatBoost)

## Output

Trained models saved to `../app/`:
- `crop_model.pkl` (15MB) - Crop classifier
- `yield_model.pkl` (45MB) - Yield regressor

## Notes

⚠️ **These scripts are NOT needed to run the app**
- Pre-trained models already exist in `../app/`
- Use only for retraining or experimentation
- Requires full dependencies from `../app/requirements.txt`
