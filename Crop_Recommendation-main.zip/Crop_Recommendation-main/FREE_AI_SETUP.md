# 🆓 FREE AI API KEYS - SETUP GUIDE

Your Gemini API has hit the limit. Here are **FREE alternatives** with generous limits:

---

## 🥇 OPTION 1: GROQ (RECOMMENDED - FASTEST)

**Why Groq?**
- ⚡ 10x faster than OpenAI/Gemini
- 🆓 **30 requests/minute** (14,400/day) - MORE than enough
- 🤖 Powered by Llama 3.1 70B (excellent quality)
- 💯 100% FREE forever

**Get Your Key (takes 1 minute):**

1. **Go to**: https://console.groq.com
2. **Sign up** with Google/GitHub
3. **Click "API Keys"** in left sidebar
4. **Click "Create API Key"**
5. **Copy the key** (starts with `gsk_...`)
6. **Paste in `.env` file**:
   ```
   GROQ_API_KEY=gsk_your_key_here
   ```

**Done!** Your app will automatically use Groq.

---

## 🥈 OPTION 2: HUGGING FACE (GOOD BACKUP)

**Free Tier:**
- 🆓 30,000 tokens/month
- 🤖 Llama 3, Mistral, Zephyr models
- 📚 Access to 100+ open-source models

**Get Your Key:**

1. **Go to**: https://huggingface.co/settings/tokens
2. **Sign up** (free)
3. **Click "New token"**
4. **Name it** (e.g., "farming-app")
5. **Select "Read" access**
6. **Copy the token**
7. **Add to `.env`**:
   ```
   HUGGINGFACE_API_KEY=hf_your_token_here
   ```

---

## 🥉 OPTION 3: TOGETHER AI (BEST MODELS)

**Free Tier:**
- 🆓 $25 credit (lasts months)
- 🤖 Llama 3.1, Mixtral, Qwen models
- ⚡ Fast inference

**Get Your Key:**

1. **Go to**: https://api.together.xyz
2. **Sign up**
3. **Navigate to Settings → API Keys**
4. **Create new key**
5. **Add to `.env`**:
   ```
   TOGETHER_API_KEY=your_key_here
   ```

---

## 🔧 HOW TO USE

### Step 1: Get Groq API Key (2 minutes)
1. Visit https://console.groq.com
2. Sign up (free)
3. Create API key
4. Copy the key (starts with `gsk_...`)

### Step 2: Update `.env` File
Open `app/.env` and add:

```env
# Groq API (RECOMMENDED - Fast & Free)
GROQ_API_KEY=gsk_YOUR_KEY_HERE
```

### Step 3: Install Groq Library
Run in terminal:

```bash
pip install groq
```

### Step 4: Run Your App
```bash
cd app
streamlit run streamlit_app.py
```

**That's it!** Your app will automatically use Groq instead of Gemini.

---

## 🚀 AUTOMATIC FALLBACK

The app now supports **multiple providers** with automatic fallback:

1. **Groq** (tries first - fastest)
2. **Hugging Face** (if Groq fails)
3. **Gemini** (if others fail)
4. **Rules-based** (if all AI fails)

Add API keys in `.env` and the app handles the rest!

---

## 📊 COMPARISON

| Provider | Free Limit | Speed | Quality | Setup Time |
|----------|-----------|-------|---------|------------|
| **Groq** 🥇 | 14,400/day | ⚡⚡⚡ | ⭐⭐⭐⭐⭐ | 1 min |
| Hugging Face | 30k tokens/month | ⚡⚡ | ⭐⭐⭐⭐ | 2 min |
| Together AI | $25 credit | ⚡⚡⚡ | ⭐⭐⭐⭐⭐ | 2 min |
| Gemini | 15 req/min | ⚡⚡ | ⭐⭐⭐⭐ | 1 min |

---

## 💡 PRO TIP

Get **ALL THREE** API keys:
- **Groq** for daily use (super fast, unlimited)
- **Hugging Face** as backup
- **Gemini** as final fallback

This gives you 100% uptime! If one fails, the app automatically switches to the next.

---

## ❓ TROUBLESHOOTING

### "Module 'groq' not found"
```bash
pip install groq
```

### "Module 'huggingface_hub' not found"
```bash
pip install huggingface-hub
```

### "All providers failed"
Check your `.env` file has valid keys with no extra spaces.

### "Rate limit exceeded"
The app automatically tries next provider. If all fail, it uses rules-based fallback.

---

## 🎯 RECOMMENDED SETUP (5 minutes)

1. Get Groq API key: https://console.groq.com ✅
2. Add to `.env`: `GROQ_API_KEY=gsk_...` ✅
3. Run: `pip install groq` ✅
4. Restart app: `streamlit run streamlit_app.py` ✅

**You now have 14,400 free AI requests per day!** 🎉

No credit card needed. No payment ever required. Just fast, free AI.
