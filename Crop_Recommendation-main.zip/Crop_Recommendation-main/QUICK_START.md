# Quick Start Guide - Get FREE AI API Key in 2 Minutes

## 🚀 FASTEST OPTION: GROQ (RECOMMENDED)

### Step 1: Get Your Free API Key (1 minute)
1. Open: **https://console.groq.com**
2. Click **"Sign up"** (use Google/GitHub)
3. Click **"API Keys"** (left sidebar)
4. Click **"Create API Key"**
5. **Copy the key** (looks like: `gsk_xxxxxxxxxxxxxx`)

### Step 2: Add to Your Project (30 seconds)
1. Open file: `app/.env`
2. Find the line: `GROQ_API_KEY=`
3. Paste your key after the `=`:
   ```
   GROQ_API_KEY=gsk_your_key_here
   ```
4. **Save the file**

### Step 3: Install Groq Library (30 seconds)
Open terminal in your project folder and run:
```bash
pip install groq
```

### Step 4: Test It! (30 seconds)
```bash
cd app
python test_groq.py
```

## ✅ That's It!

Your app now has:
- **14,400 FREE requests per day** (vs Gemini's 15/minute)
- **10x FASTER** response time
- **Better quality** (Llama 3.1 70B model)
- **No payment** required ever

## 🎯 Quick Commands

```bash
# 1. Install Groq
pip install groq

# 2. Test connection
cd app
python test_groq.py

# 3. Run your app
streamlit run streamlit_app.py
```

## 💡 Why Groq?

| Feature | Gemini (Free) | Groq (Free) |
|---------|---------------|-------------|
| Requests/minute | 15 | 30 |
| Requests/day | ~1,000 | 14,400 |
| Speed | 2-5 seconds | 0.3-1 second |
| Model | Gemini 2.0 | Llama 3.1 70B |
| Credit card | No | No |

**Groq is 5-10x faster and has 14x more requests!**

## 🆘 Need Help?

**"Where do I paste the API key?"**
- Open `app/.env` file
- Find: `GROQ_API_KEY=`
- Paste after `=` (no spaces)
- Save

**"Module 'groq' not found"**
```bash
pip install groq
```

**"Still using Gemini?"**
- Make sure `.env` has: `GROQ_API_KEY=gsk_...`
- Restart your app
- Check terminal - should say "Groq API detected"

---

## 🎁 BONUS: Get All 3 Free APIs

For 100% uptime, get all three free APIs (takes 5 minutes):

1. **Groq** (main): https://console.groq.com
2. **Hugging Face** (backup): https://huggingface.co/settings/tokens
3. **Keep Gemini** (fallback): Already have it

App automatically switches if one fails!

---

**Ready?** Get your Groq key now: https://console.groq.com

**Questions?** The app shows which API it's using in the terminal when you run it.
