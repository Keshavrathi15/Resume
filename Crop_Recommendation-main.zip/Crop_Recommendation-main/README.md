# 🌾 AI-Powered Smart Crop Recommendation System

![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)
![Streamlit](https://img.shields.io/badge/Streamlit-1.30.0-red.svg)
![scikit-learn](https://img.shields.io/badge/scikit--learn-1.3.2-orange.svg)
![License](https://img.shields.io/badge/License-MIT-yellow.svg)

## 🎯 Overview

A production-ready AI system that combines **Machine Learning**, **Weather APIs**, and **Large Language Models (Gemini/Llama)** to provide intelligent crop recommendations and personalized farming plans for farmers.

### ✨ Key Features

- 🤖 **Local ML Model**: Self-trained RandomForest/XGBoost/CatBoost models with 99.7% accuracy
- 🌤️ **Dataset-Driven Explainability**: Crop-specific optimal ranges from your actual data
- 📊 **Comprehensive Analysis**: 22 crops, 21 features, instant predictions
- 🎨 **Clean Web Interface**: Streamlit-powered user-friendly interface
- 💾 **Local Operation**: No external APIs required for core functionality
- 🧠 **Multi-Provider AI Planning**: Google Gemini 2.0 & Groq (Llama 3) integration for farming advice
- 🛡️ **Smart Robustness**: Automatic fallback to rules-based system if AI quotas are exceeded
- 📋 **Complete Guidance**: Soil analysis, yield estimation, and recommendations

---

## 🏗️ Architecture

```
┌─────────────┐
│   Farmer    │
│  (Browser)  │
└──────┬──────┘
       │
       ▼
┌─────────────────────────────────────┐
│     Streamlit Frontend              │
│  (Interactive UI & Visualization)   │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│      CropRecommender Engine         │
│   (Local ML & Explainability)      │
└──────────┬──────────┬───────────────┘
           │          │
           ▼          ▼
    ┌──────────┐  ┌──────────────┐
    │ Local ML │  │ Optional AI  │
    │ Model    │  │ Planner      │
    │(RF/XGB/  │  │(Gemini/Groq) │
    │CatBoost) │  └──────────────┘
    └──────────┘
           │
           ▼
    ┌──────────────────┐
    │ Dataset-Driven   │
    │ Explainability   │
    └──────────────────┘
```

---

## 📁 Project Structure

```
Crop_Detection/
├── smartcrop_cleaned.csv       # Training dataset (6,600 samples)
└── app/
    ├── train_model.py          # Train & compare ML models
    ├── fast_train.py           # Optimized fast training
    ├── crop_model.pkl          # Saved best model (generated)
    ├── crop_optimal_ranges.json # Dataset-driven ranges
    ├── recommender.py          # ML prediction engine
    ├── ai_planner.py           # Single-provider AI planner (Gemini)
    ├── ai_planner_multi.py     # Multi-provider AI planner (Groq + Gemini)
    ├── explainability.py       # Dataset-driven explanations
    ├── streamlit_app.py        # Web UI frontend (MAIN APP)
    ├── utils.py                # Utility functions
    ├── requirements.txt        # Python dependencies
    └── test_explainability.py  # Testing tools
```

---

## 🚀 Quick Start

### Prerequisites

- Python 3.8 or higher
- pip package manager
- pip package manager
- (Optional) Google Gemini API key or Groq API key for AI farming plans

### Installation

1. **Navigate to the project directory**
   ```powershell
   cd c:\Users\lenovo\OneDrive\Desktop\Crop_Detection\app
   ```

2. **Create a virtual environment (recommended)**
   ```powershell
   python -m venv venv
   .\venv\Scripts\Activate
   ```

3. **Install dependencies**
   ```powershell
   pip install -r requirements.txt
   pip install groq  # Required for Llama 3 on Groq
   ```

4. **Set up AI integration (optional)**
   
   Create a `.env` file in the `app` directory for AI farming plans:
   ```env
   # Primary: Fast & Free (Llama 3)
   GROQ_API_KEY=gsk_...
   
   # Backup: Google Gemini
   GOOGLE_API_KEY=AIza...
   ```
   
   Or set environment variables:
   ```powershell
   $env:GROQ_API_KEY="your_key"
   $env:GEMINI_API_KEY="your_key"
   ```

---

## 📚 Usage Guide

### Step 1: Train the Model

Train your local ML model with your dataset:

**Fast Training (Recommended)**
```powershell
python fast_train.py
```

**Full Pipeline Training**
```powershell
python train_model.py --dataset "../smartcrop_cleaned.csv"
```

**What it does:**
- Loads your dataset (6,600 samples)
- Trains RandomForest with optimized parameters
- Creates dataset-driven explainability ranges
- Saves `crop_model.pkl` and `crop_optimal_ranges.json`

**Expected Output:**
```
🚀 FAST MODEL TRAINING
📁 Loading dataset... 6600 samples
🌳 Training Random Forest...
📊 Results: Test Accuracy: 99.70%
### Step 2: Run the Web Application

Launch the Streamlit web interface:

```powershell
streamlit run streamlit_app.py
```

**What happens:**
- Loads your trained model automatically
- Opens web browser at `http://localhost:8501`
- Provides interactive crop recommendation interface
- Includes dataset-driven explanations and optional AI planning

**Features Available:**
- 🌾 **Crop Prediction**: Enter soil parameters, get instant recommendations
- 🔍 **Smart Explanations**: See why specific conditions are optimal/suboptimal
- 📊 **Yield Estimation**: Predicted crop yields based on your inputs
- 🧠 **AI Farming Plans**: Optional 12-week farming schedules (requires API key)
- 📈 **What-If Analysis**: Compare different scenarios

---

### Step 3: Test Individual Components

**Test crop prediction directly:**
```powershell
python -c "
from recommender import CropRecommender
r = CropRecommender()
result = r.predict({'N': 90, 'P': 42, 'K': 43, 'temperature': 20.9, 'humidity': 82, 'pH': 6.5, 'rainfall': 202.9})
print(f'Recommended: {result["crop"]} ({result["confidence"]:.1f}% confidence)')
"
```

**Test explainability system:**
```powershell
python test_explainability.py
```

---

## 💡 Advanced Usage

### Custom Dataset Training

Use your own agricultural data:

1. **Prepare CSV** with columns: `n,p,k,temperature,humidity,ph,rainfall,crop`
2. **Train model**: `python train_model.py --dataset "your_data.csv"`
3. **Verify model**: Check `crop_model.pkl` and accuracy results

### Batch Predictions

Process multiple predictions at once:

```python
from recommender import CropRecommender

recommender = CropRecommender()
samples = [
    {'N': 90, 'P': 42, 'K': 43, 'temperature': 20.9, 'humidity': 82, 'pH': 6.5, 'rainfall': 202.9},
    {'N': 85, 'P': 58, 'K': 41, 'temperature': 21.8, 'humidity': 80, 'pH': 6.8, 'rainfall': 226.7}
]

for sample in samples:
    result = recommender.predict(sample)
    print(f"Soil: {sample['pH']:.1f} pH → Crop: {result['crop']} ({result['confidence']:.1f}%)")
```

### Model Comparison

Compare different training approaches:

```powershell
# Fast training (30 seconds)
python fast_train.py

# Full pipeline training (with cross-validation)
python train_model.py --dataset "../smartcrop_cleaned.csv"
```

**2. Generate Farming Plan:**
```powershell
curl -X POST "http://localhost:8000/plan" `
  -H "Content-Type: application/json" `
  -d '{
    "crop": "Rice",
    "soil_features": {
      "N": 90, "P": 42, "K": 43,
      "temperature": 20.5, "humidity": 82,
      "pH": 6.5, "rainfall": 202
    },
    "city": "Mumbai"
  }'
```

**3. Full Analysis:**
```powershell
curl -X POST "http://localhost:8000/full" `
  -H "Content-Type: application/json" `
  -d '{
    "soil_features": {
      "N": 90, "P": 42, "K": 43,
      "temperature": 20.5, "humidity": 82,
      "pH": 6.5, "rainfall": 202
    },
    "city": "Mumbai"
  }'
```

### Using Python Requests

```python
import requests

url = "http://localhost:8000/full"
payload = {
    "soil_features": {
        "N": 90, "P": 42, "K": 43,
        "temperature": 20.5, "humidity": 82,
        "pH": 6.5, "rainfall": 202
    },
    "city": "Mumbai"
}

response = requests.post(url, json=payload)
result = response.json()

print(f"Recommended Crop: {result['summary']['recommended_crop']}")
print(f"Confidence: {result['summary']['confidence']}%")
```

---

## 📊 Model Performance

The system uses a **dual-model architecture** with independent ML models:

### Crop Classification Model
- **Architecture**: RandomForest Classifier
- **Accuracy**: 99.20%
- **Features**: 11 soil and climate parameters
- **Output**: Predicted crop type with confidence score

### Yield Prediction Model
- **Architecture**: RandomForest Regressor
- **Performance**: R² = 0.9938, RMSE = 6.27 q/ha
- **Features**: 8 parameters (crop type + soil conditions)
- **Output**: Estimated yield in quintals/hectare

| Model | Typical Accuracy | Training Time | Prediction Speed |
|-------|------------------|---------------|------------------|
| RandomForest | ~98.5% | Fast | Very Fast |
| XGBoost | ~99.0% | Medium | Fast |
| CatBoost | ~99.2% | Slow | Fast |

**Note:** Both models run independently in parallel - the classifier predicts crop type while the regressor estimates yield.

---

## 🎯 ML-Based Optimization Feature

The system includes an advanced **ML-based optimization engine** that finds optimal growing conditions for maximum yield:

### How It Works

**Traditional Approach (Statistical):**
- Searches historical data for top 10% highest yields
- Takes median values of their conditions
- **Limitation**: Only reports what worked historically, doesn't predict new optimal combinations

**ML-Based Optimization (NEW):**
1. **Global Search**: Uses `scipy.optimize.differential_evolution` algorithm
2. **Parameter Space**: Explores realistic bounds (10th-90th percentile from data)
3. **Objective Function**: Maximizes predicted yield using trained regressor
4. **Smart Prediction**: Considers complex parameter interactions learned by ML model
5. **Convergence**: Runs 100 iterations with population size 15 to find global maximum

### Algorithm Details

```python
# Optimization objective
def objective(params):
    # params = [N, P, K, temperature, humidity, pH, rainfall]
    soil_features = {
        'N': params[0], 'P': params[1], 'K': params[2],
        'temperature': params[3], 'humidity': params[4],
        'pH': params[5], 'rainfall': params[6]
    }
    predicted_yield = yield_model.predict(soil_features)
    return -predicted_yield  # Minimize negative = Maximize yield

# Run global optimization
result = differential_evolution(
    objective,
    bounds=[(N_min, N_max), (P_min, P_max), ...],
    maxiter=100,
    popsize=15,
    strategy='best1bin'
)

optimal_conditions = result.x  # Best parameter combination
max_predicted_yield = -result.fun
```

### Key Advantages

✅ **Active Prediction**: Uses ML model to predict outcomes, not just historical lookup  
✅ **Global Optimization**: Finds best combination across entire parameter space  
✅ **Interaction Awareness**: Considers how N, P, K, temperature, etc. interact  
✅ **Novel Solutions**: Can suggest parameter combinations not seen in training data  
✅ **Confidence Metrics**: Compares ML prediction with historical top 10% performance  

### Usage

In the web interface sidebar:
1. Enter crop name (e.g., "rice", "wheat", "maize")
2. Click **"🔍 Find Optimal Conditions"**
3. System runs ML optimization (10-20 seconds)
4. View results showing:
   - ML predicted maximum yield
   - Optimal values for N, P, K, temperature, humidity, pH, rainfall
   - Comparison with historical top 10% yields
   - Realistic min/max ranges for each parameter

**Example Output:**
```
ML Predicted Max Yield: 85.3 q/ha
Historical Top 10%: 78.2 q/ha

Optimal Conditions:
- Nitrogen (N): 95.3 kg/ha [Source: ML Optimized]
- Phosphorus (P): 48.7 kg/ha [Source: ML Optimized]
- Potassium (K): 42.1 kg/ha [Source: ML Optimized]
- Temperature: 23.5°C [Source: ML Optimized]
- Humidity: 78.2% [Source: ML Optimized]
- pH: 6.8 [Source: ML Optimized]
- Rainfall: 215.3 mm/month [Source: ML Optimized]
```

---

## 🌾 Supported Crops

The trained model can predict 22+ crops including:

- **Cereals**: Rice, Wheat, Maize
- **Pulses**: Chickpea, Kidney beans, Pigeon peas, Lentil, Mung bean, Black gram, Moth beans
- **Cash Crops**: Cotton, Jute, Coffee, Sugarcane
- **Fruits**: Banana, Mango, Grapes, Watermelon, Muskmelon, Apple, Orange, Papaya, Coconut, Pomegranate

---

## 🧪 AI Farming Plan Components

Each plan includes:

1. **Seed Varieties**: Top 3 recommended varieties
2. **12-16 Week Schedule**: Week-by-week activities
3. **Irrigation Plan**: Frequency, amount, and method
4. **Fertilizer Schedule**: NPK values by week
5. **Pest/Disease Alerts**: Risk level and prevention
6. **Harvest Timeline**: Expected date and methods
7. **Cost-Saving Tips**: 8+ practical tips
8. **Market Advice**: Selling strategies and channels

---

## ⚙️ Configuration

### Weather API

1. Get free API key from [OpenWeatherMap](https://openweathermap.org/api)
2. Set environment variable or pass to API calls
3. Without API key: System uses mock weather data

### LLM Integration (Optional)

**OpenAI:**
```python
export OPENAI_API_KEY="sk-..."
```

**Groq (Llama 3):**
```python
export GROQ_API_KEY="gsk_..."
```

**Google Gemini:**
```python
export GEMINI_API_KEY="..."
```

Without LLM API: System generates rule-based farming plans (still comprehensive)

---

## 🛠️ Customization

### Use Your Own Dataset ⭐ NEW

Train with your custom crop dataset:

```powershell
python train_model.py --dataset "your_dataset.csv"
```

**Required CSV columns:**
- `N`, `P`, `K`, `temperature`, `humidity`, `ph` (or `pH`), `rainfall`, `label`

**Complete guide:** See [CUSTOM_DATASET_GUIDE.md](CUSTOM_DATASET_GUIDE.md) for:
- CSV format examples
- Column requirements
- Command-line options
- Troubleshooting tips

### Add New Crops

1. Add crop profiles to `train_model.py` → `_generate_synthetic_data()`
2. Retrain model: `python train_model.py`
3. Add crop-specific rules in `ai_planner.py`

### Adjust Model Parameters

Edit hyperparameters in `train_model.py`:

```python
rf_model = RandomForestClassifier(
    n_estimators=200,  # Increase for better accuracy
    max_depth=20,      # Adjust complexity
    random_state=42
)
```

---

## 🐛 Troubleshooting

### Model Not Found Error

```
FileNotFoundError: Model file not found
```
**Solution:** Run `python train_model.py` first

### Import Errors

```
ModuleNotFoundError: No module named 'xgboost'
```
**Solution:** `pip install -r requirements.txt`

### Weather API Errors

```
Could not fetch weather data
```
**Solution:** Check API key or internet connection. System will use mock data.

### API Quota Exceeded

```
API QUOTA EXCEEDED (ResourceExhausted)
```
**Solution:** The system automatically falls back to rules-based planning. Wait 1 minute for the free tier quota to reset, or add a Groq API key for higher limits.

### Port Already in Use

```
ERROR: Port already in use
```
**Solution:** Change port in Streamlit:
```powershell
streamlit run streamlit_app.py --server.port 8502
```

---

## 📈 Performance Tips

1. **Large Dataset**: Use `chunksize` for loading big CSV files
2. **Production**: Use `gunicorn` with multiple workers
3. **Caching**: Enable model caching for faster predictions
4. **Database**: Store predictions in DB for analytics
5. **GPU**: Use GPU-enabled XGBoost/CatBoost for large datasets

---

## 🤝 Contributing

Contributions are welcome! Areas for improvement:

- Add more crop datasets
- Integrate satellite imagery
- Add soil testing integration
- Multi-language support
- Mobile app version
- Historical yield tracking

---

## 📄 License

This project is licensed under the MIT License.

---

## 👨‍💻 Credits

**Built with:**
- Scikit-learn, XGBoost, CatBoost (ML)
- Streamlit (Local UI)
- Google Gemini (Optional AI Plans)
- Dataset-Driven Explainability

---

## 📞 Support

For issues or questions:
1. Check troubleshooting section above
2. Test individual components first
3. Verify model training completed successfully

---

## 🎓 Learning Resources

- [Scikit-learn Documentation](https://scikit-learn.org/)
- [Streamlit Gallery](https://streamlit.io/gallery)
- [XGBoost Guide](https://xgboost.readthedocs.io/)
- [CatBoost Tutorial](https://catboost.ai/)

---

## 🌟 Future Enhancements

- [ ] Add crop rotation recommendations
- [ ] Integrate soil testing APIs
- [ ] Satellite imagery analysis
- [ ] Price prediction models
- [ ] Climate change impact analysis
- [ ] Multi-season planning
- [ ] Community features for farmers
- [ ] Offline mode support

---

**Happy Farming! 🌾🚜**
