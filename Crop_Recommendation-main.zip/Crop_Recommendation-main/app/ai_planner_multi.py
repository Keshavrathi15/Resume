

import os
import sys
from typing import Dict, Any, List
from dotenv import load_dotenv
import json
import time
import warnings

# Suppress warnings
warnings.filterwarnings('ignore')
os.environ['GRPC_VERBOSITY'] = 'ERROR'
os.environ['GLOG_minloglevel'] = '3'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

# Load environment variables
load_dotenv()


class MultiProviderAIPlanner:
    """
    🤖 Multi-Provider AI Farming Planner
    Supports: Groq (FAST & FREE), Hugging Face, Google Gemini
    Automatically falls back to next provider if one fails
    """
    
    def __init__(self):
        """Initialize with multiple AI providers"""
        
        # Load API keys from .env
        self.groq_key = os.getenv('GROQ_API_KEY')
        self.gemini_key = os.getenv('GEMINI_API_KEY')
        
        self.providers = []
        
        # Priority order: Groq (fastest & free) -> Gemini (backup)
        if self.groq_key:
            self.providers.append('groq')
            print(" Groq API detected (Fast & Free - 30 req/min)")
        
        if self.gemini_key:
            self.providers.append('gemini')
            print(" Google Gemini API detected (backup only)")
        
        if not self.providers:
            print(" No AI API keys found. Using rules-based system.")
            print(" To enable AI features, add to .env file:")
            print("   - GROQ_API_KEY (get from https://console.groq.com - FREE & FAST!)")
        else:
            print(f"\n Multi-Provider AI Planner ready with {len(self.providers)} provider(s)")
    
    def _call_groq(self, prompt: str) -> str:
        """Call Groq API (Llama 3.1 - Fast & Free)"""
        try:
            from groq import Groq
            
            client = Groq(api_key=self.groq_key)
            
            response = client.chat.completions.create(
                model="llama-3.3-70b-versatile",  # Latest active model (Dec 2024)
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert agricultural planning assistant. Provide detailed, practical farming advice in valid JSON format only."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=8192,  # Increased for comprehensive agent responses
                top_p=0.95
            )
            
            return response.choices[0].message.content
        
        except ImportError:
            print(" Groq library not installed. Install: pip install groq")
            print("   Skipping Groq and trying next provider...")
            raise
        except Exception as e:
            print(f" Groq API error: {str(e)[:100]}")
            raise
    
    def _call_gemini(self, prompt: str) -> str:
        """Call Google Gemini API (fallback)"""
        try:
            import google.generativeai as genai
            
            genai.configure(api_key=self.gemini_key)
            
            model = genai.GenerativeModel(
                'gemini-2.0-flash-exp',
                generation_config={
                    'temperature': 0.7,
                    'top_p': 0.95,
                    'top_k': 40,
                    'max_output_tokens': 8192,
                }
            )
            
            response = model.generate_content(prompt)
            return response.text
        
        except Exception as e:
            print(f"⚠️ Gemini API error: {str(e)[:100]}")
            raise
    
    def generate_plan(self, crop: str, soil_features: Dict[str, float]) -> Dict[str, Any]:
        """
        Generate comprehensive farming plan using multiple AI providers
        Automatically tries providers in order until one succeeds
        
        Args:
            crop: Name of the crop to plant
            soil_features: Dictionary with N, P, K, pH, temperature, humidity, rainfall
        
        Returns:
            Dictionary with comprehensive farming plan
        """
        
        print(f"\n🌾 Generating farming plan for: {crop}")
        
        # If no providers available, use fallback directly
        if not self.providers:
            print("ℹ️ No AI providers available. Using rules-based plan.")
            return self._create_fallback_plan(crop, soil_features)
        
        # Create agent-based prompt
        prompt = self._create_farming_prompt(crop, soil_features)
        
        # Try each provider in order
        for provider in self.providers:
            try:
                print(f"🔄 Trying {provider.upper()}...")
                start_time = time.time()
                
                if provider == 'groq':
                    response_text = self._call_groq(prompt)
                elif provider == 'gemini':
                    response_text = self._call_gemini(prompt)
                
                elapsed = time.time() - start_time
                print(f"✅ {provider.upper()} responded in {elapsed:.1f}s")
                
                # Parse JSON response
                plan = self._parse_response(response_text, crop, soil_features)
                plan['generated_by'] = f'AI ({provider.capitalize()})'
                plan['generation_time'] = f'{elapsed:.1f}s'
                
                return plan
            
            except Exception as e:
                print(f"❌ {provider.upper()} failed: {str(e)[:100]}")
                
                # If this was the last provider, use fallback
                if provider == self.providers[-1]:
                    print("⚠️ All AI providers failed. Using rules-based fallback.")
                    return self._create_fallback_plan(crop, soil_features)
                
                # Try next provider
                print(f"🔄 Trying next provider...")
                time.sleep(1)
        
        # Fallback if all providers fail
        return self._create_fallback_plan(crop, soil_features)
    
    def _create_farming_prompt(self, crop: str, soil_features: Dict[str, float]) -> str:
        """Create Agent-Based Farming Prompt (same as original)"""
        
        N = soil_features.get('N', 0)
        P = soil_features.get('P', 0)
        K = soil_features.get('K', 0)
        pH = soil_features.get('ph', 7.0)
        temp = soil_features.get('temperature', 25)
        humidity = soil_features.get('humidity', 80)
        rainfall = soil_features.get('rainfall', 100)
        
        prompt = f"""You are an AUTONOMOUS Agricultural Planning Agent. Your role is to analyze farm conditions and ML predictions to create a detailed, step-by-step farming plan.

**FARM CONDITIONS YOU MUST ANALYZE:**
- Crop to plant: {crop.upper()}
- Soil Nutrients: N={N} kg/ha, P={P} kg/ha, K={K} kg/ha
- Soil pH: {pH}
- Climate: Temperature={temp}°C, Humidity={humidity}%, Rainfall={rainfall}mm/month

**YOUR TASK AS AN AGENT:**
Using the above data, create a COMPREHENSIVE farming plan. You must provide ALL sections below with detailed information:

1. **Seed Selection & Sowing**
   - Recommended varieties (3-4 options with characteristics)
   - Seed rate (kg/ha)
   - Spacing (row x plant distance)
   - Sowing method (broadcasting/line sowing/transplanting)

2. **Step-by-Step Sowing Guide**
   - Day-by-day activities for the first 2 weeks
   - Land preparation, seed treatment, sowing, irrigation timing

3. **Irrigation Schedule**
   - Irrigation method (drip/sprinkler/flood)
   - Frequency and quantity per irrigation
   - Critical growth stages requiring water
   - Total water requirement per season

4. **Fertilizer Schedule**
   - Stage-by-stage NPK application (basal + top dressings)
   - Timing (days/weeks after sowing)
   - Application method (broadcast/band/foliar)
   - Micronutrient recommendations

5. **Pest Risk Assessment**
   - 3-4 most likely pests/diseases for this crop and soil
   - Risk level (High/Medium/Low)
   - Early symptoms to watch for
   - Preventive measures (cultural/biological)
   - Control measures if infestation occurs (IPM approach)

6. **Weekly Monitoring Plan**
   - 12-week schedule of what to check each week
   - Growth milestones to expect
   - Actions to take based on observations

7. **Harvest Planning**
   - Expected days to maturity
   - Harvest indicators (visual signs, moisture content)
   - Harvesting method
   - Post-harvest handling and storage

**OUTPUT FORMAT (MUST BE VALID JSON):**
{{
  "crop": "{crop}",
  "seed_selection": {{
    "recommended_varieties": ["variety1", "variety2", "variety3"],
    "seed_rate": "10-15 kg/ha",
    "spacing": "45cm x 20cm",
    "sowing_method": "line sowing"
  }},
  "sowing_guide": [
    {{"day": 1, "activity": "Land preparation", "details": "Plow to 15cm depth..."}},
    {{"day": 7, "activity": "Sowing", "details": "Sow seeds at..."}}
  ],
  "irrigation_schedule": {{
    "method": "drip irrigation",
    "frequency": "every 3-4 days",
    "critical_stages": ["germination", "flowering", "grain filling"],
    "water_requirement": "450-500mm per season"
  }},
  "fertilizer_schedule": [
    {{"stage": "Basal", "N": 30, "P": 60, "K": 40, "application_method": "broadcast"}},
    {{"stage": "Top-dressing 1 (Week 4)", "N": 40, "P": 0, "K": 20, "application_method": "side dressing"}}
  ],
  "pest_risk_assessment": [
    {{
      "pest_name": "Stem Borer",
      "risk_level": "Medium",
      "symptoms": "Dead hearts, stem tunneling",
      "prevention": "Use pheromone traps, remove egg masses",
      "control_if_found": "Apply Chlorantraniliprole 0.4ml/L"
    }}
  ],
  "weekly_monitoring_plan": [
    {{"week": 1, "check_for": ["germination rate", "soil moisture"], "action_if_needed": "Resow gaps, irrigate if dry"}},
    {{"week": 2, "check_for": ["seedling vigor", "early pests"], "action_if_needed": "Thin if overcrowded"}}
  ],
  "harvest_planning": {{
    "expected_maturity": "90-110 days",
    "harvest_indicators": ["grain hardening", "80% yellowing"],
    "harvest_method": "combine harvester or manual",
    "post_harvest": "dry to 14% moisture, clean, store in dry place"
  }}
}}

**CRITICAL REQUIREMENTS:**
1. Generate AT LEAST 7 day-by-day entries in sowing_guide
2. Generate AT LEAST 12 weeks in weekly_monitoring_plan (one for each week of growing season)
3. Generate AT LEAST 3-4 entries in fertilizer_schedule
4. Generate AT LEAST 3-4 pests in pest_risk_assessment
5. Make it specific to {crop.upper()} and the soil conditions provided
6. Return ONLY valid JSON - no markdown, no explanations, JUST the JSON object

Begin JSON now:
"""
        
        return prompt
    
    def _parse_response(self, response_text: str, crop: str, soil_features: Dict[str, float]) -> Dict[str, Any]:
        """Parse AI response and extract JSON"""
        
        try:
            # Debug: Show what we received
            print(f"\n📝 AI Response Length: {len(response_text)} characters")
            
            # Remove markdown code blocks if present
            response_text = response_text.strip()
            if response_text.startswith('```json'):
                response_text = response_text[7:]
            if response_text.startswith('```'):
                response_text = response_text[3:]
            if response_text.endswith('```'):
                response_text = response_text[:-3]
            
            response_text = response_text.strip()
            
            # Parse JSON
            plan = json.loads(response_text)
            
            # Validate required fields
            required_fields = ['seed_selection', 'sowing_guide', 'irrigation_schedule', 
                             'fertilizer_schedule', 'pest_risk_assessment', 'weekly_monitoring_plan']
            
            missing = [f for f in required_fields if f not in plan]
            if missing:
                print(f"⚠️ AI response missing fields: {missing}")
                print("🔄 Using rules-based fallback...")
                return self._create_fallback_plan(crop, soil_features)
            
            print(f"✅ AI response validated - All fields present")
            return plan
        
        except json.JSONDecodeError as e:
            print(f"⚠️ Failed to parse AI response as JSON: {str(e)}")
            print(f"📄 First 200 chars: {response_text[:200]}...")
            print("🔄 Using rules-based fallback...")
            return self._create_fallback_plan(crop, soil_features)
    
    def _create_fallback_plan(self, crop: str, soil_features: Dict[str, float]) -> Dict[str, Any]:
        """Rules-based fallback plan (same as original ai_planner.py)"""
        
        N = soil_features.get('N', 0)
        P = soil_features.get('P', 0)
        K = soil_features.get('K', 0)
        pH = soil_features.get('ph', 7.0)
        temp = soil_features.get('temperature', 25)
        humidity = soil_features.get('humidity', 80)
        rainfall = soil_features.get('rainfall', 100)
        
        # Maturity days for different crops
        maturity_days = {
            'rice': 120, 'wheat': 110, 'maize': 90, 'chickpea': 100, 'kidneybeans': 90,
            'pigeonpeas': 120, 'mothbeans': 75, 'mungbean': 70, 'blackgram': 75,
            'lentil': 110, 'pomegranate': 180, 'banana': 365, 'mango': 120,
            'grapes': 140, 'watermelon': 90, 'muskmelon': 80, 'apple': 150,
            'orange': 240, 'papaya': 180, 'coconut': 365, 'cotton': 150,
            'jute': 120, 'coffee': 210
        }
        
        days = maturity_days.get(crop.lower(), 100)
        
        return {
            'crop': crop,
            'seed_selection': {
                'recommended_varieties': [
                    f'{crop.title()} HYV-1 (High Yielding)',
                    f'{crop.title()} Disease Resistant-2',
                    f'{crop.title()} Drought Tolerant-3'
                ],
                'seed_rate': f'{10 + (N / 10):.0f} kg/ha',
                'spacing': '45 cm x 20 cm' if crop.lower() in ['rice', 'wheat', 'maize'] else '60 cm x 30 cm',
                'sowing_method': 'Line sowing / Drilling (recommended for better yield)'
            },
            'sowing_guide': [
                {'day': 1, 'activity': 'Land Preparation', 'details': 'Deep plowing to 15-20cm depth, level the field'},
                {'day': 3, 'activity': 'Farmyard Manure', 'details': 'Apply 10-12 tons/ha of FYM'},
                {'day': 5, 'activity': 'Seed Treatment', 'details': 'Treat seeds with fungicide + bio-fertilizer'},
                {'day': 7, 'activity': 'Basal Fertilizer', 'details': f'Apply N={int(N*0.3)} P={int(P*0.5)} K={int(K*0.3)} kg/ha'},
                {'day': 8, 'activity': 'Sowing', 'details': 'Sow seeds at recommended spacing'},
                {'day': 10, 'activity': 'Light Irrigation', 'details': 'Light irrigation for germination'},
                {'day': 14, 'activity': 'Check Germination', 'details': 'Monitor germination (>80%)'}
            ],
            'irrigation_schedule': {
                'method': 'Drip irrigation (saves 40% water)',
                'frequency': f'Every {3 if rainfall > 150 else 2} days',
                'critical_stages': ['Germination', 'Tillering', 'Flowering', 'Grain filling'],
                'water_requirement': f'{max(20, int(60 - (rainfall/4)))} mm per irrigation'
            },
            'fertilizer_schedule': [
                {'stage': 'Basal (Day 0)', 'N': int(N*0.3), 'P': int(P*0.5), 'K': int(K*0.3), 'application_method': 'Broadcast before sowing'},
                {'stage': 'Top-dressing 1 (Week 3)', 'N': int(N*0.4), 'P': int(P*0.3), 'K': int(K*0.3), 'application_method': 'Side dressing'},
                {'stage': 'Top-dressing 2 (Week 6)', 'N': int(N*0.3), 'P': int(P*0.2), 'K': int(K*0.4), 'application_method': 'Band placement'}
            ],
            'pest_risk_assessment': [
                {'pest_name': f'{crop.title()} Stem Borer', 'risk_level': 'Medium', 'symptoms': 'Dead hearts', 'prevention': 'Pheromone traps', 'control_if_found': 'Spray Chlorantraniliprole'},
                {'pest_name': 'Leaf Spot', 'risk_level': 'Medium', 'symptoms': 'Brown spots on leaves', 'prevention': 'Avoid overhead irrigation', 'control_if_found': 'Spray Mancozeb'},
                {'pest_name': 'Aphids', 'risk_level': 'Low', 'symptoms': 'Curling leaves', 'prevention': 'Yellow sticky traps', 'control_if_found': 'Spray neem oil'}
            ],
            'weekly_monitoring_plan': [
                {'week': 1, 'check_for': ['Germination rate', 'Soil moisture'], 'action_if_needed': 'Resow gaps, irrigate'},
                {'week': 2, 'check_for': ['Seedling vigor', 'Early pests'], 'action_if_needed': 'Thin if needed'},
                {'week': 3, 'check_for': ['Plant height', 'Leaf color'], 'action_if_needed': 'Apply first fertilizer'},
                {'week': 4, 'check_for': ['Tillering/Branching', 'Weeds'], 'action_if_needed': 'Weed control'},
                {'week': 8, 'check_for': ['Flowering', 'Water stress'], 'action_if_needed': 'Ensure adequate moisture'},
                {'week': 12, 'check_for': ['Grain filling', 'Lodging'], 'action_if_needed': 'Support plants'}
            ],
            'harvest_planning': {
                'expected_maturity': f'{days} days',
                'harvest_indicators': ['Grain moisture 20-22%', '80% yellowing'],
                'harvest_method': 'Manual or combine harvester',
                'post_harvest': 'Dry to 14% moisture, store in dry place'
            },
            'generated_by': 'Rules-based Autonomous Agent',
            'note': '🤖 Generated by rules-based fallback system'
        }


# Example usage
if __name__ == "__main__":
    
    # Test with sample data
    planner = MultiProviderAIPlanner()
    
    test_soil = {
        'N': 40,
        'P': 30,
        'K': 35,
        'ph': 6.5,
        'temperature': 28,
        'humidity': 75,
        'rainfall': 120
    }
    
    plan = planner.generate_plan('rice', test_soil)
    
    print("\n" + "="*60)
    print("GENERATED FARMING PLAN:")
    print("="*60)
    print(json.dumps(plan, indent=2))
