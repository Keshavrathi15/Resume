

import os
import sys
from typing import Dict, Any, List
from dotenv import load_dotenv
import json
import time
import socket
import warnings

# Suppress ALL warnings and gRPC logs
warnings.filterwarnings('ignore')
os.environ['GRPC_VERBOSITY'] = 'ERROR'
os.environ['GLOG_minloglevel'] = '3'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['GRPC_ENABLE_FORK_SUPPORT'] = '0'

import google.generativeai as genai

# Load environment variables
load_dotenv()


class AIFarmingPlanner:
    """
     AI-Powered Farming Plan Generator
    Creates detailed, personalized farming plans using Google Gemini
    """
    
    def __init__(self, api_key: str = None):
        """
        Initialize AI Planner with Gemini API
        
        Args:
            api_key: Google Gemini API key (if None, loads from environment)
        """
        self.api_key = api_key or os.getenv('GEMINI_API_KEY')
        
        if not self.api_key:
            raise ValueError(
                " Gemini API key not found. "
                "Set GEMINI_API_KEY in .env file or pass it as parameter."
            )
        
        # Validate API key format
        if not self.api_key.startswith('AIza'):
            print(f" Warning: API key format looks unusual (should start with 'AIza')")
        
        # Configure Gemini AI
        genai.configure(api_key=self.api_key)
        print(f" API Key configured: {self.api_key[:10]}...{self.api_key[-5:]}")
        
        # Configure model for faster responses
        generation_config = {
            'temperature': 0.7,
            'top_p': 0.95,
            'top_k': 40,
            'max_output_tokens': 1024,  # Reduced from 2048 for faster generation
        }
        
        self.model = genai.GenerativeModel(
            'gemini-2.0-flash-exp',
            generation_config=generation_config
        )
        
        print(" AI Farming Planner initialized with Gemini 2.0 Flash")
    
    def generate_plan(self, crop: str, soil_features: Dict[str, float]) -> Dict[str, Any]:
        """
         Generate comprehensive farming plan for a crop
        
        Args:
            crop: Name of the crop
            soil_features: Dictionary with N, P, K, temperature, humidity, pH, rainfall
            
        Returns:
            Dictionary with farming plan components
        """
        max_retries = 3
        retry_count = 0
        
        # Check internet connectivity first
        if not self._check_connectivity():
            print(" No internet connection detected")
            print(" Using rules-based farming plan...")
            plan = self._create_fallback_plan(crop, soil_features)
            plan['generated_by'] = 'Rules-based (No Internet)'
            plan['note'] = 'Generated using expert agricultural rules. Internet connection unavailable.'
            return plan
        
        while retry_count < max_retries:
            try:
                # Create detailed prompt
                prompt = self._create_farming_prompt(crop, soil_features)
                
                print(f"Generating AI plan (attempt {retry_count + 1}/{max_retries})...")
                print(f"    This may take 10-20 seconds, please wait...")
                
                # Generate plan using Gemini
                response = self.model.generate_content(prompt)
                
                # Parse response
                plan = self._parse_farming_plan(response.text, crop, soil_features)
                
                print(" AI plan generated successfully!")
                return plan
            
            except Exception as e:
                retry_count += 1
                error_type = type(e).__name__
                error_msg = str(e)
                
                # Detect specific error types
                is_quota_error = any([
                    '429' in error_msg,
                    'quota' in error_msg.lower(),
                    'ResourceExhausted' in error_type,
                    'rate limit' in error_msg.lower()
                ])
                
                is_network_error = any([
                    '503' in error_msg,
                    'socket' in error_msg.lower(),
                    'connect' in error_msg.lower(),
                    'timeout' in error_msg.lower(),
                    'RetryError' in error_type
                ])
                
                # Don't retry on quota errors - fail immediately
                if is_quota_error:
                    print(f"\n API QUOTA EXCEEDED ({error_type})")
                    print(f"    Your Gemini API key has reached its usage limit")
                    print(f"\n SOLUTIONS:")
                    print(f"   1. Wait 1 minute and try again (free tier: 15 requests/minute)")
                    print(f"   2. Check usage at: https://ai.dev/usage?tab=rate-limit")
                    print(f"   3. Upgrade API plan at: https://makersuite.google.com/")
                    print(f"   4. Get a new free API key (if current one expired)")
                    print(f"\n Using rules-based farming plan...\n")
                    
                    plan = self._create_fallback_plan(crop, soil_features)
                    plan['generated_by'] = 'Rules-based (API Quota Exceeded)'
                    plan['note'] = 'Generated using expert agricultural rules. Please wait 1 minute for API quota to reset, or upgrade your Gemini API plan.'
                    return plan
                
                if retry_count < max_retries:
                    # Exponential backoff: 2s, 5s, 10s
                    wait_time = 2 ** retry_count
                    print(f" Attempt {retry_count} failed ({error_type})")
                    
                    if is_network_error:
                        print(f"    Network issue: {error_msg[:150]}")
                        print(f"    Possible causes: Firewall, VPN, or API service temporarily down")
                    else:
                        print(f"   Error: {error_msg[:200]}")
                    
                    print(f" Retrying in {wait_time} seconds... ({retry_count}/{max_retries})")
                    time.sleep(wait_time)
                    continue
                else:
                    # All retries failed, use fallback
                    print(f" AI generation failed after {max_retries} attempts ({error_type})")
                    
                    if is_network_error:
                        print(f"    Network Error: Cannot reach Google's API servers")
                        print(f"    Solutions:")
                        print(f"      • Check if firewall/antivirus is blocking connections")
                        print(f"      • Try disabling VPN if active")
                        print(f"      • Check if generativelanguage.googleapis.com is accessible")
                        print(f"      • Verify API quota at https://makersuite.google.com/")
                    else:
                        print(f"   Error: {error_msg[:300]}")
                    
                    print(" Using rules-based farming plan as fallback...")
                    plan = self._create_fallback_plan(crop, soil_features)
                    plan['generated_by'] = 'Rules-based (AI unavailable)'
                    plan['note'] = f'Generated using expert agricultural rules. AI service temporarily unavailable due to network issues.'
                    return plan
    
    def _check_connectivity(self) -> bool:
        """Check basic internet connectivity"""
        try:
            # Try to resolve Google's DNS
            socket.gethostbyname('google.com')
            return True
        except socket.error:
            return False
    
    def _create_farming_prompt(self, crop: str, soil_features: Dict[str, float]) -> str:
        """
         Create Agent-Based Farming Prompt for Gemini AI
        
        LLM acts as an autonomous farming assistant that:
        - Reads ML predictions and farm conditions
        - Applies agricultural rules and best practices
        - Generates comprehensive step-by-step farming plan
        
        Args:
            crop: Name of the crop
            soil_features: Dictionary with soil and environmental features
            
        Returns:
            Formatted prompt string for agent-based planning
        """
        prompt = f"""You are an expert Agricultural Planning Agent. Based on the ML-predicted crop and farm conditions, create a comprehensive, autonomous farming plan.

**CROP TO GROW:** {crop.upper()}

**FARM CONDITIONS (from ML model):**
- Soil Nutrients: N={soil_features['N']} kg/ha, P={soil_features['P']} kg/ha, K={soil_features['K']} kg/ha
- Climate: Temperature={soil_features['temperature']}°C, Humidity={soil_features['humidity']}%, Rainfall={soil_features['rainfall']}mm
- Soil pH: {soil_features['pH']}

**YOUR TASK AS AN AUTONOMOUS AGENT:**
Analyze the conditions and generate a detailed farming plan with:

1. **Seed Selection & Sowing**: Recommend varieties, seed rate, spacing, best sowing method
2. **Step-by-Step Sowing Guide**: Day-by-day activities for first 2 weeks
3. **Irrigation Schedule**: Method, frequency, critical stages, water quantity
4. **Fertilizer Schedule**: NPK applications by growth stage with exact timing
5. **Pest Risk Assessment**: Likely pests for this crop/conditions, prevention strategies
6. **Weekly Monitoring Plan**: What to check each week (12-week schedule)
7. **Harvest Planning**: When to harvest, indicators, post-harvest handling

Return as JSON (NO markdown, NO explanations):
{{
  "seed_selection": {{
    "recommended_varieties": ["variety1", "variety2", "variety3"],
    "seed_rate": "kg/ha",
    "spacing": "row x plant distance",
    "sowing_method": "drilling/broadcasting/transplanting"
  }},
  "sowing_guide": [
    {{"day": 1, "activity": "Land preparation", "details": "specific steps"}},
    {{"day": 2, "activity": "...", "details": "..."}}
  ],
  "irrigation_schedule": {{
    "method": "drip/sprinkler/flood",
    "frequency": "every X days",
    "critical_stages": ["germination", "flowering", "grain filling"],
    "water_requirement": "mm per irrigation"
  }},
  "fertilizer_schedule": [
    {{"stage": "Basal (Day 0)", "N": 0, "P": 0, "K": 0, "application_method": "broadcast and incorporate"}},
    {{"stage": "First top-dressing (Week 3)", "N": 0, "P": 0, "K": 0, "application_method": "side dressing"}},
    {{"stage": "Second top-dressing (Week 6)", "N": 0, "P": 0, "K": 0, "application_method": "foliar/soil"}}
  ],
  "pest_risk_assessment": [
    {{"pest_name": "...", "risk_level": "High/Medium/Low", "symptoms": "...", "prevention": "...", "control_if_found": "..."}}
  ],
  "weekly_monitoring_plan": [
    {{"week": 1, "check_for": ["germination rate", "soil moisture"], "action_if_needed": "..."}}
  ],
  "harvest_planning": {{
    "expected_maturity": "days after sowing",
    "harvest_indicators": ["grain moisture 20%", "yellowing of leaves"],
    "harvest_method": "manual/mechanical",
    "post_harvest": "drying, storage steps"
  }}
}}

**IMPORTANT:** Base recommendations on the actual soil nutrient levels and climate conditions provided. Be specific and actionable."""
        return prompt
    
    def _parse_farming_plan(self, response_text: str, crop: str, 
                           soil_features: Dict[str, float]) -> Dict[str, Any]:
        """
         Parse Gemini response into structured plan
        
        Args:
            response_text: Raw text response from Gemini
            crop: Name of the crop
            soil_features: Soil features for fallback data
            
        Returns:
            Structured farming plan dictionary
        """
        try:
            # Try to extract JSON from response
            # Remove markdown code blocks if present
            text = response_text.strip()
            if text.startswith('```json'):
                text = text[7:]
            if text.startswith('```'):
                text = text[3:]
            if text.endswith('```'):
                text = text[:-3]
            text = text.strip()
            
            # Parse JSON
            plan = json.loads(text)
            
            # Add metadata
            plan['crop'] = crop
            plan['soil_conditions'] = soil_features
            plan['generated_by'] = 'Gemini AI'
            
            return plan
        
        except json.JSONDecodeError:
            # Fallback: return basic plan
            print(" Failed to parse JSON, using fallback plan")
            return self._create_fallback_plan(crop, soil_features)
    
    def _create_fallback_plan(self, crop: str, soil_features: Dict[str, float]) -> Dict[str, Any]:
        """
         Create fallback plan if AI generation fails
        
        Args:
            crop: Name of the crop
            soil_features: Soil and environmental features
            
        Returns:
            Basic farming plan dictionary
        """
        N = soil_features['N']
        P = soil_features['P']
        K = soil_features['K']
        rainfall = soil_features['rainfall']
        
        # Crop-specific maturity periods
        maturity_days = {
            'rice': 120, 'wheat': 110, 'maize': 90, 'cotton': 150,
            'jute': 120, 'coffee': 180, 'tea': 180, 'sugarcane': 300,
            'chickpea': 100, 'kidneybeans': 90, 'pigeonpeas': 120,
            'mothbeans': 75, 'mungbean': 70, 'blackgram': 75,
            'lentil': 110, 'pomegranate': 180, 'banana': 270,
            'mango': 365, 'grapes': 150, 'watermelon': 90,
            'muskmelon': 85, 'apple': 180, 'orange': 270,
            'papaya': 240, 'coconut': 365
        }
        
        days = maturity_days.get(crop.lower(), 100)
        
        # Agent-based comprehensive farming plan (rules-based fallback)
        return {
            'crop': crop,
            'seed_selection': {
                'recommended_varieties': [
                    f'{crop.title()} HYV-1 (High Yielding)', 
                    f'{crop.title()} Disease Resistant-2',
                    f'{crop.title()} Drought Tolerant-3'
                ],
                'seed_rate': f'{10 + (N / 10):.0f} kg/ha',
                'spacing': '45 cm x 20 cm' if crop.lower() in ['rice', 'wheat', 'maize'] else '60 cm x 30 cm',
                'sowing_method': 'Line sowing / Drilling (recommended for better yield)'
            },
            'sowing_guide': [
                {'day': 1, 'activity': 'Land Preparation', 'details': 'Deep plowing to 15-20cm depth, level the field, prepare seedbed'},
                {'day': 3, 'activity': 'Farmyard Manure Application', 'details': f'Apply 10-12 tons/ha of well-decomposed FYM, incorporate into soil'},
                {'day': 5, 'activity': 'Seed Treatment', 'details': 'Treat seeds with fungicide + bio-fertilizer (Azospirillum/Rhizobium)'},
                {'day': 7, 'activity': 'Basal Fertilizer', 'details': f'Apply N={int(N*0.3)} P={int(P*0.5)} K={int(K*0.3)} kg/ha, mix with soil'},
                {'day': 8, 'activity': 'Sowing', 'details': 'Sow seeds at recommended spacing and depth (2-3 cm). Ensure uniform distribution'},
                {'day': 10, 'activity': 'Light Irrigation', 'details': 'Give light irrigation if soil is dry to ensure germination'},
                {'day': 14, 'activity': 'Check Germination', 'details': 'Monitor germination rate (should be >80%). Resow gaps if needed'}
            ],
            'irrigation_schedule': {
                'method': 'Drip irrigation (saves 40% water) or Furrow irrigation',
                'frequency': f'Every {3 if rainfall > 150 else 2} days based on soil moisture',
                'critical_stages': ['Germination (Day 5-10)', 'Tillering/Branching (Week 3-4)', 'Flowering (Week 7-9)', 'Grain filling (Week 10-12)'],
                'water_requirement': f'{max(20, int(60 - (rainfall/4)))} mm per irrigation',
                'notes': f'Monthly rainfall: {rainfall}mm. Adjust based on weather. Use tensiometer for precise irrigation scheduling.'
            },
            'fertilizer_schedule': [
                {'stage': 'Basal (Day 0)', 'N': int(N*0.3), 'P': int(P*0.5), 'K': int(K*0.3), 'application_method': 'Broadcast and incorporate before sowing'},
                {'stage': 'First top-dressing (Week 3)', 'N': int(N*0.4), 'P': int(P*0.3), 'K': int(K*0.3), 'application_method': 'Side dressing along rows, irrigate after application'},
                {'stage': 'Second top-dressing (Week 6)', 'N': int(N*0.3), 'P': int(P*0.2), 'K': int(K*0.4), 'application_method': 'Band placement or foliar spray (if water stress)'},
                {'stage': 'Micronutrients (Week 5)', 'N': 0, 'P': 0, 'K': 0, 'application_method': 'Foliar spray: Zinc sulfate 0.5% + Borax 0.2%'}
            ],
            'pest_risk_assessment': [
                {'pest_name': f'{crop.title()} Stem Borer / Shoot Fly', 'risk_level': 'Medium', 'symptoms': 'Dead hearts, wilting of central shoots', 'prevention': 'Set up pheromone traps @ 20/ha, remove egg masses', 'control_if_found': 'Spray Chlorantraniliprole 0.4ml/L or neem oil 5ml/L'},
                {'pest_name': 'Leaf Spot / Blight', 'risk_level': 'Medium', 'symptoms': 'Brown spots on leaves, yellowing, premature leaf drop', 'prevention': 'Avoid overhead irrigation, ensure air circulation, use disease-free seeds', 'control_if_found': 'Spray Mancozeb 2g/L or Copper oxychloride 3g/L at 10-day interval'},
                {'pest_name': 'Aphids / Thrips / Whitefly', 'risk_level': 'Low', 'symptoms': 'Curling leaves, sticky honeydew, sooty mold', 'prevention': 'Monitor with yellow sticky traps, conserve natural enemies (ladybugs)', 'control_if_found': 'Spray Imidacloprid 0.5ml/L or neem oil 5ml/L + sticker'},
                {'pest_name': 'Root Rot / Wilt', 'risk_level': 'Low-Medium', 'symptoms': 'Wilting despite adequate moisture, yellowing, stunted growth', 'prevention': 'Improve drainage, avoid waterlogging, seed treatment with Trichoderma', 'control_if_found': 'Drench soil with Carbendazim 1g/L, improve soil aeration'}
            ],
            'weekly_monitoring_plan': [
                {'week': 1, 'check_for': ['Germination rate (should be >80%)', 'Soil crusting', 'Cutworm damage'], 'action_if_needed': 'Resow gaps, break crust, apply soil insecticide'},
                {'week': 2, 'check_for': ['Seedling vigor', 'Soil moisture', 'Early pest infestation'], 'action_if_needed': 'Thin seedlings if overcrowded, irrigate if dry, spray if pests found'},
                {'week': 3, 'check_for': ['Plant height', 'Leaf color (should be dark green)', 'First top-dressing timing'], 'action_if_needed': 'Apply first fertilizer dose, check for nutrient deficiency'},
                {'week': 4, 'check_for': ['Tillering/Branching', 'Weed competition', 'Moisture stress'], 'action_if_needed': 'First weeding (manual/chemical), irrigate critical stage'},
                {'week': 5, 'check_for': ['Nutrient deficiency symptoms', 'Pest trap catches', 'Disease spots'], 'action_if_needed': 'Foliar micronutrient spray, take preventive pest measures'},
                {'week': 6, 'check_for': ['Canopy development', 'Second fertilizer timing', 'Lodging risk'], 'action_if_needed': 'Apply second fertilizer dose, provide support if needed'},
                {'week': 7, 'check_for': ['Flowering initiation', 'Water stress (critical!)', 'Pollination'], 'action_if_needed': 'Ensure adequate moisture, avoid stress during flowering'},
                {'week': 8, 'check_for': ['Fruit/Grain set', 'Late-season pests', 'Nutrient sufficiency'], 'action_if_needed': 'Continue irrigation, monitor closely, spray if needed'},
                {'week': 9, 'check_for': ['Grain/Fruit filling', 'Lodging', 'Bird damage risk'], 'action_if_needed': 'Support lodged plants, set up bird scarers'},
                {'week': 10, 'check_for': ['Maturity progress', 'Moisture content', 'Harvest preparation'], 'action_if_needed': 'Plan harvest timing, arrange labor/machinery'},
                {'week': 11, 'check_for': ['Final maturity signs', 'Weather forecast (avoid rain at harvest)', 'Market prices'], 'action_if_needed': 'Monitor market, finalize harvest date'},
                {'week': 12, 'check_for': ['Optimal harvest window', 'Moisture content (14-16% for grains)', 'Storage readiness'], 'action_if_needed': 'Harvest, dry, clean, store properly'}
            ],
            'harvest_planning': {
                'expected_maturity': f'{days} days after sowing',
                'harvest_indicators': [
                    'Grain moisture content: 20-22% (for combine harvesting) or 16-18% (for manual)',
                    'Yellowing and drying of leaves (80-90% of plants)',
                    'Hard dough stage / Physiological maturity',
                    'Panicles/Pods drooping down'
                ],
                'harvest_method': 'Combine harvester (for large scale >5 ha) or Manual reaping + threshing',
                'post_harvest': 'Sun-dry to 12-14% moisture, clean, grade, store in moisture-proof bags with rodent control. Consider hermetic storage for long-term.'
            },
            'generated_by': 'Rules-based Autonomous Agent',
            'note': '🤖 This comprehensive plan was generated by an autonomous farming agent using agricultural best practices. Adjust based on local conditions and expert advice.'
        }
    
    def generate_market_insights(self, crop: str) -> Dict[str, Any]:
        """
         Generate market insights and trends for a crop
        
        Args:
            crop: Name of the crop
            
        Returns:
            Dictionary with market insights
        """
        try:
            prompt = f"""Market insights for {crop.upper()} in India as JSON only:
{{
  "current_price_range": "₹X-Y/quintal",
  "demand_trend": "Increasing/Stable/Decreasing",
  "best_markets": ["market1", "market2"],
  "export_potential": "High/Medium/Low",
  "insights": "Brief analysis"
}}
Return JSON only, NO other text."""
            
            response = self.model.generate_content(prompt)
            
            # Parse response
            text = response.text.strip()
            if text.startswith('```json'):
                text = text[7:]
            if text.startswith('```'):
                text = text[3:]
            if text.endswith('```'):
                text = text[:-3]
            text = text.strip()
            
            insights = json.loads(text)
            return insights
        
        except Exception as e:
            error_msg = str(e)
            if '429' in error_msg or 'quota' in error_msg.lower():
                print(f" Market insights skipped: API quota exceeded")
            return {
                'error': str(e),
                'message': 'Failed to generate market insights'
            }


if __name__ == "__main__":
    # Test AI Farming Planner
    print(" Testing AI Farming Planner...\n")
    
    try:
        planner = AIFarmingPlanner()
        
        # Sample soil data
        soil_data = {
            'N': 90,
            'P': 42,
            'K': 43,
            'temperature': 20.5,
            'humidity': 82.0,
            'pH': 6.5,
            'rainfall': 202.0
        }
        
        print(" Generating farming plan for RICE...")
        plan = planner.generate_plan('rice', soil_data)
        
        if 'error' not in plan:
            print("\n Plan generated successfully!")
            print(f"\n Seed Varieties: {', '.join(plan.get('seed_varieties', [])[:3])}")
            print(f"\n Irrigation: {plan.get('irrigation_plan', {}).get('method', 'N/A')}")
            print(f"\n Pest Risks: {len(plan.get('pest_risks', []))} identified")
        else:
            print(f"\n Error: {plan['error']}")
    
    except Exception as e:
        print(f"\n Test failed: {str(e)}")
        print(" Make sure GEMINI_API_KEY is set in .env file")
