

import pickle
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Any
import os


class CropRecommender:
    
    
    def __init__(self, model_path: str = 'crop_model.pkl', yield_model_path: str = 'yield_model.pkl'):
        """
        Initialize the recommender with a trained model
        
        Args:
            model_path: Path to the trained crop classification model
            yield_model_path: Path to the trained yield regression model
        """
        self.model_path = model_path
        self.yield_model_path = yield_model_path
        self.model = None
        self.feature_names = None
        self.model_name = None
        self.accuracy = None
        self.crop_yield_map = None
        self.yield_model = None
        self.yield_feature_cols = None
        self.yield_label_encoder = None
        self.load_model()
        self.load_yield_model()
    
    def load_model(self):
        """Load the trained model from disk"""
        if not os.path.exists(self.model_path):
            raise FileNotFoundError(
                f" Model file not found: {self.model_path}\n"
                f"Please train the model first using: python enhanced_train.py"
            )
        
        try:
            with open(self.model_path, 'rb') as f:
                model_data = pickle.load(f)
            
            self.model = model_data['model']
            self.feature_names = model_data['feature_names']
            self.model_name = model_data['model_name']
            self.accuracy = model_data['accuracy']
            self.crop_yield_map = model_data.get('crop_yield_map', {})
            self.feature_selector = model_data.get('feature_selector', None)
            
            print(f" Loaded {self.model_name} model with {self.accuracy*100:.2f}% accuracy")
            print(f" Features: {len(self.feature_names)} selected features")
        
        except Exception as e:
            raise RuntimeError(f" Error loading model: {str(e)}")
    
    def load_yield_model(self):
        """Load the ML-based yield prediction model"""
        if not os.path.exists(self.yield_model_path):
            print(f" ML yield model not found: {self.yield_model_path}")
            print("   Using fallback rule-based yield estimation")
            self.yield_model = None
            return
        
        try:
            with open(self.yield_model_path, 'rb') as f:
                yield_data = pickle.load(f)
            
            self.yield_model = yield_data['model']
            self.yield_feature_cols = yield_data['feature_columns']
            self.yield_label_encoder = yield_data['label_encoder']
            
            r2_score = yield_data.get('r2_score', 0)
            rmse = yield_data.get('rmse', 0)
            
            print(f" Loaded ML yield model: {yield_data.get('model_name', 'Unknown')}")
            print(f"   R² Score: {r2_score:.4f}, RMSE: {rmse:.2f} q/ha")
        
        except Exception as e:
            print(f"  Error loading yield model: {str(e)}")
            print("   Using fallback rule-based yield estimation")
            self.yield_model = None
    
    def _engineer_features(self, soil_features: Dict[str, float]) -> Dict[str, float]:
        """
         Engineer comprehensive features matching enhanced training
        
        Creates advanced features from basic soil inputs:
        - NPK ratios and interactions
        - Climate indices and stress factors
        - Fertility scores and balance metrics
        - Polynomial and interaction features
        
        Args:
            soil_features: Dictionary with N, P, K, temperature, humidity, pH, rainfall
            
        Returns:
            Dictionary with engineered features
        """
        # Extract base features
        N = soil_features.get('N', soil_features.get('n', 0))
        P = soil_features.get('P', soil_features.get('p', 0))
        K = soil_features.get('K', soil_features.get('k', 0))
        temp = soil_features.get('temperature', 0)
        humidity = soil_features.get('humidity', 0)
        pH = soil_features.get('pH', soil_features.get('ph', 0))
        rainfall = soil_features.get('rainfall', 0)
        
        # Start with base features (using uppercase to match model)
        features = {
            'N': N, 'P': P, 'K': K,
            'temperature': temp, 'humidity': humidity, 'pH': pH, 'rainfall': rainfall
        }
        
        # Enhanced feature engineering (matching enhanced_train.py)
        features['NPK_sum'] = N + P + K
        features['N_P_ratio'] = N / (P + 1e-6)
        features['N_K_ratio'] = N / (K + 1e-6)
        features['P_K_ratio'] = P / (K + 1e-6)
        
        # Climate indices
        features['temp_humidity_index'] = temp * humidity / 100
        features['water_stress_index'] = rainfall / (temp + 1)
        
        # Soil fertility indicators
        features['soil_fertility_score'] = (N + P + K) / 3
        features['NPK_balance'] = np.std([N, P, K])
        
        # Environmental stress factors
        features['heat_stress'] = 1 if temp > 35 else 0
        features['moisture_deficit'] = 1 if humidity < 40 else 0
        features['nutrient_deficiency'] = 1 if (N < 50) or (P < 30) or (K < 30) else 0
        
        # Polynomial features
        features['temp_squared'] = temp ** 2
        features['humidity_squared'] = humidity ** 2
        features['rainfall_squared'] = rainfall ** 2
        features['pH_squared'] = pH ** 2
        
        # Interaction features
        features['temp_rainfall_interaction'] = temp * rainfall / 100
        features['pH_nutrient_interaction'] = pH * features['soil_fertility_score']
        features['climate_stress'] = features['heat_stress'] + features['moisture_deficit']
        
        # Advanced ratios
        features['nutrient_density'] = features['NPK_sum'] / (pH + 1)
        features['growth_potential'] = (features['soil_fertility_score'] * features['temp_humidity_index']) / (features['climate_stress'] + 1)
        
        return features
    
    def predict_crop(self, soil_features: Dict[str, float]) -> Dict[str, Any]:
        """
         Predict the best crop for given soil conditions
        
        Args:
            soil_features: Dictionary with N, P, K, temperature, humidity, pH, rainfall
            
        Returns:
            Dictionary with recommended crop, confidence, and alternatives
        """
        # Engineer comprehensive features
        all_features = self._engineer_features(soil_features)
        
        # Create feature vector with ALL engineered features
        all_feature_names = [
            'N', 'P', 'K', 'temperature', 'humidity', 'pH', 'rainfall',
            'NPK_sum', 'N_P_ratio', 'N_K_ratio', 'P_K_ratio',
            'temp_humidity_index', 'water_stress_index', 'soil_fertility_score',
            'NPK_balance', 'heat_stress', 'moisture_deficit', 'nutrient_deficiency',
            'temp_squared', 'humidity_squared', 'rainfall_squared', 'pH_squared',
            'temp_rainfall_interaction', 'pH_nutrient_interaction', 'climate_stress',
            'nutrient_density', 'growth_potential'
        ]
        
        # Create feature vector with all features
        X_full = np.array([[all_features[name] for name in all_feature_names]])
        
        # Apply feature selection if model has selector
        if hasattr(self, 'feature_selector') and self.feature_selector is not None:
            X = self.feature_selector.transform(X_full)
        else:
            # Fallback: use features in order of model's feature_names
            X = np.array([[all_features[name] for name in self.feature_names]])
        
        # Get prediction and probabilities
        prediction = self.model.predict(X)[0]
        # Extract string from array if needed
        if isinstance(prediction, np.ndarray):
            prediction = prediction[0]
        probabilities = self.model.predict_proba(X)[0]
        
        # Get confidence (probability of predicted class)
        predicted_class_idx = list(self.model.classes_).index(prediction)
        confidence = probabilities[predicted_class_idx] * 100
        
        # Get top 5 alternative crops
        top_indices = np.argsort(probabilities)[-6:][::-1]
        alternatives = []
        for idx in top_indices[1:]:  # Skip first (main prediction)
            crop_name = self.model.classes_[idx]
            crop_confidence = probabilities[idx] * 100
            alternatives.append({
                'crop': crop_name,
                'confidence': crop_confidence
            })
        
        return {
            'recommended_crop': prediction,
            'confidence': confidence,
            'alternatives': alternatives,
            'features_used': all_features
        }
    
    def predict_yield(self, crop: str, soil_features: Dict[str, float]) -> float:
        """
         ML-Based Yield Prediction with fallback
        
        Uses trained regression model to predict crop yield based on:
        - Soil nutrients (N, P, K)
        - Climate conditions (temperature, humidity, rainfall)
        - Soil pH
        - Crop type
        
        Falls back to rule-based estimation if ML model not available
        
        Args:
            crop: Name of the crop
            soil_features: Dictionary with soil and environmental features
            
        Returns:
            Estimated yield in quintals per hectare
        """
        # Extract string from array if needed
        if isinstance(crop, np.ndarray):
            crop = crop[0]
        
        crop = crop.lower()
        
        # Try ML-based prediction first
        if self.yield_model is not None and self.yield_label_encoder is not None:
            try:
                return self._predict_yield_ml(crop, soil_features)
            except Exception as e:
                print(f" ML yield prediction failed: {e}, using fallback")
        
        # Fallback to rule-based estimation
        return self._predict_yield_fallback(crop, soil_features)
    
    def _predict_yield_ml(self, crop: str, soil_features: Dict[str, float]) -> float:
        """ML-based yield prediction"""
        
        # Check if crop is in encoder
        if crop not in self.yield_label_encoder.classes_:
            raise ValueError(f"Crop '{crop}' not in yield model")
        
        # Create feature DataFrame
        feature_dict = {
            'N': soil_features.get('N', soil_features.get('n', 0)),
            'P': soil_features.get('P', soil_features.get('p', 0)),
            'K': soil_features.get('K', soil_features.get('k', 0)),
            'temperature': soil_features.get('temperature', 0),
            'humidity': soil_features.get('humidity', 0),
            'pH': soil_features.get('pH', soil_features.get('ph', 0)),
            'rainfall': soil_features.get('rainfall', 0)
        }
        
        # Engineer features for yield model
        test_df = pd.DataFrame([feature_dict])
        
        # Add NPK ratios
        test_df['NPK_sum'] = test_df['N'] + test_df['P'] + test_df['K']
        test_df['N_P_ratio'] = test_df['N'] / (test_df['P'] + 1e-6)
        test_df['N_K_ratio'] = test_df['N'] / (test_df['K'] + 1e-6)
        test_df['P_K_ratio'] = test_df['P'] / (test_df['K'] + 1e-6)
        
        # Climate indices
        test_df['temp_humidity_index'] = test_df['temperature'] * test_df['humidity'] / 100
        test_df['water_availability'] = test_df['rainfall'] / (test_df['temperature'] + 1)
        
        # Soil fertility
        test_df['soil_fertility_score'] = (test_df['N'] + test_df['P'] + test_df['K']) / 3
        test_df['nutrient_balance'] = test_df[['N', 'P', 'K']].std(axis=1)
        
        # Stress indicators
        test_df['heat_stress'] = (test_df['temperature'] > 35).astype(int)
        test_df['moisture_deficit'] = (test_df['humidity'] < 40).astype(int)
        test_df['pH_stress'] = ((test_df['pH'] < 5.5) | (test_df['pH'] > 8.0)).astype(int)
        
        # Interaction features
        test_df['nutrient_climate_interaction'] = (test_df['soil_fertility_score'] * 
                                                   test_df['temp_humidity_index'] / 100)
        test_df['water_stress_index'] = test_df['rainfall'] * test_df['humidity'] / 100
        
        # Add crop encoding
        test_df['crop_encoded'] = self.yield_label_encoder.transform([crop])
        
        # Select only features used in training
        X_test = test_df[self.yield_feature_cols]
        
        # Predict
        predicted_yield = self.yield_model.predict(X_test)[0]
        
        # Sanity check: Ensure prediction is within reasonable bounds for this crop
        # Load crop-specific yield ranges
        try:
            dataset_path = os.path.join(os.path.dirname(__file__), '..', 'training_scripts', 'crop_yield_dataset.csv')
            if not os.path.exists(dataset_path):
                dataset_path = 'training_scripts/crop_yield_dataset.csv'
            
            if os.path.exists(dataset_path):
                crop_yield_data = pd.read_csv(dataset_path)
                crop_specific = crop_yield_data[crop_yield_data['crop'].str.lower() == crop.lower()]
                
                if len(crop_specific) > 0:
                    crop_max = crop_specific['yield'].max() * 1.1  # Allow 10% beyond historical max
                    crop_min = crop_specific['yield'].min() * 0.9  # Allow 10% below historical min
                    
                    # Clamp prediction to reasonable range
                    if predicted_yield > crop_max:
                        print(f"  Warning: Predicted yield {predicted_yield:.1f} exceeds {crop} maximum {crop_max:.1f}, capping to {crop_max:.1f}")
                        predicted_yield = crop_max
                    elif predicted_yield < crop_min:
                        predicted_yield = crop_min
        except Exception as e:
            # If validation fails, just use the prediction as-is
            pass
        
        return round(max(0, predicted_yield), 2)  # Ensure non-negative
    
    def _predict_yield_fallback(self, crop: str, soil_features: Dict[str, float]) -> float:
        """Rule-based yield estimation (fallback)"""
        
        # Base yield from crop yield map
        base_yield = self.crop_yield_map.get(crop, 50.0)
        
        # Adjust based on soil conditions
        all_features = self._engineer_features(soil_features)
        
        # Fertility adjustment
        fertility_score = all_features['soil_fertility_score']
        fertility_factor = min(1.5, max(0.5, fertility_score / 100))
        
        # Climate adjustment
        temp_factor = 1.0
        if all_features['heat_stress'] > 0:
            temp_factor = max(0.6, 1.0 - (all_features['heat_stress'] / 20))
        
        moisture_factor = 1.0
        if all_features['moisture_deficit'] > 0:
            moisture_factor = max(0.7, 1.0 - (all_features['moisture_deficit'] / 100))
        
        # Calculate adjusted yield
        estimated_yield = base_yield * fertility_factor * temp_factor * moisture_factor
        
        return round(estimated_yield, 2)
    
    def get_top_crops(self, soil_features: Dict[str, float], n: int = 3) -> List[Dict[str, Any]]:
        """
         Get top N crop recommendations with confidence and yield
        
        Args:
            soil_features: Dictionary with soil and environmental features
            n: Number of top crops to return
            
        Returns:
            List of dictionaries with crop, confidence, and estimated yield
        """
        # Engineer features
        all_features = self._engineer_features(soil_features)
        X = np.array([[all_features[name] for name in self.feature_names]])
        
        # Get probabilities
        probabilities = self.model.predict_proba(X)[0]
        
        # Sort crops by probability
        top_indices = np.argsort(probabilities)[-n:][::-1]
        
        top_crops = []
        for idx in top_indices:
            crop_name = self.model.classes_[idx]
            crop_confidence = probabilities[idx] * 100
            estimated_yield = self.predict_yield(crop_name, soil_features)
            
            top_crops.append({
                'crop': crop_name,
                'confidence': crop_confidence,
                'estimated_yield': estimated_yield
            })
        
        return top_crops
    
    def get_feature_importance(self, crop: str, soil_features: Dict[str, float]) -> Dict[str, Any]:
        """
         Get feature importance for explainability
        
        Args:
            crop: Name of the crop
            soil_features: Dictionary with soil and environmental features
            
        Returns:
            Dictionary with feature importance and explanations
        """
        # Engineer features
        all_features = self._engineer_features(soil_features)
        
        # Get feature importances from model
        if hasattr(self.model, 'feature_importances_'):
            importances = self.model.feature_importances_
        else:
            # For models without feature_importances_ attribute
            importances = np.ones(len(self.feature_names)) / len(self.feature_names)
        
        # Normalize importances to sum to 100%
        total_importance = np.sum(importances)
        if total_importance > 0:
            normalized_importances = (importances / total_importance) * 100
        else:
            normalized_importances = importances * 100
        
        # Create feature importance dictionary
        feature_importance = {}
        for name, importance in zip(self.feature_names, normalized_importances):
            feature_importance[name] = round(importance, 2)
        
        # Sort by importance
        sorted_features = sorted(feature_importance.items(), key=lambda x: x[1], reverse=True)
        
        # Import explainability module for detailed explanations
        try:
            from explainability import generate_feature_explanations
            explanations = generate_feature_explanations(
                dict(sorted_features[:10]),
                all_features,
                crop
            )
        except ImportError:
            # Fallback: basic explanations without reasons
            explanations = []
            for feature_name, importance in sorted_features[:10]:
                explanations.append({
                    'feature': feature_name,
                    'value': round(all_features[feature_name], 2),
                    'importance': importance,
                    'reason': f'Contributes {importance:.1f}% to {crop} prediction'
                })
        
        return {
            'feature_importance': dict(sorted_features[:10]),
            'explanations': explanations,
            'crop': crop
        }
    
    def simulate_what_if(self, soil_features: Dict[str, float], 
                        modifications: Dict[str, float]) -> Dict[str, Any]:
        """
         Simulate what-if scenarios by modifying soil parameters
        
        Args:
            soil_features: Original soil features
            modifications: Dictionary with features to modify and their new values
            
        Returns:
            Dictionary comparing current vs modified predictions
        """
        # Get current prediction
        current_prediction = self.predict_crop(soil_features)
        current_crop = current_prediction['recommended_crop']
        current_confidence = current_prediction['confidence']
        current_yield = self.predict_yield(current_crop, soil_features)
        current_top_crops = self.get_top_crops(soil_features, 3)
        
        # Apply modifications
        modified_features = soil_features.copy()
        modified_features.update(modifications)
        
        # Get modified prediction
        modified_prediction = self.predict_crop(modified_features)
        modified_crop = modified_prediction['recommended_crop']
        modified_confidence = modified_prediction['confidence']
        modified_yield = self.predict_yield(modified_crop, modified_features)
        modified_top_crops = self.get_top_crops(modified_features, 3)
        
        # Calculate changes
        crop_changed = current_crop != modified_crop
        confidence_change = modified_confidence - current_confidence
        yield_change = modified_yield - current_yield
        yield_change_percent = (yield_change / current_yield) * 100 if current_yield > 0 else 0
        
        # Generate recommendation
        if crop_changed:
            recommendation = f" Modifying soil conditions changes the recommended crop from {current_crop} to {modified_crop}."
        elif yield_change > 0:
            recommendation = f" The modifications improve yield by {yield_change:.1f} q/ha ({yield_change_percent:+.1f}%) for {current_crop}."
        elif yield_change < 0:
            recommendation = f" The modifications decrease yield by {abs(yield_change):.1f} q/ha ({yield_change_percent:.1f}%) for {current_crop}."
        else:
            recommendation = f"The modifications have minimal impact on {current_crop} yield."
        
        return {
            'current': {
                'crop': current_crop,
                'confidence': current_confidence,
                'yield': current_yield,
                'top_crops': current_top_crops
            },
            'modified': {
                'crop': modified_crop,
                'confidence': modified_confidence,
                'yield': modified_yield,
                'top_crops': modified_top_crops
            },
            'changes': {
                'crop_changed': crop_changed,
                'confidence_change': confidence_change,
                'yield_change': yield_change,
                'yield_change_percent': yield_change_percent
            },
            'modifications': modifications,
            'recommendation': recommendation
        }


    def get_optimal_conditions(self, crop: str, method: str = 'ml') -> Dict[str, Any]:
        """
        Get optimal soil and climate conditions for maximum yield of a given crop
        
        Args:
            crop: Name of the crop (e.g., 'rice', 'wheat', 'maize')
            method: 'ml' for ML-based optimization, 'statistical' for top performers analysis
        
        Returns:
            Dictionary with optimal conditions and expected maximum yield
        """
        crop = crop.lower().strip()
        
        # Load training data to find realistic ranges
        try:
            df = pd.read_csv('../training_scripts/crop_yield_dataset.csv')
        except:
            try:
                df = pd.read_csv('training_scripts/crop_yield_dataset.csv')
            except:
                # Return generic optimal conditions if data not available
                return self._get_generic_optimal_conditions(crop)
        
        # Filter data for the specific crop
        crop_data = df[df['crop'].str.lower() == crop]
        
        if crop_data.empty:
            return {
                'error': f"Crop '{crop}' not found in database",
                'available_crops': sorted(df['crop'].str.lower().unique().tolist())
            }
        
        if method == 'ml':
            return self._get_ml_optimized_conditions(crop, crop_data)
        else:
            return self._get_statistical_optimal_conditions(crop, crop_data)
    
    def _get_ml_optimized_conditions(self, crop: str, crop_data: pd.DataFrame) -> Dict[str, Any]:
        """
        Use ML model with grid search to find optimal conditions for maximum yield
        """
        from scipy.optimize import differential_evolution
        
        # Define realistic bounds for each parameter (1st to 99th percentile for comprehensive search)
        param_bounds = {
            'N': (crop_data['N'].quantile(0.01), crop_data['N'].quantile(0.99)),
            'P': (crop_data['P'].quantile(0.01), crop_data['P'].quantile(0.99)),
            'K': (crop_data['K'].quantile(0.01), crop_data['K'].quantile(0.99)),
            'temperature': (crop_data['temperature'].quantile(0.01), crop_data['temperature'].quantile(0.99)),
            'humidity': (crop_data['humidity'].quantile(0.01), crop_data['humidity'].quantile(0.99)),
            'pH': (crop_data['pH'].quantile(0.01), crop_data['pH'].quantile(0.99)),
            'rainfall': (crop_data['rainfall'].quantile(0.01), crop_data['rainfall'].quantile(0.99))
        }
        
        # Define objective function to maximize yield (minimize negative yield)
        def objective(params):
            soil_features = {
                'N': params[0],
                'P': params[1],
                'K': params[2],
                'temperature': params[3],
                'humidity': params[4],
                'pH': params[5],
                'rainfall': params[6]
            }
            predicted_yield = self.predict_yield(crop, soil_features)
            return -predicted_yield  # Negative because we minimize
        
        # Grid search with multiple starting points for robustness
        best_yield = -float('inf')
        best_params = None
        
        print(f" Running ML optimization for {crop}...")
        
        # Create bounds array for optimizer
        bounds = [
            param_bounds['N'],
            param_bounds['P'],
            param_bounds['K'],
            param_bounds['temperature'],
            param_bounds['humidity'],
            param_bounds['pH'],
            param_bounds['rainfall']
        ]
        
        # Use differential evolution for global optimization (optimized for speed)
        result = differential_evolution(
            objective,
            bounds,
            maxiter=50,
            popsize=10,
            seed=42,
            workers=1,
            tol=0.05,
            atol=0.05,
            polish=False
        )
        
        best_params = result.x
        best_yield = -result.fun
        
        print(f" ML optimization complete. Predicted max yield: {best_yield:.1f} q/ha")
        
        # Also get statistical baseline from top 10%
        top_percentile = crop_data.nlargest(int(len(crop_data) * 0.1), 'yield')
        
        # Build result with ML-optimized conditions
        optimal_conditions = {
            'crop': crop.title(),
            'method': 'ML-based Optimization',
            'maximum_recorded_yield': float(crop_data['yield'].max()),
            'average_yield': float(crop_data['yield'].mean()),
            'top_10_percent_yield': float(top_percentile['yield'].mean()),
            'ml_predicted_max_yield': float(best_yield),
            'optimal_conditions': {
                'N': {
                    'optimal': float(best_params[0]),
                    'min': float(param_bounds['N'][0]),
                    'max': float(param_bounds['N'][1]),
                    'unit': 'kg/ha',
                    'source': 'ML Optimized'
                },
                'P': {
                    'optimal': float(best_params[1]),
                    'min': float(param_bounds['P'][0]),
                    'max': float(param_bounds['P'][1]),
                    'unit': 'kg/ha',
                    'source': 'ML Optimized'
                },
                'K': {
                    'optimal': float(best_params[2]),
                    'min': float(param_bounds['K'][0]),
                    'max': float(param_bounds['K'][1]),
                    'unit': 'kg/ha',
                    'source': 'ML Optimized'
                },
                'temperature': {
                    'optimal': float(best_params[3]),
                    'min': float(param_bounds['temperature'][0]),
                    'max': float(param_bounds['temperature'][1]),
                    'unit': '°C',
                    'source': 'ML Optimized'
                },
                'humidity': {
                    'optimal': float(best_params[4]),
                    'min': float(param_bounds['humidity'][0]),
                    'max': float(param_bounds['humidity'][1]),
                    'unit': '%',
                    'source': 'ML Optimized'
                },
                'pH': {
                    'optimal': float(best_params[5]),
                    'min': float(param_bounds['pH'][0]),
                    'max': float(param_bounds['pH'][1]),
                    'unit': 'pH scale',
                    'source': 'ML Optimized'
                },
                'rainfall': {
                    'optimal': float(best_params[6]),
                    'min': float(param_bounds['rainfall'][0]),
                    'max': float(param_bounds['rainfall'][1]),
                    'unit': 'mm/month',
                    'source': 'ML Optimized'
                }
            },
            'total_samples': len(crop_data),
            'recommendation': f"ML model predicts maximum yield of {best_yield:.1f} q/ha with optimized conditions. Historical top 10% achieved {top_percentile['yield'].mean():.1f} q/ha."
        }
        
        return optimal_conditions
    
    def _get_statistical_optimal_conditions(self, crop: str, crop_data: pd.DataFrame) -> Dict[str, Any]:
        """
        Statistical analysis: Find conditions from top 10% highest yielding samples
        """
        # Find top 10% highest yielding samples for this crop
        top_percentile = crop_data.nlargest(int(len(crop_data) * 0.1), 'yield')
        
        # Calculate optimal ranges from top performers
        optimal_conditions = {
            'crop': crop.title(),
            'method': 'Statistical Analysis (Top 10%)',
            'maximum_recorded_yield': float(crop_data['yield'].max()),
            'average_yield': float(crop_data['yield'].mean()),
            'top_10_percent_yield': float(top_percentile['yield'].mean()),
            'optimal_conditions': {
                'N': {
                    'min': float(top_percentile['N'].quantile(0.25)),
                    'optimal': float(top_percentile['N'].median()),
                    'max': float(top_percentile['N'].quantile(0.75)),
                    'unit': 'kg/ha',
                    'source': 'Top 10% Median'
                },
                'P': {
                    'min': float(top_percentile['P'].quantile(0.25)),
                    'optimal': float(top_percentile['P'].median()),
                    'max': float(top_percentile['P'].quantile(0.75)),
                    'unit': 'kg/ha',
                    'source': 'Top 10% Median'
                },
                'K': {
                    'min': float(top_percentile['K'].quantile(0.25)),
                    'optimal': float(top_percentile['K'].median()),
                    'max': float(top_percentile['K'].quantile(0.75)),
                    'unit': 'kg/ha',
                    'source': 'Top 10% Median'
                },
                'temperature': {
                    'min': float(top_percentile['temperature'].quantile(0.25)),
                    'optimal': float(top_percentile['temperature'].median()),
                    'max': float(top_percentile['temperature'].quantile(0.75)),
                    'unit': '°C',
                    'source': 'Top 10% Median'
                },
                'humidity': {
                    'min': float(top_percentile['humidity'].quantile(0.25)),
                    'optimal': float(top_percentile['humidity'].median()),
                    'max': float(top_percentile['humidity'].quantile(0.75)),
                    'unit': '%',
                    'source': 'Top 10% Median'
                },
                'pH': {
                    'min': float(top_percentile['pH'].quantile(0.25)),
                    'optimal': float(top_percentile['pH'].median()),
                    'max': float(top_percentile['pH'].quantile(0.75)),
                    'unit': 'pH scale',
                    'source': 'Top 10% Median'
                },
                'rainfall': {
                    'min': float(top_percentile['rainfall'].quantile(0.25)),
                    'optimal': float(top_percentile['rainfall'].median()),
                    'max': float(top_percentile['rainfall'].quantile(0.75)),
                    'unit': 'mm/month',
                    'source': 'Top 10% Median'
                }
            },
            'total_samples': len(crop_data),
            'recommendation': f"For maximum {crop} yield, maintain conditions within the optimal range. The top 10% performers achieved {top_percentile['yield'].mean():.1f} q/ha on average."
        }
        
        # Test the optimal conditions with the yield model
        optimal_soil = {
            'N': optimal_conditions['optimal_conditions']['N']['optimal'],
            'P': optimal_conditions['optimal_conditions']['P']['optimal'],
            'K': optimal_conditions['optimal_conditions']['K']['optimal'],
            'temperature': optimal_conditions['optimal_conditions']['temperature']['optimal'],
            'humidity': optimal_conditions['optimal_conditions']['humidity']['optimal'],
            'pH': optimal_conditions['optimal_conditions']['pH']['optimal'],
            'rainfall': optimal_conditions['optimal_conditions']['rainfall']['optimal']
        }
        
        predicted_yield = self.predict_yield(crop, optimal_soil)
        optimal_conditions['predicted_max_yield'] = predicted_yield
        
        return optimal_conditions
    
    def _get_generic_optimal_conditions(self, crop: str) -> Dict[str, Any]:
        """Fallback generic optimal conditions if data is not available"""
        generic_conditions = {
            'rice': {'N': (80, 100), 'P': (40, 60), 'K': (40, 60), 'temp': (25, 30), 'humidity': (70, 85), 'pH': (6.0, 7.0), 'rainfall': (150, 250)},
            'wheat': {'N': (100, 120), 'P': (50, 70), 'K': (50, 70), 'temp': (20, 25), 'humidity': (50, 70), 'pH': (6.0, 7.5), 'rainfall': (50, 100)},
            'maize': {'N': (80, 120), 'P': (40, 60), 'K': (40, 60), 'temp': (25, 30), 'humidity': (60, 80), 'pH': (5.5, 7.0), 'rainfall': (80, 150)},
        }
        
        conditions = generic_conditions.get(crop, {
            'N': (70, 100), 'P': (40, 60), 'K': (40, 60), 
            'temp': (20, 30), 'humidity': (60, 80), 
            'pH': (6.0, 7.0), 'rainfall': (100, 200)
        })
        
        return {
            'crop': crop.title(),
            'optimal_conditions': {
                key: {'min': val[0], 'optimal': (val[0] + val[1]) / 2, 'max': val[1]}
                for key, val in conditions.items()
            },
            'note': 'Generic optimal conditions (training data not available)'
        }


if __name__ == "__main__":
    # Test the recommender
    print(" Testing Crop Recommender...\n")
    
    recommender = CropRecommender()
    
    # Sample soil data
    soil_data = {
        'N': 90,
        'P': 42,
        'K': 43,
        'temperature': 20.5,
        'humidity': 82.0,
        'pH': 6.5,
        'rainfall': 202.0
    }
    
    print(" Soil Features:")
    for key, value in soil_data.items():
        print(f"  {key}: {value}")
    
    # Get prediction
    print("\n Prediction:")
    result = recommender.predict_crop(soil_data)
    print(f"  Recommended Crop: {result['recommended_crop']}")
    print(f"  Confidence: {result['confidence']:.2f}%")
    
    # Get yield estimate
    yield_estimate = recommender.predict_yield(result['recommended_crop'], soil_data)
    print(f"  Estimated Yield: {yield_estimate:.1f} q/ha")
    
    # Get alternatives
    print("\n🌿 Alternative Crops:")
    for i, alt in enumerate(result['alternatives'][:3], 1):
        yield_est = recommender.predict_yield(alt['crop'], soil_data)
        print(f"  {i}. {alt['crop']} - {alt['confidence']:.2f}% ({yield_est:.1f} q/ha)")
    
    print("\n Test completed!")
