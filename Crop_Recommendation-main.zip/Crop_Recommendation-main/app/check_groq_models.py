"""
Check which Groq models are currently available
"""

import os
from dotenv import load_dotenv
from groq import Groq

load_dotenv()

groq_key = os.getenv('GROQ_API_KEY')

if not groq_key:
    print("❌ GROQ_API_KEY not found")
    exit(1)

print("🔍 Checking available Groq models...")
print("="*60)

client = Groq(api_key=groq_key)

# Test different models
models_to_test = [
    "llama-3.3-70b-versatile",
    "llama-3.1-70b-versatile", 
    "llama-3.1-8b-instant",
    "llama3-70b-8192",
    "llama3-8b-8192",
    "mixtral-8x7b-32768",
    "gemma2-9b-it",
]

working_models = []

for model in models_to_test:
    try:
        response = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": "Hi"}],
            max_tokens=5
        )
        print(f"✅ {model} - WORKING")
        working_models.append(model)
    except Exception as e:
        error_msg = str(e)
        if "decommissioned" in error_msg.lower():
            print(f"❌ {model} - DECOMMISSIONED")
        elif "does not exist" in error_msg.lower():
            print(f"❌ {model} - NOT FOUND")
        else:
            print(f"⚠️  {model} - ERROR: {error_msg[:50]}")

print("\n" + "="*60)
print(f"✅ Found {len(working_models)} working model(s):")
for model in working_models:
    print(f"   - {model}")
