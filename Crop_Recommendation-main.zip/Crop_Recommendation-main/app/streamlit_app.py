
import streamlit as st
import json
from typing import Dict, Any
import os
import sys
import time

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

try:
    from recommender import CropRecommender
    # Try multi-provider AI planner first (supports Groq, HF, Gemini)
    try:
        from ai_planner_multi import MultiProviderAIPlanner as AIFarmingPlanner
        USING_MULTI_PROVIDER = True
    except ImportError:
        # Fallback to original single-provider planner
        from ai_planner import AIFarmingPlanner
        USING_MULTI_PROVIDER = False
except ImportError as e:
    # This error will be shown after set_page_config
    IMPORT_ERROR = str(e)
    AIFarmingPlanner = None
    CropRecommender = None

# Page configuration
st.set_page_config(
    page_title="Smart Crop Advisor",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Check for import errors after set_page_config
if AIFarmingPlanner is None or CropRecommender is None:
    st.error(f" Required modules not found. Please ensure recommender.py and ai_planner.py are available.")
    st.stop()

# Show which AI provider is being used
if USING_MULTI_PROVIDER:
    st.success("")
else:
    st.info(" Using single-provider AI (Gemini only)")

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #2E7D32;
        text-align: center;
        font-weight: bold;
        margin-bottom: 1rem;
    }
    .sub-header {
        font-size: 1.5rem;
        color: #558B2F;
        font-weight: bold;
        margin-top: 1.5rem;
        margin-bottom: 0.5rem;
    }
    .success-box {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #E8F5E9;
        border-left: 5px solid #4CAF50;
        margin: 1rem 0;
    }
    .info-box {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #E3F2FD;
        border-left: 5px solid #2196F3;
        margin: 1rem 0;
    }
    .warning-box {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #FFF3E0;
        border-left: 5px solid #FF9800;
        margin: 1rem 0;
    }
    .metric-card {
        background-color: #F5F5F5;
        padding: 1rem;
        border-radius: 0.5rem;
        text-align: center;
    }
</style>
""", unsafe_allow_html=True)


def initialize_session_state():
    """Initialize session state variables"""
    if 'prediction_result' not in st.session_state:
        st.session_state.prediction_result = None
    if 'farming_plan' not in st.session_state:
        st.session_state.farming_plan = None
    if 'full_analysis' not in st.session_state:
        st.session_state.full_analysis = None


def get_soil_features_input():
    """Create input form for soil features"""
    st.markdown('<p class="sub-header">Soil & Environmental Data</p>', unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        N = st.number_input(
            "Nitrogen (N) kg/ha",
            min_value=0.0,
            max_value=300.0,
            value=90.0,
            step=1.0,
            help="Nitrogen content in soil"
        )
        P = st.number_input(
            "Phosphorus (P) kg/ha",
            min_value=0.0,
            max_value=300.0,
            value=42.0,
            step=1.0,
            help="Phosphorus content in soil"
        )
        K = st.number_input(
            "Potassium (K) kg/ha",
            min_value=0.0,
            max_value=300.0,
            value=43.0,
            step=1.0,
            help="Potassium content in soil"
        )
    
    with col2:
        temperature = st.number_input(
            "Temperature (°C)",
            min_value=0.0,
            max_value=60.0,
            value=20.5,
            step=0.1,
            help="Average temperature"
        )
        humidity = st.number_input(
            "Humidity (%)",
            min_value=0.0,
            max_value=100.0,
            value=82.0,
            step=1.0,
            help="Relative humidity"
        )
        pH = st.number_input(
            "Soil pH",
            min_value=0.0,
            max_value=14.0,
            value=6.5,
            step=0.1,
            help="Soil pH level"
        )
    
    with col3:
        rainfall = st.number_input(
            "Rainfall (mm)",
            min_value=0.0,
            max_value=500.0,
            value=202.0,
            step=1.0,
            help="Monthly rainfall"
        )
        st.markdown("<br>", unsafe_allow_html=True)
    
    return {
        'N': N,
        'P': P,
        'K': K,
        'temperature': temperature,
        'humidity': humidity,
        'pH': pH,
        'rainfall': rainfall
    }


def display_prediction_result(result: Dict[str, Any]):
    """Display crop prediction results"""
    st.markdown('<p class="sub-header"> Crop Recommendation</p>', unsafe_allow_html=True)
    
    if 'error' in result:
        st.error(f"Error: {result['error']}")
        return
    
    # Main recommendation
    prediction = result.get('prediction', {})
    crop = prediction.get('crop', 'Unknown')
    confidence = prediction.get('confidence', 0)
    
    st.markdown(f"""
    <div class="success-box">
        <h2 style="color: #2E7D32; margin: 0;"> Recommended Crop: {crop}</h2>
        <h3 style="color: #558B2F; margin: 0.5rem 0 0 0;">Confidence: {confidence:.2f}%</h3>
    </div>
    """, unsafe_allow_html=True)
    
    # Metrics
    st.metric(
        " Estimated Yield (ML)",
        f"{result.get('yield_estimate', {}).get('value', 0):.2f}",
        delta=f"{result.get('yield_estimate', {}).get('unit', 'q/ha')}"
    )
    st.caption("Predicted by  Yield Regressor (R²=0.9938)")
    
    # Alternative crops
    alternatives = result.get('alternative_crops', [])
    if alternatives:
        st.markdown('<p class="sub-header"> Alternative Crops (Next Best Options)</p>', unsafe_allow_html=True)
        st.caption(" Low match percentages indicate the soil conditions are highly optimized for the recommended crop.")
        
        cols = st.columns(len(alternatives))
        for idx, alt in enumerate(alternatives):
            with cols[idx]:
                conf = alt.get('confidence', 0)
                # Show more decimal places for very low probabilities
                conf_str = f"{conf:.3f}%" if conf < 1 else f"{conf:.1f}%"
                st.info(f"**{alt.get('crop', 'N/A').title()}**\n\n{conf_str} match\n\n~{alt.get('estimated_yield', 0):.1f} q/ha")


def display_feature_importance(importance_data: Dict[str, Any]):
    """Display Explainable AI - feature importance visualization"""
    st.markdown('<p class="sub-header"> Why This Crop? (Explainable AI)</p>', unsafe_allow_html=True)
    
    if not importance_data or 'feature_importance' not in importance_data:
        st.warning("Feature importance data not available")
        return
    
    # Dual-Model Architecture Explanation
    st.markdown("""
    <div class="info-box">
        <h4 style="margin: 0 0 0.5rem 0;"> Dual-Model AI System</h4>
        <p style="margin: 0;">This system uses <strong>TWO specialized AI models</strong> working together:</p>
        <ul style="margin: 0.5rem 0;">
            <li><strong>Crop Classifier</strong> (11 features, 99.7% accuracy) → Recommends best crop</li>
            <li><strong>Yield Regressor</strong> (21 features, R²=0.9938) → Predicts expected yield</li>
        </ul>
        <p style="margin: 0.5rem 0 0 0;">Both models analyze your soil and climate data to provide crop recommendation + yield forecast!</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Display top features with explanations
    st.markdown("####  Key Factors Influencing Crop Selection")
    
    explanations = importance_data.get('explanations', [])
    if explanations:
        for i, exp in enumerate(explanations, 1):
            with st.expander(f"**{i}. {exp['feature'].upper()}** - {exp['importance']:.1f}% importance", expanded=(i==1)):
                st.write(f"**Current Value:** {exp['value']}")
                st.write(f"**Impact:** {exp['reason']}")
    
    # Feature Importance Comparison - Two Models Side by Side
    st.markdown("####  Feature Importance Comparison")
    
    col1, col2 = st.columns(2)
    
    # Classifier Model Feature Importance (actual values from trained model)
    with col1:
        st.markdown("** Crop Classifier Model (11 features)**")
        st.markdown("""
        <div style="background-color: #f0f8ff; padding: 1rem; border-radius: 0.5rem; border-left: 4px solid #4CAF50;">
            <p style="margin: 0; font-size: 0.9rem;"><strong>1. Rainfall:</strong> 18.98%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>2. Humidity:</strong> 16.33%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>3. Potassium (K):</strong> 14.62%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>4. Phosphorus (P):</strong> 9.31%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>5. Soil Fertility Score:</strong> 8.84%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>6. Temp-Humidity Index:</strong> 8.55%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>7. NPK Sum:</strong> 6.45%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>8. Nitrogen (N):</strong> 6.42%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>9. N/P Ratio:</strong> 4.85%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>10. Temperature:</strong> 3.47%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>11. pH:</strong> 2.19%</p>
        </div>
        """, unsafe_allow_html=True)
        st.caption(" Accuracy: 99.70%")
    
    # Yield Regressor Model Feature Importance (actual values from trained model)
    with col2:
        st.markdown("** Yield Regressor Model (21 features, Top 10 shown)**")
        st.markdown("""
        <div style="background-color: #fff8e1; padding: 1rem; border-radius: 0.5rem; border-left: 4px solid #FF9800;">
            <p style="margin: 0; font-size: 0.9rem;"><strong>1. Crop Encoded:</strong> 47.48%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>2. N/P Ratio:</strong> 25.85%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>3. Potassium (K):</strong> 11.43%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>4. Nitrogen (N):</strong> 4.81%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>5. Phosphorus (P):</strong> 3.03%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>6. N/K Ratio:</strong> 2.49%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>7. Nutrient Balance:</strong> 1.79%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>8. NPK Sum:</strong> 0.77%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>9. Soil Fertility Score:</strong> 0.72%</p>
            <p style="margin: 0; font-size: 0.9rem;"><strong>10. Rainfall:</strong> 0.49%</p>
        </div>
        """, unsafe_allow_html=True)
        st.caption(" R² = 0.9938 (99.38% accuracy), RMSE = 6.27 q/ha")
    
    # Key Insights
    st.markdown("""
    <div class="warning-box" style="margin-top: 1rem;">
        <h4 style="margin: 0 0 0.5rem 0;"> Key Insights</h4>
        <ul style="margin: 0;">
            <li><strong>Classifier Focus:</strong> Climate factors (Rainfall, Humidity) dominate crop selection</li>
            <li><strong>Yield Focus:</strong> Crop type (47.48%) is the strongest yield predictor - different crops have vastly different yield potentials</li>
            <li><strong>Common Factors:</strong> NPK nutrients important for both selection and yield</li>
            <li><strong>Complexity:</strong> Yield model uses 21 features (vs 11 for classifier) to capture yield-determining nuances</li>
        </ul>
    </div>
    """, unsafe_allow_html=True)


def display_what_if_scenarios(recommender, soil_features: Dict[str, float]):
    """Display what-if scenario simulator"""
    st.markdown('<p class="sub-header"> What-If Scenarios</p>', unsafe_allow_html=True)
    st.markdown("Simulate how changes in soil and environmental conditions affect crop recommendations")
    
    # NPK Changes
    st.markdown("** Nutrient Levels**")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        n_change = st.slider("N Change (kg/ha)", -50, 100, 0, key="n_change")
        new_n = soil_features['N'] + n_change
        st.caption(f"Current: {soil_features['N']} → New: {new_n}")
    
    with col2:
        p_change = st.slider("P Change (kg/ha)", -30, 80, 0, key="p_change")
        new_p = soil_features['P'] + p_change
        st.caption(f"Current: {soil_features['P']} → New: {new_p}")
    
    with col3:
        k_change = st.slider("K Change (kg/ha)", -30, 80, 0, key="k_change")
        new_k = soil_features['K'] + k_change
        st.caption(f"Current: {soil_features['K']} → New: {new_k}")
    
    # Environmental Changes
    st.markdown("** Environmental Conditions**")
    col4, col5 = st.columns(2)
    
    with col4:
        temp_change = st.slider("Temperature Change (°C)", -10, 15, 0, key="temp_change")
        new_temp = soil_features['temperature'] + temp_change
        st.caption(f"Current: {soil_features['temperature']}°C → New: {new_temp}°C")
    
    with col5:
        rain_change = st.slider("Rainfall Change (mm)", -150, 150, 0, key="rain_change")
        new_rain = soil_features['rainfall'] + rain_change
        st.caption(f"Current: {soil_features['rainfall']}mm → New: {new_rain}mm")
    
    if st.button(" Run Simulation", type="primary"):
        modifications = {}
        if n_change != 0:
            modifications['N'] = new_n
        if p_change != 0:
            modifications['P'] = new_p
        if k_change != 0:
            modifications['K'] = new_k
        if temp_change != 0:
            modifications['temperature'] = new_temp
        if rain_change != 0:
            modifications['rainfall'] = new_rain
        
        if modifications:
            with st.spinner("Running simulation..."):
                what_if_result = recommender.simulate_what_if(soil_features, modifications)
                
                if 'error' not in what_if_result:
                    st.markdown("#### Simulation Results")
                    
                    # Comparison table
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.markdown("**Current Scenario**")
                        current = what_if_result['current']
                        st.metric("Crop", current['crop'])
                        st.metric("Confidence", f"{current['confidence']:.1f}%")
                        st.metric("Yield", f"{current['yield']:.1f} q/ha")
                    
                    with col2:
                        st.markdown("**Modified Scenario**")
                        modified = what_if_result['modified']
                        st.metric("Crop", modified['crop'])
                        st.metric("Confidence", f"{modified['confidence']:.1f}%")
                        st.metric("Yield", f"{modified['yield']:.1f} q/ha")
                    
                    with col3:
                        st.markdown("**Changes**")
                        changes = what_if_result['changes']
                        if changes['crop_changed']:
                            st.warning(" Crop Changed!")
                        else:
                            st.success(" Same Crop")
                        
                        confidence_delta = changes['confidence_change']
                        st.metric("Confidence Change", f"{confidence_delta:+.1f}%")
                        
                        yield_delta = changes['yield_change']
                        yield_pct = changes['yield_change_percent']
                        st.metric("Yield Change", f"{yield_delta:+.1f} q/ha", 
                                 delta=f"{yield_pct:+.1f}%")
                    
                    # Recommendation
                    st.markdown("####  Recommendation")
                    st.info(what_if_result['recommendation'])
                    
                    # Top 3 crops comparison
                    st.markdown("#### Top 3 Crops Comparison")
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.markdown("**Current Top 3**")
                        for i, crop in enumerate(current['top_crops'], 1):
                            st.write(f"{i}. **{crop['crop']}** - {crop['confidence']:.1f}% ({crop['estimated_yield']:.1f} q/ha)")
                    
                    with col2:
                        st.markdown("**Modified Top 3**")
                        for i, crop in enumerate(modified['top_crops'], 1):
                            st.write(f"{i}. **{crop['crop']}** - {crop['confidence']:.1f}% ({crop['estimated_yield']:.1f} q/ha)")
                else:
                    st.error(f"Simulation error: {what_if_result['error']}")
        else:
            st.warning("Please adjust at least one NPK value to run simulation")



def display_optimal_conditions(optimal_data: Dict[str, Any]):
    """Display optimal growing conditions for a crop"""
    st.markdown('<p class="sub-header"> Optimal Growing Conditions</p>', unsafe_allow_html=True)
    
    if 'error' in optimal_data:
        st.error(optimal_data['error'])
        if 'available_crops' in optimal_data:
            st.info("**Available crops:** " + ", ".join(optimal_data['available_crops'][:10]))
        return
    
    crop = optimal_data['crop']
    st.markdown(f"### {crop}")
    
    # Yield statistics
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Maximum Recorded Yield", f"{optimal_data.get('maximum_recorded_yield', 0):.1f} q/ha", delta="Peak Performance")
    with col2:
        st.metric("Average Yield", f"{optimal_data.get('average_yield', 0):.1f} q/ha", delta="Typical")
    with col3:
        st.metric("Top 10% Average", f"{optimal_data.get('top_10_percent_yield', 0):.1f} q/ha", delta="Best Performers")
    
    if 'predicted_max_yield' in optimal_data:
        st.success(f" **Predicted Maximum Yield with Optimal Conditions:** {optimal_data['predicted_max_yield']:.1f} q/ha")
    
    st.markdown("---")
    
    # Optimal conditions table
    st.markdown("####  Optimal Parameter Ranges")
    st.caption("Based on top 10% highest yielding samples")
    
    conditions = optimal_data.get('optimal_conditions', {})
    
    # Create comparison table
    import pandas as pd
    table_data = []
    for param, values in conditions.items():
        table_data.append({
            'Parameter': param.upper() if len(param) <= 3 else param.title(),
            'Minimum': f"{values['min']:.1f}",
            'Optimal': f"{values['optimal']:.1f}",
            'Maximum': f"{values['max']:.1f}",
            'Unit': values.get('unit', '')
        })
    
    df = pd.DataFrame(table_data)
    st.dataframe(df, use_container_width=True, hide_index=True)
    
    # Visual representation
    st.markdown("####  Visual Ranges")
    for param, values in conditions.items():
        param_name = param.upper() if len(param) <= 3 else param.title()
        col1, col2 = st.columns([3, 1])
        with col1:
            # Create a simple range visualization
            min_val = values['min']
            opt_val = values['optimal']
            max_val = values['max']
            
            st.markdown(f"**{param_name}**")
            st.slider(
                f"{param_name} Range",
                min_value=float(min_val * 0.8),
                max_value=float(max_val * 1.2),
                value=(float(min_val), float(max_val)),
                disabled=True,
                label_visibility="collapsed",
                key=f"slider_{param}"
            )
            st.caption(f"Optimal: {opt_val:.1f} {values.get('unit', '')}")
        with col2:
            st.metric("", f"{opt_val:.1f}", values.get('unit', ''))
    
    # Recommendation
    if 'recommendation' in optimal_data:
        st.info(f" **Recommendation:** {optimal_data['recommendation']}")
    
    if 'total_samples' in optimal_data:
        st.caption(f"Analysis based on {optimal_data['total_samples']} historical samples")


def display_farming_plan(plan: Dict[str, Any]):
    """Display AI-generated farming plan"""
    st.markdown('<p class="sub-header"> AI-Powered Farming Plan</p>', unsafe_allow_html=True)
    
    if 'error' in plan:
        st.error(f"Error: {plan['error']}")
        return
    
    # Seed varieties (handle both old and new format)
    st.markdown("####  Recommended Seed Varieties")
    seed_selection = plan.get('seed_selection', {})
    if seed_selection and isinstance(seed_selection, dict):
        varieties = seed_selection.get('recommended_varieties', [])
        st.write(", ".join(varieties) if varieties else "Standard varieties")
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Seed Rate", seed_selection.get('seed_rate', 'N/A'))
        with col2:
            st.metric("Spacing", seed_selection.get('spacing', 'N/A'))
        with col3:
            st.metric("Method", seed_selection.get('sowing_method', 'N/A'))
    else:
        # Fallback to old format
        varieties = plan.get('seed_varieties', [])
        st.write(", ".join(varieties) if varieties else "Standard varieties")
    
    # Sowing Guide (Day-by-day)
    st.markdown("####   Step-by-Step Sowing Guide")
    sowing_guide = plan.get('sowing_guide', [])
    if sowing_guide:
        for day_item in sowing_guide:
            with st.expander(f"Day {day_item.get('day', 'N/A')}: {day_item.get('activity', 'N/A')}"):
                st.write(day_item.get('details', 'N/A'))
    else:
        # Fallback to old format
        schedule = plan.get('growing_schedule', [])
        if schedule:
            for stage in schedule[:6]:
                with st.expander(f"{stage.get('period', 'N/A')} - {stage.get('stage', 'N/A')}"):
                    st.write(stage.get('activities', 'N/A'))
    
    # Irrigation schedule (new format) or plan (old format)
    st.markdown("####   Irrigation Schedule")
    irrigation = plan.get('irrigation_schedule', plan.get('irrigation_plan', {}))
    if irrigation:
        col1, col2 = st.columns(2)
        with col1:
            st.info(f"**Method:** {irrigation.get('method', 'N/A')}")
            st.info(f"**Frequency:** {irrigation.get('frequency', 'N/A')}")
        with col2:
            st.info(f"**Water Requirement:** {irrigation.get('water_requirement', irrigation.get('irrigation_needed', 'N/A'))}")
            rainfall = irrigation.get('weekly_rainfall', 0)
            if isinstance(rainfall, (int, float)):
                st.info(f"**Rainfall:** {rainfall:.1f} mm/week")
        
        # Show critical stages if available
        critical_stages = irrigation.get('critical_stages', [])
        if critical_stages:
            st.write("** Critical Irrigation Stages:**")
            st.write(", ".join(critical_stages))
    
    # Fertilizer schedule
    st.markdown("####   Fertilizer Schedule")
    fertilizer = plan.get('fertilizer_schedule', [])
    if fertilizer:
        for fert in fertilizer:
            stage = fert.get('stage', f"Week {fert.get('week', 'N/A')}")
            application_method = fert.get('application_method', '')
            st.markdown(f"""
            <div class="info-box">
                <strong>{stage}</strong><br>
                N: {fert.get('N', 0)} kg/ha | P: {fert.get('P', 0)} kg/ha | K: {fert.get('K', 0)} kg/ha<br>
                <em>{application_method}</em>
            </div>
            """, unsafe_allow_html=True)
    
    # Pest Risk Assessment
    st.markdown("####   Pest Risk Assessment")
    pests = plan.get('pest_risk_assessment', plan.get('pest_disease_risks', plan.get('pest_risks', [])))
    if pests:
        for pest in pests:
            risk_color = {'High': '🔴', 'Medium': '🟡', 'Low': '🟢'}
            risk_level = pest.get('risk_level', pest.get('risk', 'Medium'))
            risk_icon = risk_color.get(risk_level, '🟡')
            pest_name = pest.get('pest_name', pest.get('pest', 'N/A'))
            
            with st.expander(f"{risk_icon} {pest_name} - Risk: {risk_level}"):
                st.write(f"**Symptoms:** {pest.get('symptoms', 'N/A')}")
                st.write(f"**Prevention:** {pest.get('prevention', 'N/A')}")
                if 'control_if_found' in pest:
                    st.write(f"**Control Measures:** {pest.get('control_if_found', 'N/A')}")
    else:
        st.info("No major pest or disease risks identified for current conditions.")
    
    # Weekly Monitoring Plan
    st.markdown("####   Weekly Monitoring Plan")
    monitoring = plan.get('weekly_monitoring_plan', [])
    if monitoring:
        # Show in a table format
        import pandas as pd
        monitoring_data = []
        for item in monitoring:
            week = item.get('week', 'N/A')
            checks = ', '.join(item.get('check_for', [])) if isinstance(item.get('check_for', []), list) else item.get('check_for', 'N/A')
            actions = item.get('action_if_needed', 'N/A')
            monitoring_data.append({'Week': week, 'What to Check': checks, 'Action if Needed': actions})
        
        if monitoring_data:
            df = pd.DataFrame(monitoring_data)
            st.dataframe(df, use_container_width=True, hide_index=True)
    
    # Harvest timeline
    st.markdown("####   Harvest Planning")
    harvest = plan.get('harvest_planning', plan.get('harvest_timeline', {}))
    if harvest:
        col1, col2 = st.columns(2)
        with col1:
            maturity = harvest.get('expected_maturity', harvest.get('expected_duration', 'N/A'))
            st.success(f"**Maturity:** {maturity}")
            method = harvest.get('harvest_method', harvest.get('harvesting_method', 'N/A'))
            st.success(f"**Method:** {method}")
        with col2:
            # Handle both list and string for indicators
            indicators = harvest.get('harvest_indicators', harvest.get('maturity_signs', 'N/A'))
            if isinstance(indicators, list):
                st.success(f"**Indicators:** {', '.join(indicators)}")
            else:
                st.success(f"**Indicators:** {indicators}")
            
            post_harvest = harvest.get('post_harvest', 'N/A')
            st.success(f"**Post-Harvest:** {post_harvest}")
    
    # Cost-saving tips (only show if present - from fallback system)
    tips = plan.get('cost_saving_tips', [])
    if tips:
        st.markdown("####   Cost-Saving Tips")
        for tip in tips[:5]:  # Show first 5
            st.markdown(f"✓ {tip}")
    
    # Market advice (only show if present - from fallback system)
    market = plan.get('market_advice', {})
    if market:
        st.markdown("#### Market Advice")
        st.info(f"**Timing:** {market.get('timing', 'N/A')}")
        st.info(f"**Quality Focus:** {market.get('quality_focus', 'N/A')}")
        
        channels = market.get('channels', [])
        if channels:
            st.write("**Selling Channels:**")
            for channel in channels:
                st.write(f"  • {channel}")
    
    # Show generation info
    generated_by = plan.get('generated_by', 'Unknown')
    generation_time = plan.get('generation_time', 'N/A')
    if generated_by != 'Unknown':
        st.divider()
        col1, col2 = st.columns(2)
        with col1:
            st.caption(f" Generated by: {generated_by}")
        with col2:
            st.caption(f" Generation time: {generation_time}")


def main():
    """Main Streamlit application"""
    # Initialize session state FIRST
    initialize_session_state()
    
    # Header
    st.markdown('<p class="main-header" style="font-size: 2rem"> AI-Powered Smart Crop Advisor</p>', unsafe_allow_html=True)
    st.markdown(
        '<p style="text-align: center; color: #666; font-size: 1.1rem;">'
        'Intelligent Crop Recommendation with AI Farming Plans'
        '</p>',
        unsafe_allow_html=True
    )
    
    # Sidebar
    with st.sidebar:
       # st.image("https://via.placeholder.com/300x100/2E7D32/FFFFFF?text=Smart+Farming", use_column_width=True)
        st.markdown("###  Features")
        st.markdown("""
        -  ML-powered crop prediction
        -  Explainable AI insights      
        - What-If Scenario Simulation
        -  Yield estimation
        -  AI farming plans
        -  Expert recommendations
        """)
        
        st.markdown("---")
        st.markdown("###  Find Optimal Conditions")
        st.caption("Enter a crop name to find ideal growing conditions for maximum yield")
        
        crop_input = st.text_input("Crop Name", placeholder="e.g., rice, wheat, maize", key="optimal_crop_input")
        
        if st.button(" Find Optimal Conditions", use_container_width=True):
            if crop_input:
                with st.spinner(f"Finding optimal conditions for {crop_input}..."):
                    try:
                        recommender = CropRecommender('crop_model.pkl', 'yield_model.pkl')
                        optimal_data = recommender.get_optimal_conditions(crop_input)
                        st.session_state.optimal_conditions = optimal_data
                        st.success(f"✓ Found optimal conditions for {crop_input}!")
                    except Exception as e:
                        st.error(f"Error: {str(e)}")
            else:
                st.warning("Please enter a crop name")
        
       
    
    # Main content
    st.markdown("---")
    
    # Input form
    soil_features = get_soil_features_input()
    
    st.markdown("---")
    
    # Action buttons
    st.markdown('<p class="sub-header"> Actions</p>', unsafe_allow_html=True)
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button(" Recommend Crop", use_container_width=True, type="primary"):
            with st.spinner("Analyzing soil conditions..."):
                try:
                    # Use local recommender with both models
                    recommender = CropRecommender('crop_model.pkl', 'yield_model.pkl')
                    
                    # Get prediction
                    prediction = recommender.predict_crop(soil_features)
                    crop = prediction['recommended_crop']
                    confidence = prediction['confidence']
                    
                    # Get yield estimate
                    estimated_yield = recommender.predict_yield(crop, soil_features)
                    
                    # Get feature importance
                    importance_data = recommender.get_feature_importance(crop, soil_features)
                    
                    # Get top crops
                    top_crops = recommender.get_top_crops(soil_features, 5)
                    
                    result = {
                        'prediction': {
                            'crop': crop,
                            'confidence': confidence
                        },
                        'yield_estimate': {
                            'value': estimated_yield,
                            'unit': 'q/ha'
                        },
                        'model_accuracy': recommender.accuracy,
                        'features_used': len(recommender.feature_names),
                        'alternative_crops': [
                            {
                                'crop': alt['crop'],
                                'confidence': alt['confidence'],
                                'estimated_yield': recommender.predict_yield(alt['crop'], soil_features)
                            }
                            for alt in top_crops[1:4]
                        ],
                        'feature_importance': importance_data
                    }
                    st.session_state.recommender = recommender
                    st.session_state.prediction_result = result
                    st.session_state.soil_features = soil_features
                except Exception as e:
                    st.error(f"Error: {str(e)}")
    
    with col2:
        if st.button(" Generate Farming Plan", use_container_width=True):
            if st.session_state.prediction_result:
                crop = st.session_state.prediction_result.get('prediction', {}).get('crop', 'Rice')
            else:
                crop = st.text_input("Enter crop name:", value="Rice")
            
            # Create progress placeholder
            progress_placeholder = st.empty()
            
            with st.spinner(f" Generating AI farming plan for {crop}..."):
                progress_placeholder.info("Contacting Groq... This may take 10-20 seconds.")
                try:
                    planner = AIFarmingPlanner()
                    plan = planner.generate_plan(crop, soil_features)
                    st.session_state.farming_plan = plan
                    progress_placeholder.success(" Plan generated successfully!")
                    time.sleep(1)  # Brief pause to show success
                    progress_placeholder.empty()
                except Exception as e:
                    progress_placeholder.empty()
                    st.error(f"Error: {str(e)}")
    
    with col3:
        if st.button(" Full Smart Analysis", use_container_width=True, type="secondary"):
            with st.spinner("Running complete analysis..."):
                try:
                    recommender = CropRecommender('crop_model.pkl', 'yield_model.pkl')
                    planner = AIFarmingPlanner()
                    
                    # Get prediction
                    prediction = recommender.predict_crop(soil_features)
                    crop = prediction['recommended_crop']
                    confidence = prediction['confidence']
                    
                    # Get yield estimate
                    estimated_yield = recommender.predict_yield(crop, soil_features)
                    
                    # Get feature importance
                    importance_data = recommender.get_feature_importance(crop, soil_features)
                    
                    # Get top crops
                    top_crops = recommender.get_top_crops(soil_features, 5)
                    
                    # Generate farming plan
                    plan = planner.generate_plan(crop, soil_features)
                    
                    st.session_state.prediction_result = {
                        'prediction': {
                            'crop': crop,
                            'confidence': confidence
                        },
                        'estimated_yield': estimated_yield,
                        'model_name': recommender.model_name,
                        'model_accuracy': recommender.accuracy,
                        'features_used': len(recommender.feature_names),
                        'alternative_crops': top_crops[1:4],
                        'feature_importance': importance_data
                    }
                    st.session_state.farming_plan = plan
                    st.session_state.recommender = recommender
                    st.session_state.soil_features = soil_features
                    
                    st.success("✓ Complete analysis ready!")
                except Exception as e:
                    st.error(f"Error: {str(e)}")
    
    st.markdown("---")
    
    # Display results (with safety checks)
    if hasattr(st.session_state, 'prediction_result') and st.session_state.prediction_result:
        # Check if current input matches the displayed result
        stored_features = st.session_state.get('soil_features', {})
        
        if stored_features and soil_features != stored_features:
            st.error(" **OUTDATED PREDICTION** - You changed the input values!")
            st.info(" Scroll up and click the **' Recommend Crop'** button to get new prediction for your updated values.")
            st.markdown("---")
        
        display_prediction_result(st.session_state.prediction_result)
        
        # Display feature importance (Explainable AI)
        if 'feature_importance' in st.session_state.prediction_result:
            st.markdown("---")
            display_feature_importance(st.session_state.prediction_result['feature_importance'])
        
        # Display what-if scenarios
        if hasattr(st.session_state, 'recommender') and hasattr(st.session_state, 'soil_features'):
            st.markdown("---")
            display_what_if_scenarios(st.session_state.recommender, st.session_state.soil_features)
    
    if hasattr(st.session_state, 'farming_plan') and st.session_state.farming_plan:
        st.markdown("---")
        display_farming_plan(st.session_state.farming_plan)
    
    # Display optimal conditions if available
    if hasattr(st.session_state, 'optimal_conditions') and st.session_state.optimal_conditions:
        st.markdown("---")
        display_optimal_conditions(st.session_state.optimal_conditions)
    
    # Footer
    st.markdown("---")
    st.markdown(
        '<p style="text-align: center; color: #999; font-size: 0.9rem;">'
        '© 2025 Smart Crop Advisor | Empowering Farmers with AI'
        '</p>',
        unsafe_allow_html=True
    )


if __name__ == "__main__":
    main()
