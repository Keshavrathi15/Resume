
from typing import Dict, List, Any
import numpy as np
import json
import os

# Load crop-specific optimal ranges (generated from dataset)
_crop_ranges = None

def _load_crop_ranges():
    """Load crop-specific ranges from JSON file"""
    global _crop_ranges
    if _crop_ranges is None:
        try:
            ranges_path = os.path.join(os.path.dirname(__file__), 'crop_optimal_ranges.json')
            with open(ranges_path, 'r') as f:
                _crop_ranges = json.load(f)
        except FileNotFoundError:
            _crop_ranges = {}  # Fallback to empty dict
    return _crop_ranges

def _get_status_for_crop(feature: str, value: float, crop: str) -> str:
    """Get data-driven status (optimal/acceptable/suboptimal) for a feature value"""
    ranges = _load_crop_ranges()
    crop_lower = crop.lower()
    
    # Map uppercase feature names to match dataset format
    feature_map = {
        'N': 'N', 'P': 'P', 'K': 'K',
        'pH': 'pH', 'temperature': 'temperature',
        'humidity': 'humidity', 'rainfall': 'rainfall'
    }
    
    feature_key = feature_map.get(feature, feature)
    
    if crop_lower in ranges and feature_key in ranges[crop_lower]:
        range_data = ranges[crop_lower][feature_key]
        opt_min = range_data['min']  # 25th percentile
        opt_max = range_data['max']  # 75th percentile
        mean_val = range_data['mean']
        
        # Create acceptable range as wider bounds (±20% from optimal)
        range_width = opt_max - opt_min
        acc_min = opt_min - (range_width * 0.3)
        acc_max = opt_max + (range_width * 0.3)
        
        if opt_min <= value <= opt_max:
            return 'optimal'
        elif acc_min <= value <= acc_max:
            return 'acceptable'
        else:
            return 'suboptimal'
    
    # Fallback for unknown crops or features
    return 'unknown'


def generate_feature_explanations(feature_importance: Dict[str, float], 
                                  feature_values: Dict[str, float],
                                  crop: str) -> List[Dict[str, Any]]:
   
    explanations = []
    
    # Helper function for data-driven feature explanations
    def explain_feature(feature: str, value: float) -> str:
        status = _get_status_for_crop(feature, value, crop)
        
        feature_info = {
            'N': ('Nitrogen', 'kg/ha', 'nutrient uptake and leaf growth'),
            'P': ('Phosphorus', 'kg/ha', 'root development and flowering'),
            'K': ('Potassium', 'kg/ha', 'disease resistance and fruit quality'),
            'temperature': ('Temperature', '°C', 'growth rate and development'),
            'humidity': ('Humidity', '%', 'transpiration and disease resistance'),
            'pH': ('Soil pH', '', 'nutrient availability'),
            'rainfall': ('Rainfall', 'mm', 'water requirements')
        }
        
        if feature not in feature_info:
            return f"{feature} value of {value:.1f} influences {crop} growth"
        
        name, unit, impact = feature_info[feature]
        unit_str = f" {unit}" if unit else ""
        
        if status == 'optimal':
            return f"{name} of {value:.1f}{unit_str} is optimal for {crop} - supports excellent {impact}"
        elif status == 'acceptable':
            return f"{name} of {value:.1f}{unit_str} is acceptable for {crop} - adequate for {impact}"
        elif status == 'suboptimal':
            return f"{name} of {value:.1f}{unit_str} needs adjustment for {crop} - may limit {impact}"
        else:
            return f"{name} of {value:.1f}{unit_str} influences {crop} {impact}"
    
    # Define explanation templates for each feature (using data-driven ranges for original features)
    feature_explanations = {
        # Original features (data-driven explanations)
        'N': lambda v: explain_feature('N', v),
        'P': lambda v: explain_feature('P', v),
        'K': lambda v: explain_feature('K', v),
        'temperature': lambda v: explain_feature('temperature', v),
        'humidity': lambda v: explain_feature('humidity', v),
        'pH': lambda v: explain_feature('pH', v),
        'rainfall': lambda v: explain_feature('rainfall', v),
        
        # Engineered features (exact names from trained model)
        'N_P_ratio': lambda v: f"N:P ratio of {v:.2f} indicates {'balanced' if 1.5 <= v <= 3.0 else 'imbalanced'} nutrient distribution",
        'N_K_ratio': lambda v: f"N:K ratio of {v:.2f} shows {'good' if 1.5 <= v <= 3.0 else 'suboptimal'} nitrogen-potassium balance",
        'P_K_ratio': lambda v: f"P:K ratio of {v:.2f} demonstrates {'optimal' if 0.5 <= v <= 1.5 else 'variable'} phosphorus-potassium relationship",
        'temp_humidity_index': lambda v: f"Temperature-humidity index of {v:.1f} creates {'favorable' if 15 <= v <= 30 else 'challenging'} growing conditions",
        'water_stress_index': lambda v: f"Water stress index of {v:.1f} {'minimizes drought risk' if v > 5 else 'suggests potential water stress'}",
        'NPK_sum': lambda v: f"Total NPK of {v:.1f} kg/ha indicates {'high' if v > 200 else 'moderate' if v > 100 else 'low'} soil fertility",
        'NPK_balance': lambda v: f"NPK balance score of {v:.1f} shows {'well-distributed' if v < 30 else 'uneven'} nutrient levels",
        'soil_fertility_score': lambda v: f"Fertility score of {v:.1f} indicates {'excellent' if v > 100 else 'good' if v > 60 else 'fair'} soil health",
        'heat_stress': lambda v: f"Heat stress of {v:.1f} {'is minimal' if v == 0 else 'may affect plant growth'}",
        'moisture_deficit': lambda v: f"Moisture deficit of {v:.1f} {'is not a concern' if v == 0 else 'requires attention'}",
        'temp_squared': lambda v: f"Temperature intensity factor helps model non-linear temperature effects on {crop}",
        'humidity_squared': lambda v: f"Humidity intensity factor captures complex moisture-related patterns",
        'rainfall_squared': lambda v: f"Rainfall intensity factor models water availability impacts",
        'pH_squared': lambda v: f"pH intensity factor accounts for non-linear soil acidity effects",
    }
    
    # Sort features by importance
    sorted_features = sorted(feature_importance.items(), key=lambda x: x[1], reverse=True)
    
    # Generate explanations for top features
    for feature_name, importance in sorted_features[:10]:
        # Get value - try lowercase first, then as-is
        value = feature_values.get(feature_name)
        if value is None:
            # Try lowercase version
            value = feature_values.get(feature_name.lower(), 0)
        
        # Get explanation or use default
        if feature_name in feature_explanations:
            try:
                reason = feature_explanations[feature_name](value)
            except Exception as e:
                reason = f"This feature contributes {importance:.1f}% to the {crop} prediction"
        else:
            # Default explanation for unknown features
            reason = f"This feature contributes {importance:.1f}% to the {crop} prediction"
        
        explanations.append({
            'feature': feature_name,
            'value': round(value, 2) if value is not None else 0,
            'importance': round(importance, 2),
            'reason': reason
        })
    
    return explanations


def generate_what_if_recommendation(current_crop: str, modified_crop: str,
                                   current_yield: float, modified_yield: float,
                                   modifications: Dict[str, float]) -> str:

    mod_list = ", ".join([f"{k}={v:.1f}" for k, v in modifications.items()])
    
    if current_crop != modified_crop:
        return (
            f" Changing {mod_list} shifts the recommendation from "
            f"{current_crop} to {modified_crop}. "
            f"This indicates these parameters are critical for crop selection. "
            f"Consider soil amendments if targeting {current_crop}."
        )
    
    yield_diff = modified_yield - current_yield
    yield_pct = (yield_diff / current_yield * 100) if current_yield > 0 else 0
    
    if abs(yield_pct) < 5:
        return (
            f"Modifying {mod_list} has minimal impact ({yield_pct:+.1f}%) on "
            f"{current_crop} yield. Current soil conditions are already suitable."
        )
    elif yield_pct > 0:
        return (
            f" Increasing {mod_list} can improve {current_crop} yield by "
            f"{yield_diff:.1f} q/ha ({yield_pct:+.1f}%). "
            f"Consider targeted fertilization or soil amendments to achieve this boost."
        )
    else:
        return (
            f" Reducing {mod_list} may decrease {current_crop} yield by "
            f"{abs(yield_diff):.1f} q/ha ({yield_pct:.1f}%). "
            f"Maintain current nutrient levels for optimal production."
        )


def get_optimal_npk_ranges(crop: str) -> Dict[str, tuple]:
    """
     Get optimal NPK ranges for different crops
    
    Args:
        crop: Name of the crop
        
    Returns:
        Dictionary with optimal N, P, K ranges
    """
    # General crop NPK requirements (kg/ha)
    crop_npk_map = {
        'rice': {'N': (80, 120), 'P': (40, 60), 'K': (40, 60)},
        'wheat': {'N': (100, 150), 'P': (50, 80), 'K': (40, 60)},
        'maize': {'N': (120, 180), 'P': (60, 90), 'K': (50, 80)},
        'cotton': {'N': (100, 150), 'P': (50, 70), 'K': (50, 70)},
        'chickpea': {'N': (20, 40), 'P': (40, 60), 'K': (20, 40)},
        'kidneybeans': {'N': (20, 40), 'P': (40, 60), 'K': (20, 40)},
        'pigeonpeas': {'N': (20, 40), 'P': (40, 60), 'K': (20, 40)},
        'mothbeans': {'N': (20, 40), 'P': (40, 60), 'K': (20, 40)},
        'mungbean': {'N': (20, 40), 'P': (40, 60), 'K': (20, 40)},
        'blackgram': {'N': (20, 40), 'P': (40, 60), 'K': (20, 40)},
        'lentil': {'N': (20, 40), 'P': (40, 60), 'K': (20, 40)},
        'pomegranate': {'N': (60, 100), 'P': (40, 60), 'K': (60, 100)},
        'banana': {'N': (200, 300), 'P': (50, 80), 'K': (200, 300)},
        'mango': {'N': (100, 150), 'P': (50, 80), 'K': (100, 150)},
        'grapes': {'N': (80, 120), 'P': (40, 60), 'K': (80, 120)},
        'watermelon': {'N': (100, 150), 'P': (50, 80), 'K': (80, 120)},
        'muskmelon': {'N': (100, 150), 'P': (50, 80), 'K': (80, 120)},
        'apple': {'N': (100, 150), 'P': (50, 80), 'K': (100, 150)},
        'orange': {'N': (100, 150), 'P': (50, 80), 'K': (100, 150)},
        'papaya': {'N': (100, 150), 'P': (50, 80), 'K': (100, 150)},
        'coconut': {'N': (100, 150), 'P': (50, 80), 'K': (150, 200)},
        'coffee': {'N': (80, 120), 'P': (40, 60), 'K': (80, 120)},
        'jute': {'N': (60, 100), 'P': (30, 50), 'K': (40, 60)},
    }
    
    # Return crop-specific ranges or default
    crop_lower = crop.lower()
    return crop_npk_map.get(crop_lower, {
        'N': (60, 120),
        'P': (40, 70),
        'K': (40, 70)
    })


def explain_npk_recommendations(current_npk: Dict[str, float], 
                               optimal_npk: Dict[str, tuple],
                               crop: str) -> str:
  
    recommendations = []
    
    for nutrient in ['N', 'P', 'K']:
        current = current_npk[nutrient]
        optimal_min, optimal_max = optimal_npk[nutrient]
        
        if current < optimal_min:
            diff = optimal_min - current
            recommendations.append(
                f"• **{nutrient}**: Current {current:.1f} kg/ha is below optimal range "
                f"({optimal_min}-{optimal_max}). Consider adding {diff:.1f} kg/ha."
            )
        elif current > optimal_max:
            diff = current - optimal_max
            recommendations.append(
                f"• **{nutrient}**: Current {current:.1f} kg/ha exceeds optimal range "
                f"({optimal_min}-{optimal_max}). Reduce by {diff:.1f} kg/ha to avoid waste."
            )
        else:
            recommendations.append(
                f"• **{nutrient}**: Current {current:.1f} kg/ha is within optimal range "
                f"({optimal_min}-{optimal_max}). "
            )
    
    header = f" NPK Recommendations for {crop.title()}:\n\n"
    return header + "\n".join(recommendations)


if __name__ == "__main__":
    # Test explainability functions
    print(" Testing Explainability Module...\n")
    
    # Sample feature importance
    feature_importance = {
        'rainfall': 15.5,
        'N': 12.3,
        'humidity': 11.2,
        'temperature': 10.8,
        'K': 9.5,
        'P': 8.7,
        'pH': 7.2,
        'soil_fertility_score': 6.5,
        'NPK_sum': 5.3,
        'temp_humidity_index': 4.1
    }
    
    # Sample feature values
    feature_values = {
        'rainfall': 202.0,
        'N': 90.0,
        'humidity': 82.0,
        'temperature': 20.5,
        'K': 43.0,
        'P': 42.0,
        'pH': 6.5,
        'soil_fertility_score': 85.3,
        'NPK_sum': 175.0,
        'temp_humidity_index': 16.81
    }
    
    # Generate explanations
    explanations = generate_feature_explanations(
        feature_importance, 
        feature_values, 
        'rice'
    )
    
    print(" Top Feature Explanations:")
    for i, exp in enumerate(explanations[:5], 1):
        print(f"\n{i}. {exp['feature'].upper()} (Importance: {exp['importance']:.1f}%)")
        print(f"   Value: {exp['value']}")
        print(f"   Reason: {exp['reason']}")
    
    # Test NPK recommendations
    print("\n" + "="*60)
    current_npk = {'N': 90, 'P': 42, 'K': 43}
    optimal_npk = get_optimal_npk_ranges('rice')
    
    npk_rec = explain_npk_recommendations(current_npk, optimal_npk, 'rice')
    print(f"\n{npk_rec}")
    
    print("\n Test completed!")
