# 🌾 App Folder - Core Application Files

This folder contains **ONLY** the essential files needed to run the Crop Detection System.

## ✅ Essential Files (DO NOT DELETE)

### Main Application
- **streamlit_app.py** - Frontend web interface (721 lines)
- **recommender.py** - ML engine with dual-model architecture (544 lines)
- **explainability.py** - Dataset-driven explainability engine (352 lines)
- **ai_planner.py** - Gemini AI integration for farming plans
- **utils.py** - Utility functions

### Trained Models (Required)
- **crop_model.pkl** (15MB) - Crop classifier (99.70% accuracy)
- **yield_model.pkl** (45MB) - Yield regressor (R²=0.9938)

### Configuration Files
- **crop_optimal_ranges.json** - Data-driven crop-specific optimal ranges
- **requirements.txt** - Python dependencies
- **.env** - Environment variables (API keys)

### Virtual Environment (Optional)
- **venv/** - Python virtual environment (can recreate)
- **__pycache__/** - Python bytecode cache (auto-generated)

## 🚀 Running the Application

### Step 1: Install Dependencies
```bash
cd app
pip install -r requirements.txt
```

### Step 2: Configure Environment
Edit `.env` file and add your Gemini API key:
```
GEMINI_API_KEY=your_api_key_here
```

### Step 3: Run the App
```bash
streamlit run streamlit_app.py
```

### Step 4: Access in Browser
```
Local:   http://localhost:8501
Network: http://192.168.1.61:8501
```

## 📁 File Sizes

```
Total: ~65MB (mostly models)

Models:
  crop_model.pkl     - 15MB
  yield_model.pkl    - 45MB

Application Code:
  streamlit_app.py   - ~35KB
  recommender.py     - ~25KB
  explainability.py  - ~20KB
  ai_planner.py      - ~10KB
  utils.py           - ~5KB

Configuration:
  crop_optimal_ranges.json - ~50KB
  requirements.txt         - ~1KB
  .env                     - <1KB
```

## 🔑 Key Components

### Dual-Model System
1. **Crop Classifier** (crop_model.pkl)
   - 11 features
   - 99.70% accuracy
   - 22 crop varieties
   - RandomForest algorithm

2. **Yield Regressor** (yield_model.pkl)
   - 21 features
   - R²=0.9938 (99.38% accuracy)
   - 23 crop varieties
   - RandomForestRegressor algorithm

### Frontend (streamlit_app.py)
- Interactive input forms
- Real-time predictions
- Visualizations and explanations
- AI farming plans
- What-if scenarios

### Backend (recommender.py)
- Model loading and caching
- Feature engineering (7→21 features)
- Dual predictions (crop + yield)
- Fallback mechanisms

### Explainability (explainability.py)
- Crop-specific optimal ranges
- Feature importance display
- Status indicators (✓ Optimal, ~ Acceptable, ✗ Needs Adjustment)
- Agricultural insights

### AI Integration (ai_planner.py)
- Google Gemini 2.0 Flash
- Custom farming plans
- Season-specific advice
- Fallback rule-based plans

## 🛠️ Maintenance

### Updating Models
If you retrain models, copy new `.pkl` files here:
```bash
cp ../training_scripts/crop_model.pkl .
cp ../training_scripts/yield_model.pkl .
```

### Updating Ranges
Regenerate optimal ranges after retraining:
```bash
cd ../testing_scripts
python generate_ranges.py
# Copy output to ../app/crop_optimal_ranges.json
```

### Updating Dependencies
```bash
pip freeze > requirements.txt
```

## 📊 Performance

- **Model Loading:** <1 second
- **Prediction Time:** <250ms (crop + yield)
- **Memory Usage:** ~80MB
- **Concurrent Users:** 50+ per instance

## ⚠️ Important Notes

1. **Do NOT delete any files in this folder** - all are required for the app to run
2. Models are pre-trained - no training scripts needed here
3. Virtual environment (venv/) can be recreated but saves setup time
4. __pycache__/ is auto-generated, safe to delete but will regenerate
5. .env file should never be committed to version control (contains API keys)

## 🔐 Security

- Keep `.env` file secure (contains API keys)
- Never commit `.env` to Git
- Use environment variables in production
- Rotate API keys periodically

## 📞 Need Help?

- Check `../README.md` for main documentation
- See `../documentation/` for detailed guides
- Review `../PROJECT_PRESENTATION_REPORT.md` for technical details
