"""
Utility Functions for Crop Recommendation System
Validation, weather data, logging, and helper functions
"""

import os
import logging
from typing import Dict, Any, Optional
from datetime import datetime
import json


def setup_logging(log_dir: str = 'logs', log_level: int = logging.INFO):
    """
     Setup logging configuration
    
    Args:
        log_dir: Directory to store log files
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
    """
    os.makedirs(log_dir, exist_ok=True)
    
    log_filename = os.path.join(
        log_dir, 
        f"crop_system_{datetime.now().strftime('%Y%m%d')}.log"
    )
    
    logging.basicConfig(
        level=log_level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_filename),
            logging.StreamHandler()
        ]
    )
    
    return logging.getLogger(__name__)


def validate_soil_features(features: Dict[str, float]) -> Dict[str, Any]:
    """
     Validate soil feature inputs
    
    Args:
        features: Dictionary with soil and environmental features
        
    Returns:
        Dictionary with 'valid' boolean and 'errors' list
    """
    errors = []
    required_fields = ['N', 'P', 'K', 'temperature', 'humidity', 'pH', 'rainfall']
    
    # Check for missing fields
    for field in required_fields:
        if field not in features:
            errors.append(f"Missing required field: {field}")
    
    if errors:
        return {'valid': False, 'errors': errors}
    
    # Validate ranges
    validations = {
        'N': (0, 300, "Nitrogen (N) must be between 0-300 kg/ha"),
        'P': (0, 150, "Phosphorus (P) must be between 0-150 kg/ha"),
        'K': (0, 210, "Potassium (K) must be between 0-210 kg/ha"),
        'temperature': (-10, 50, "Temperature must be between -10 to 50°C"),
        'humidity': (0, 100, "Humidity must be between 0-100%"),
        'pH': (3, 10, "pH must be between 3-10"),
        'rainfall': (0, 500, "Rainfall must be between 0-500 mm")
    }
    
    for field, (min_val, max_val, error_msg) in validations.items():
        value = features.get(field, 0)
        if not isinstance(value, (int, float)):
            errors.append(f"{field} must be a number")
        elif value < min_val or value > max_val:
            errors.append(error_msg)
    
    return {
        'valid': len(errors) == 0,
        'errors': errors
    }


def format_crop_name(crop: str) -> str:
    """
     Format crop name for display
    
    Args:
        crop: Raw crop name
        
    Returns:
        Formatted crop name
    """
    # Handle special cases
    special_cases = {
        'kidneybeans': 'Kidney Beans',
        'pigeonpeas': 'Pigeon Peas',
        'mothbeans': 'Moth Beans',
        'mungbean': 'Mung Bean',
        'blackgram': 'Black Gram',
        'pomegranate': 'Pomegranate',
        'muskmelon': 'Muskmelon',
        'watermelon': 'Watermelon'
    }
    
    crop_lower = crop.lower()
    if crop_lower in special_cases:
        return special_cases[crop_lower]
    
    return crop.title()


def get_season_recommendation(crop: str) -> str:
    """
     Get planting season recommendation for a crop
    
    Args:
        crop: Name of the crop
        
    Returns:
        Season recommendation string
    """
    # Crop season mapping (simplified for Indian context)
    season_map = {
        'rice': 'Kharif (June-July) or Rabi (November-December)',
        'wheat': 'Rabi (October-November)',
        'maize': 'Kharif (June-July) or Rabi (October-November)',
        'cotton': 'Kharif (May-June)',
        'chickpea': 'Rabi (October-November)',
        'kidneybeans': 'Kharif (June-July)',
        'pigeonpeas': 'Kharif (June-July)',
        'mothbeans': 'Kharif (July-August)',
        'mungbean': 'Kharif (June-July) or Summer (February-March)',
        'blackgram': 'Kharif (June-July)',
        'lentil': 'Rabi (October-November)',
        'pomegranate': 'Year-round (best: June-July)',
        'banana': 'Year-round (best: September-October)',
        'mango': 'July-August',
        'grapes': 'January-February',
        'watermelon': 'Summer (February-March)',
        'muskmelon': 'Summer (February-March)',
        'apple': 'December-January',
        'orange': 'July-August',
        'papaya': 'Year-round (best: September-October)',
        'coconut': 'Year-round (best: September-October)',
        'coffee': 'June-July',
        'jute': 'March-April'
    }
    
    crop_lower = crop.lower()
    return season_map.get(crop_lower, 'Consult local agricultural extension service')


def get_crop_duration(crop: str) -> str:
    """
     Get typical crop duration
    
    Args:
        crop: Name of the crop
        
    Returns:
        Duration string
    """
    duration_map = {
        'rice': '120-150 days',
        'wheat': '110-130 days',
        'maize': '90-120 days',
        'cotton': '150-180 days',
        'chickpea': '90-120 days',
        'kidneybeans': '90-120 days',
        'pigeonpeas': '150-180 days',
        'mothbeans': '75-90 days',
        'mungbean': '60-75 days',
        'blackgram': '70-90 days',
        'lentil': '110-130 days',
        'pomegranate': 'Perennial (harvest: 6-7 months)',
        'banana': '12-15 months',
        'mango': 'Perennial (harvest: 3-6 months)',
        'grapes': 'Perennial (harvest: 120-150 days)',
        'watermelon': '80-100 days',
        'muskmelon': '80-100 days',
        'apple': 'Perennial (harvest: 4-5 months)',
        'orange': 'Perennial (harvest: 6-8 months)',
        'papaya': '9-12 months',
        'coconut': 'Perennial (harvest: year-round)',
        'coffee': 'Perennial (harvest: 6-8 months)',
        'jute': '120-150 days'
    }
    
    crop_lower = crop.lower()
    return duration_map.get(crop_lower, 'Variable')


def save_prediction_history(prediction_data: Dict[str, Any], 
                            output_dir: str = 'history'):
    """
     Save prediction to history file
    
    Args:
        prediction_data: Dictionary with prediction results
        output_dir: Directory to save history
    """
    os.makedirs(output_dir, exist_ok=True)
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = os.path.join(output_dir, f"prediction_{timestamp}.json")
    
    # Add timestamp to data
    prediction_data['timestamp'] = timestamp
    
    try:
        with open(filename, 'w') as f:
            json.dump(prediction_data, f, indent=2)
        print(f" Prediction saved to {filename}")
    except Exception as e:
        print(f" Failed to save prediction: {str(e)}")


def calculate_cost_benefit(crop: str, yield_estimate: float, 
                          area_hectares: float = 1.0) -> Dict[str, float]:
    """
     Calculate approximate cost-benefit analysis
    
    Args:
        crop: Name of the crop
        yield_estimate: Estimated yield in quintals/hectare
        area_hectares: Farm area in hectares
        
    Returns:
        Dictionary with cost, revenue, and profit estimates
    """
    # Approximate costs per hectare (INR) - simplified
    cost_map = {
        'rice': 35000,
        'wheat': 30000,
        'maize': 32000,
        'cotton': 40000,
        'chickpea': 25000,
        'kidneybeans': 28000,
        'pigeonpeas': 27000,
        'mothbeans': 22000,
        'mungbean': 24000,
        'blackgram': 23000,
        'lentil': 26000,
        'pomegranate': 80000,
        'banana': 70000,
        'mango': 60000,
        'grapes': 90000,
        'watermelon': 35000,
        'muskmelon': 33000,
        'apple': 75000,
        'orange': 65000,
        'papaya': 45000,
        'coconut': 50000,
        'coffee': 55000,
        'jute': 28000
    }
    
    # Approximate market price per quintal (INR)
    price_map = {
        'rice': 2000,
        'wheat': 1900,
        'maize': 1600,
        'cotton': 5500,
        'chickpea': 5000,
        'kidneybeans': 6000,
        'pigeonpeas': 5500,
        'mothbeans': 4500,
        'mungbean': 7000,
        'blackgram': 6500,
        'lentil': 5500,
        'pomegranate': 4000,
        'banana': 1200,
        'mango': 3000,
        'grapes': 3500,
        'watermelon': 800,
        'muskmelon': 1000,
        'apple': 5000,
        'orange': 2500,
        'papaya': 1500,
        'coconut': 2000,
        'coffee': 8000,
        'jute': 3500
    }
    
    crop_lower = crop.lower()
    cost_per_ha = cost_map.get(crop_lower, 35000)
    price_per_quintal = price_map.get(crop_lower, 2000)
    
    total_cost = cost_per_ha * area_hectares
    total_yield = yield_estimate * area_hectares
    total_revenue = total_yield * price_per_quintal
    total_profit = total_revenue - total_cost
    profit_margin = (total_profit / total_revenue * 100) if total_revenue > 0 else 0
    
    return {
        'cost': round(total_cost, 2),
        'revenue': round(total_revenue, 2),
        'profit': round(total_profit, 2),
        'profit_margin': round(profit_margin, 2),
        'break_even_yield': round(total_cost / price_per_quintal, 2)
    }


def get_crop_emoji(crop: str) -> str:
    """
     Get emoji for crop
    
    Args:
        crop: Name of the crop
        
    Returns:
        Emoji string
    """
    emoji_map = {
        'rice': '🌾',
        'wheat': '🌾',
        'maize': '🌽',
        'cotton': '☁️',
        'chickpea': '🫘',
        'kidneybeans': '🫘',
        'pigeonpeas': '🫘',
        'mothbeans': '🫘',
        'mungbean': '🫘',
        'blackgram': '🫘',
        'lentil': '🫘',
        'pomegranate': '🍎',
        'banana': '🍌',
        'mango': '🥭',
        'grapes': '🍇',
        'watermelon': '🍉',
        'muskmelon': '🍈',
        'apple': '🍎',
        'orange': '🍊',
        'papaya': '🍈',
        'coconut': '🥥',
        'coffee': '☕',
        'jute': '🌿'
    }
    
    crop_lower = crop.lower()
    return emoji_map.get(crop_lower, '🌱')


if __name__ == "__main__":
    # Test utility functions
    print(" Testing Utility Functions...\n")
    
    # Test validation
    print("1. Testing validation:")
    test_features = {
        'N': 90,
        'P': 42,
        'K': 43,
        'temperature': 20.5,
        'humidity': 82.0,
        'pH': 6.5,
        'rainfall': 202.0
    }
    
    validation = validate_soil_features(test_features)
    print(f"   Valid: {validation['valid']}")
    
    # Test crop formatting
    print("\n2. Testing crop formatting:")
    print(f"   kidneybeans → {format_crop_name('kidneybeans')}")
    print(f"   rice → {format_crop_name('rice')}")
    
    # Test season recommendation
    print("\n3. Testing season recommendation:")
    print(f"   Rice: {get_season_recommendation('rice')}")
    
    # Test cost-benefit
    print("\n4. Testing cost-benefit analysis:")
    cb = calculate_cost_benefit('rice', 50, 2)
    print(f"   Cost: ₹{cb['cost']:,.0f}")
    print(f"   Revenue: ₹{cb['revenue']:,.0f}")
    print(f"   Profit: ₹{cb['profit']:,.0f}")
    print(f"   Margin: {cb['profit_margin']:.1f}%")
    
    print("\n Test completed!")
