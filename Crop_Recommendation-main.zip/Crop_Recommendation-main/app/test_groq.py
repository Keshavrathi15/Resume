"""
Test script to verify Groq API is working
Run this after adding GROQ_API_KEY to .env file
"""

import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

print("="*60)
print(" TESTING GROQ API CONNECTION")
print("="*60)

# Check if API key exists
groq_key = os.getenv('GROQ_API_KEY')

if not groq_key:
    print("\n GROQ_API_KEY not found in .env file")
    print("\n Follow these steps:")
    print("1. Get free API key: https://console.groq.com")
    print("2. Open app/.env file")
    print("3. Add: GROQ_API_KEY=gsk_your_key_here")
    print("4. Save and run this test again")
    exit(1)

print(f"\n API key found: {groq_key[:10]}...{groq_key[-5:]}")

# Try to import groq library
try:
    from groq import Groq
    print(" Groq library installed")
except ImportError:
    print("\n Groq library not installed")
    print("\n Run this command:")
    print("   pip install groq")
    exit(1)

# Test API connection
print("\n Testing API connection...")

try:
    client = Groq(api_key=groq_key)
    
    # Simple test request
    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",  # Updated to latest active model
        messages=[
            {
                "role": "user",
                "content": "Say 'Hello from Groq!' in exactly 5 words."
            }
        ],
        temperature=0.5,
        max_tokens=20
    )
    
    result = response.choices[0].message.content
    
    print(f"\n API CONNECTION SUCCESSFUL!")
    print(f"\n Groq Response: {result}")
    print(f"\n Model: {response.model}")
    print(f"  Usage: {response.usage.total_tokens} tokens")
    
    print("\n" + "="*60)
    print("🎉 SUCCESS! Your Groq API is working perfectly!")
    print("="*60)
    print("\n You can now:")
    print("   1. Run your Streamlit app: streamlit run streamlit_app.py")
    print("   2. Generate AI farming plans with Groq (super fast!)")
    print("   3. Enjoy 14,400 FREE requests per day")
    
except Exception as e:
    print(f"\n API Error: {str(e)}")
    print("\n Troubleshooting:")
    print("   1. Check API key is correct (should start with 'gsk_')")
    print("   2. Check internet connection")
    print("   3. Verify key is active at: https://console.groq.com")
    exit(1)
