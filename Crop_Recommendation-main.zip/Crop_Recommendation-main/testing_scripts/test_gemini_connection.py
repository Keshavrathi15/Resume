"""
Quick test script to verify Gemini API connectivity
Run this before starting the main app to diagnose connection issues
"""

import os
from dotenv import load_dotenv
import google.generativeai as genai

# Suppress warnings
os.environ['GRPC_VERBOSITY'] = 'ERROR'
os.environ['GLOG_minloglevel'] = '2'

# Load environment
load_dotenv()

print("=" * 60)
print("🧪 GEMINI API CONNECTION TEST")
print("=" * 60)

# Step 1: Check API key
api_key = os.getenv('GEMINI_API_KEY')
print("\n1️⃣ Checking API Key...")
if not api_key:
    print("   ❌ GEMINI_API_KEY not found in .env file")
    print("   💡 Add GEMINI_API_KEY=your_key to the .env file")
    exit(1)
else:
    print(f"   ✅ API Key found: {api_key[:10]}...{api_key[-5:]}")
    if not api_key.startswith('AIza'):
        print(f"   ⚠️ WARNING: Key format unusual (should start with 'AIza')")

# Step 2: Configure Gemini
print("\n2️⃣ Configuring Gemini...")
try:
    genai.configure(api_key=api_key)
    print("   ✅ Configuration successful")
except Exception as e:
    print(f"   ❌ Configuration failed: {e}")
    exit(1)

# Step 3: Initialize model
print("\n3️⃣ Initializing Gemini 2.0 Flash model...")
try:
    generation_config = {
        'temperature': 0.7,
        'top_p': 0.95,
        'top_k': 40,
        'max_output_tokens': 512,  # Smaller for test
    }
    model = genai.GenerativeModel(
        'gemini-2.0-flash-exp',
        generation_config=generation_config
    )
    print("   ✅ Model initialized")
except Exception as e:
    print(f"   ❌ Model initialization failed: {e}")
    exit(1)

# Step 4: Test connectivity to Google's API (optional check)
print("\n4️⃣ Testing network connectivity to Google APIs...")
try:
    import socket
    
    # Test DNS resolution
    print("   📡 Testing DNS resolution...")
    socket.gethostbyname('google.com')
    print("   ✅ Basic internet connection confirmed")
    
except socket.error as e:
    print(f"   ⚠️ DNS check failed: {e}")
    print("   Continuing anyway - API may still work...")

# Step 5: Test simple generation
print("\n5️⃣ Testing API with simple request...")
print("   ⏳ Sending test prompt (30s timeout)...")
try:
    response = model.generate_content(
        "Say 'Hello' in JSON format: {\"message\": \"...\"}",
        request_options={'timeout': 30}
    )
    print(f"   ✅ Response received: {response.text[:100]}")
except Exception as e:
    error_msg = str(e)
    error_type = type(e).__name__
    print(f"   ❌ Generation failed: {error_type}")
    print(f"   Error details: {error_msg[:300]}")
    
    # Check for quota errors first
    if '429' in error_msg or 'quota' in error_msg.lower() or error_type == 'ResourceExhausted':
        print("\n🚨 API QUOTA EXCEEDED!")
        print("   Your Gemini API key has reached its usage limit")
        print("\n💡 SOLUTIONS:")
        print("   1. ⏰ Wait 1 minute and try again")
        print("      Free tier: 15 requests per minute")
        print("\n   2. 📊 Check your usage:")
        print("      https://ai.dev/usage?tab=rate-limit")
        print("\n   3. 🔑 Get a new API key:")
        print("      https://makersuite.google.com/app/apikey")
        print("\n   4. ⬆️ Upgrade your plan (if you need higher limits)")
        print("      https://ai.google.dev/gemini-api/docs/pricing")
        print("\n   ✅ The app will use rules-based plans until quota resets")
        exit(1)
    
    # Specific error diagnostics
    elif '503' in error_msg or 'socket' in error_msg.lower():
        print("\n🚨 NETWORK/FIREWALL ISSUE DETECTED:")
        print("   • Google's API servers are unreachable")
        print("   • This is NOT an API key problem")
        print("\n💡 SOLUTIONS:")
        print("   1. Check Windows Firewall:")
        print("      - Open Windows Defender Firewall")
        print("      - Click 'Allow an app through firewall'")
        print("      - Ensure Python is allowed for both Private and Public networks")
        print("\n   2. Disable VPN temporarily (if using one)")
        print("\n   3. Check antivirus settings:")
        print("      - Some antivirus software blocks API calls")
        print("      - Add exception for Python/generativelanguage.googleapis.com")
        print("\n   4. Try from different network:")
        print("      - Use mobile hotspot to test if it's network-specific")
        print("\n   5. Check with your network admin:")
        print("      - Corporate/school networks may block Google APIs")
    else:
        print("\n💡 TROUBLESHOOTING:")
        print("   • Verify API key at https://makersuite.google.com/")
        print("   • Check API quota/billing")
        print("   • Try again in a few minutes (may be rate limited)")
    exit(1)

# Step 6: Test farming plan generation
print("\n6️⃣ Testing farming plan generation...")
print("   ⏳ Generating sample plan (30s timeout)...")
try:
    prompt = """Create a farming plan for RICE as JSON.

CONDITIONS: N=80 kg/ha, P=40 kg/ha, K=40 kg/ha, Temp=25°C, Humidity=80%, pH=6.5, Rainfall=200mm

Return ONLY valid JSON with NO markdown, following this structure:
{
  "crop_overview": {"growth_duration": "120-150 days"},
  "fertilizer_schedule": [{"stage": "Basal", "days": 0, "npk": "10:26:26", "amount": "100 kg/ha"}]
}"""
    
    response = model.generate_content(
        prompt,
        request_options={'timeout': 30}
    )
    print(f"   ✅ Plan generated successfully!")
    print(f"   Response length: {len(response.text)} characters")
    print(f"   Preview: {response.text[:200]}...")
except Exception as e:
    print(f"   ❌ Plan generation failed: {type(e).__name__}")
    print(f"   Error details: {str(e)[:300]}")
    print("\n   ⚠️ Warning: Simple test passed but complex generation failed")
    print("   This may indicate network instability or timeout issues")
    exit(1)

print("\n" + "=" * 60)
print("✅ ALL TESTS PASSED!")
print("=" * 60)
print("\n💡 Your Gemini API connection is working properly.")
print("   You can now run the main app: streamlit run streamlit_app.py")
print()
