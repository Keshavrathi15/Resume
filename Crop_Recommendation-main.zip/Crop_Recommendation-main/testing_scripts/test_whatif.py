from recommender import CropRecommender

recommender = CropRecommender('crop_model.pkl')

# Original rice conditions
soil_features = {
    'N': 90, 'P': 42, 'K': 43,
    'temperature': 20.5, 'humidity': 82,
    'pH': 6.5, 'rainfall': 202
}

print("=" * 80)
print("Testing What-If Scenarios")
print("=" * 80)

# Test 1: No change
print("\n1. BASELINE (Original - Should be Rice):")
result = recommender.predict_crop(soil_features)
print(f"   Crop: {result['recommended_crop']} ({result['confidence']:.2f}%)")

# Test 2: Increase N significantly
print("\n2. Increase N by +50 (90 → 140):")
modified1 = soil_features.copy()
modified1['N'] = 140
result1 = recommender.predict_crop(modified1)
print(f"   Crop: {result1['recommended_crop']} ({result1['confidence']:.2f}%)")

# Test 3: Decrease N, increase P and K
print("\n3. N -50, P +40, K +40 (40, 82, 83):")
modified2 = soil_features.copy()
modified2['N'] = 40
modified2['P'] = 82
modified2['K'] = 83
result2 = recommender.predict_crop(modified2)
print(f"   Crop: {result2['recommended_crop']} ({result2['confidence']:.2f}%)")

# Test 4: Use simulate_what_if
print("\n4. Using simulate_what_if with N+30:")
whatif = recommender.simulate_what_if(soil_features, {'N': 120})
print(f"   Current: {whatif['current']['crop']} ({whatif['current']['confidence']:.2f}%)")
print(f"   Modified: {whatif['modified']['crop']} ({whatif['modified']['confidence']:.2f}%)")
print(f"   Recommendation: {whatif['recommendation']}")

print("\n5. Using simulate_what_if with N-70, P+40, K+40:")
whatif2 = recommender.simulate_what_if(soil_features, {'N': 20, 'P': 82, 'K': 83})
print(f"   Current: {whatif2['current']['crop']} ({whatif2['current']['confidence']:.2f}%)")
print(f"   Modified: {whatif2['modified']['crop']} ({whatif2['modified']['confidence']:.2f}%)")
print(f"   Recommendation: {whatif2['recommendation']}")

print("\n" + "=" * 80)
