"""
Display features used by both Classifier and Regressor models
"""

import pickle
import sys

print("="*70)
print("📊 MODEL FEATURES COMPARISON")
print("="*70)

# Load Classifier Model
try:
    with open('crop_model.pkl', 'rb') as f:
        classifier_data = pickle.load(f)
    
    print("\n🎯 CLASSIFIER MODEL (crop_model.pkl)")
    print("="*70)
    print(f"Model Name: {classifier_data.get('model_name', 'Unknown')}")
    print(f"Accuracy: {classifier_data.get('accuracy', 0)*100:.2f}%")
    print(f"\n📋 Features Used: {len(classifier_data['feature_names'])}")
    print("-"*70)
    
    for i, feature in enumerate(classifier_data['feature_names'], 1):
        print(f"{i:2d}. {feature}")
    
except Exception as e:
    print(f"❌ Error loading classifier: {e}")

# Load Regressor Model
print("\n" + "="*70)
try:
    with open('yield_model.pkl', 'rb') as f:
        regressor_data = pickle.load(f)
    
    print("\n📈 REGRESSOR MODEL (yield_model.pkl)")
    print("="*70)
    print(f"Model Name: {regressor_data.get('model_name', 'Unknown')}")
    print(f"R² Score: {regressor_data.get('r2_score', 0):.4f}")
    print(f"RMSE: {regressor_data.get('rmse', 0):.2f} q/ha")
    print(f"\n📋 Features Used: {len(regressor_data['feature_columns'])}")
    print("-"*70)
    
    for i, feature in enumerate(regressor_data['feature_columns'], 1):
        print(f"{i:2d}. {feature}")
    
except Exception as e:
    print(f"❌ Error loading regressor: {e}")

# Compare features
print("\n" + "="*70)
print("🔍 FEATURE COMPARISON")
print("="*70)

try:
    classifier_features = set(classifier_data['feature_names'])
    regressor_features = set(regressor_data['feature_columns'])
    
    common_features = classifier_features & regressor_features
    classifier_only = classifier_features - regressor_features
    regressor_only = regressor_features - classifier_features
    
    print(f"\n✅ Common Features ({len(common_features)}):")
    for feat in sorted(common_features):
        print(f"   • {feat}")
    
    print(f"\n🎯 Classifier Only ({len(classifier_only)}):")
    for feat in sorted(classifier_only):
        print(f"   • {feat}")
    
    print(f"\n📈 Regressor Only ({len(regressor_only)}):")
    for feat in sorted(regressor_only):
        print(f"   • {feat}")
    
except:
    pass

print("\n" + "="*70)
