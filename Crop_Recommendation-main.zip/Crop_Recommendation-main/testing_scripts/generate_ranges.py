"""
Generate dataset-driven explainability rules
Calculates optimal ranges from actual training data
"""

import pandas as pd
import json
import numpy as np

def generate_crop_specific_ranges(dataset_path):
    """Generate optimal ranges for each crop based on percentiles"""
    
    df = pd.read_csv(dataset_path)
    
    features = ['n', 'p', 'k', 'temperature', 'humidity', 'ph', 'rainfall']
    crops = df['crop'].unique()
    
    crop_ranges = {}
    
    print("Generating dataset-driven optimal ranges for each crop...")
    print("=" * 80)
    
    for crop in crops:
        crop_df = df[df['crop'] == crop]
        crop_ranges[crop.lower()] = {}
        
        for feat in features:
            if feat in crop_df.columns:
                # Use 25th-75th percentile as "optimal" range
                p25 = crop_df[feat].quantile(0.25)
                p75 = crop_df[feat].quantile(0.75)
                mean = crop_df[feat].mean()
                
                # Use 10th-90th percentile as "acceptable" range
                p10 = crop_df[feat].quantile(0.10)
                p90 = crop_df[feat].quantile(0.90)
                
                crop_ranges[crop.lower()][feat] = {
                    'optimal_min': float(p25),
                    'optimal_max': float(p75),
                    'acceptable_min': float(p10),
                    'acceptable_max': float(p90),
                    'mean': float(mean)
                }
        
        print(f"✓ {crop}: {len(crop_df)} samples analyzed")
    
    # Save to JSON
    with open('crop_optimal_ranges.json', 'w') as f:
        json.dump(crop_ranges, f, indent=2)
    
    print("\n✅ Saved crop-specific ranges to crop_optimal_ranges.json")
    print(f"   Total crops: {len(crops)}")
    print(f"   Features per crop: {len(features)}")
    
    return crop_ranges

if __name__ == '__main__':
    ranges = generate_crop_specific_ranges('../smartcrop_cleaned.csv')
    
    # Show example for rice
    print("\n" + "=" * 80)
    print("EXAMPLE: Rice Optimal Ranges")
    print("=" * 80)
    if 'rice' in ranges:
        for feat, vals in ranges['rice'].items():
            print(f"\n{feat.upper()}:")
            print(f"  Optimal: {vals['optimal_min']:.1f} - {vals['optimal_max']:.1f}")
            print(f"  Acceptable: {vals['acceptable_min']:.1f} - {vals['acceptable_max']:.1f}")
            print(f"  Mean: {vals['mean']:.1f}")
