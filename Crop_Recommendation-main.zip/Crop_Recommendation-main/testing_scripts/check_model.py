import pickle

# Load the model
with open('crop_model.pkl', 'rb') as f:
    model_data = pickle.load(f)

print("=" * 80)
print("MODEL INFORMATION")
print("=" * 80)
print(f"Model Type: {model_data['model_name']}")
print(f"Accuracy: {model_data['accuracy']*100:.2f}%")
print(f"Training Date: {model_data.get('training_date', 'Unknown')}")
print(f"Number of Features: {model_data['n_features']}")
print(f"\nFeature Names Used:")
for i, feat in enumerate(model_data['feature_names'], 1):
    print(f"  {i}. {feat}")

model = model_data['model']
print(f"\nCrops Trained On ({len(model.classes_)} total):")
for crop in sorted(model.classes_):
    print(f"  - {crop}")

print("\n" + "=" * 80)
print("EXPLAINABILITY STATUS")
print("=" * 80)
print("Type: Rule-based (not trained)")
print("Method: Uses predefined templates for each feature")
print("Features Covered:")

from explainability import generate_feature_explanations

# Test with dummy data
test_importance = {feat: 5.0 for feat in model_data['feature_names'][:5]}
test_values = {
    'N': 90, 'P': 42, 'K': 43,
    'temperature': 25, 'humidity': 70,
    'pH': 6.5, 'rainfall': 150
}

explanations = generate_feature_explanations(test_importance, test_values, 'rice')
print(f"  ✓ {len(explanations)} features have explanation templates")
print("\nSample Explanation:")
if explanations:
    print(f"  Feature: {explanations[0]['feature']}")
    print(f"  Reason: {explanations[0]['reason']}")

print("\n" + "=" * 80)
