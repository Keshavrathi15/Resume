"""
Test Dataset-Driven Explainability
Compare old hardcoded vs new data-driven explanations
"""

import json
from explainability import _get_status_for_crop, _load_crop_ranges

def test_rice_nitrogen():
    """Test rice nitrogen explanation - should now be more accurate"""
    
    print("🌾 Testing Rice Nitrogen Explainability")
    print("=" * 50)
    
    # Load the dataset-driven ranges
    ranges = _load_crop_ranges()
    
    if 'rice' in ranges and 'N' in ranges['rice']:
        rice_n = ranges['rice']['N']
        print(f"📊 Dataset Rice Nitrogen ranges:")
        print(f"   Optimal: {rice_n['min']:.1f} - {rice_n['max']:.1f} kg/ha")
        print(f"   Mean: {rice_n['mean']:.1f} kg/ha")
        print()
        
        # Test different nitrogen values
        test_values = [50, 70, 80, 95, 120]
        
        for n_val in test_values:
            status = _get_status_for_crop('N', n_val, 'rice')
            print(f"   N = {n_val:3d} kg/ha → {status}")
        
        print()
        print("🔍 Old hardcoded system would have said:")
        print("   N = 50-150 kg/ha is 'optimal' (generic agricultural range)")
        print()
        print("✅ New dataset-driven system says:")
        print(f"   N = {rice_n['min']:.0f}-{rice_n['max']:.0f} kg/ha is 'optimal' (actual rice data)")
        
    else:
        print("❌ Could not load rice nitrogen ranges")

def test_multiple_crops():
    """Test explainability for multiple crops"""
    
    print("\n🌱 Testing Multiple Crops")
    print("=" * 50)
    
    ranges = _load_crop_ranges()
    test_cases = [
        ('rice', 'N', 80),
        ('wheat', 'N', 50),
        ('cotton', 'humidity', 65),
        ('coffee', 'temperature', 25)
    ]
    
    for crop, feature, value in test_cases:
        if crop in ranges and feature in ranges[crop]:
            status = _get_status_for_crop(feature, value, crop)
            crop_range = ranges[crop][feature]
            print(f"{crop:10s} {feature:11s} = {value:3.0f} → {status:10s} (optimal: {crop_range['min']:.1f}-{crop_range['max']:.1f})")

if __name__ == "__main__":
    test_rice_nitrogen()
    test_multiple_crops()