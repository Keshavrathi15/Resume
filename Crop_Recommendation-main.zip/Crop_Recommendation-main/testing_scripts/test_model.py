from recommender import CropRecommender

recommender = CropRecommender('crop_model.pkl')

# Test different NPK combinations
test_cases = [
    {
        'name': 'Rice conditions (original)',
        'N': 90, 'P': 42, 'K': 43,
        'temperature': 20.5, 'humidity': 82, 'pH': 6.5, 'rainfall': 202
    },
    {
        'name': 'Low N, High P, High K',
        'N': 20, 'P': 80, 'K': 80,
        'temperature': 25, 'humidity': 70, 'pH': 6.5, 'rainfall': 150
    },
    {
        'name': 'High N, Low P, Low K',
        'N': 120, 'P': 20, 'K': 20,
        'temperature': 25, 'humidity': 70, 'pH': 6.5, 'rainfall': 150
    },
    {
        'name': 'Medium NPK',
        'N': 50, 'P': 50, 'K': 50,
        'temperature': 25, 'humidity': 70, 'pH': 6.5, 'rainfall': 150
    },
    {
        'name': 'High temp, low rainfall (dry)',
        'N': 50, 'P': 50, 'K': 50,
        'temperature': 35, 'humidity': 40, 'pH': 7.5, 'rainfall': 50
    },
    {
        'name': 'Low temp, high rainfall (wet)',
        'N': 50, 'P': 50, 'K': 50,
        'temperature': 15, 'humidity': 90, 'pH': 6.0, 'rainfall': 300
    },
]

print('=' * 80)
print('Testing Model Predictions with Different Soil Conditions')
print('=' * 80)

for test in test_cases:
    name = test.pop('name')
    result = recommender.predict_crop(test)
    
    print(f'\n{name}:')
    print(f'  Input: N={test["N"]}, P={test["P"]}, K={test["K"]}, Temp={test["temperature"]}, Rain={test["rainfall"]}')
    print(f'  Predicted Crop: {result["recommended_crop"]}')
    print(f'  Confidence: {result["confidence"]:.2f}%')
    alts = [f'{alt["crop"]} ({alt["confidence"]:.2f}%)' for alt in result["alternatives"][:5]]
    print(f'  Top 5 alternatives: {alts}')

print('\n' + '=' * 80)
print('Analysis:')
print('If all predictions show the same crop, the model may be overfitted or')
print('the feature engineering is dominating the predictions.')
print('=' * 80)
