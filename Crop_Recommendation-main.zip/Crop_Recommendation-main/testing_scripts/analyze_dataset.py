import pandas as pd
import numpy as np

# Load the dataset
try:
    df = pd.read_csv('../smartcrop_cleaned.csv')
    print("=" * 80)
    print("DATASET-BASED ANALYSIS vs HARDCODED RULES")
    print("=" * 80)
    
    print(f"\nDataset Size: {len(df)} samples")
    print(f"Crops: {df['crop'].nunique()} unique crops")
    
    # Analyze each feature's actual ranges
    features = ['n', 'p', 'k', 'temperature', 'humidity', 'ph', 'rainfall']
    
    print("\n" + "=" * 80)
    print("ACTUAL DATA RANGES vs HARDCODED RULES")
    print("=" * 80)
    
    for feat in features:
        if feat in df.columns or feat.lower() in df.columns:
            col = feat if feat in df.columns else feat.lower()
            actual_min = df[col].min()
            actual_max = df[col].max()
            actual_mean = df[col].mean()
            actual_std = df[col].std()
            p25 = df[col].quantile(0.25)
            p75 = df[col].quantile(0.75)
            
            # Hardcoded rules
            rules = {
                'N': (40, 150),
                'P': (20, 80),
                'K': (20, 80),
                'temperature': (15, 35),
                'humidity': (40, 90),
                'ph': (5.5, 7.5),
                'rainfall': (50, 300)
            }
            
            rule_min, rule_max = rules.get(feat, (None, None))
            
            print(f"\n{feat.upper()}:")
            print(f"  Dataset: Min={actual_min:.1f}, Max={actual_max:.1f}, Mean={actual_mean:.1f}, Std={actual_std:.1f}")
            print(f"  Dataset: 25th percentile={p25:.1f}, 75th percentile={p75:.1f}")
            if rule_min and rule_max:
                print(f"  Hardcoded Rule: {rule_min} to {rule_max}")
                if actual_min < rule_min or actual_max > rule_max:
                    print(f"  ⚠️  MISMATCH: Dataset range ({actual_min:.1f}-{actual_max:.1f}) exceeds rule range ({rule_min}-{rule_max})")
                else:
                    print(f"  ✓ Rule covers dataset range")
    
    # Crop-specific analysis for rice
    print("\n" + "=" * 80)
    print("CROP-SPECIFIC ANALYSIS (Rice Example)")
    print("=" * 80)
    
    rice_df = df[df['crop'].str.lower() == 'rice']
    if len(rice_df) > 0:
        print(f"\nRice samples: {len(rice_df)}")
        for feat in ['n', 'p', 'k', 'temperature', 'rainfall']:
            col = feat
            if col in rice_df.columns:
                mean = rice_df[col].mean()
                std = rice_df[col].std()
                p10 = rice_df[col].quantile(0.10)
                p90 = rice_df[col].quantile(0.90)
                print(f"  {feat}: Mean={mean:.1f}, Std={std:.1f}, 10th-90th percentile: {p10:.1f}-{p90:.1f}")
        
        print("\n  💡 Suggested data-driven rule for rice N:")
        rice_n = rice_df['n']
        optimal_min = rice_n.quantile(0.25)
        optimal_max = rice_n.quantile(0.75)
        print(f"     'Optimal' if {optimal_min:.0f} <= N <= {optimal_max:.0f} (based on 25th-75th percentile)")
        print(f"     Current hardcoded: 'Optimal' if 40 <= N <= 150")
    
    print("\n" + "=" * 80)
    print("CONCLUSION")
    print("=" * 80)
    print("Current explainability rules are GENERIC, not dataset-specific.")
    print("They may not accurately reflect what 'optimal' means for your data.")
    print("\nTo make them dataset-based:")
    print("  1. Calculate percentiles for each feature per crop")
    print("  2. Use 25th-75th percentile as 'optimal' range")
    print("  3. Generate dynamic thresholds instead of hardcoded ones")
    
except FileNotFoundError:
    print("❌ Dataset file not found. Make sure smartcrop_cleaned.csv exists in parent directory.")
except Exception as e:
    print(f"❌ Error: {e}")
