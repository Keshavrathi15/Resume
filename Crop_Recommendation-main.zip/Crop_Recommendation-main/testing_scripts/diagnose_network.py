"""
Network Diagnostic Tool for Gemini API Connectivity Issues
Run this to diagnose why AI farming plans are failing
"""

import socket
import sys

def test_dns(hostname):
    """Test DNS resolution"""
    try:
        ip = socket.gethostbyname(hostname)
        print(f"   ✅ {hostname} → {ip}")
        return True
    except socket.error as e:
        print(f"   ❌ {hostname} → Failed: {e}")
        return False

def test_port(hostname, port):
    """Test TCP connection to specific port"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        result = sock.connect_ex((hostname, port))
        sock.close()
        
        if result == 0:
            print(f"   ✅ {hostname}:{port} → Connection successful")
            return True
        else:
            print(f"   ❌ {hostname}:{port} → Connection failed (code: {result})")
            return False
    except Exception as e:
        print(f"   ❌ {hostname}:{port} → Error: {e}")
        return False

print("=" * 70)
print("🔍 NETWORK DIAGNOSTIC FOR GEMINI API")
print("=" * 70)

# Test 1: Basic Internet Connectivity
print("\n1️⃣ Testing Basic Internet Connectivity...")
basic_ok = test_dns('google.com') and test_dns('cloudflare.com')

if not basic_ok:
    print("\n❌ CRITICAL: No internet connection detected!")
    print("   • Check if you're connected to WiFi/Ethernet")
    print("   • Try opening google.com in your browser")
    print("   • Restart your router/modem")
    sys.exit(1)

print("   ✅ Basic internet connectivity confirmed")

# Test 2: Google API DNS Resolution
print("\n2️⃣ Testing Google API DNS Resolution...")
api_dns_ok = (
    test_dns('generativelanguage.googleapis.com') and
    test_dns('googleapis.com')
)

if not api_dns_ok:
    print("\n⚠️ WARNING: Cannot resolve Google API domains")
    print("   • DNS may be blocked or misconfigured")
    print("   • Try changing DNS to Google DNS (8.8.8.8)")
    print("   • Check if corporate/school network blocks Google")

# Test 3: HTTPS Port Connectivity
print("\n3️⃣ Testing HTTPS Port (443) Connectivity...")
port_ok = test_port('googleapis.com', 443)

if not port_ok:
    print("\n🚨 FIREWALL/PROXY ISSUE DETECTED!")
    print("   • Port 443 (HTTPS) is blocked")
    print("   • This is why the API calls are failing")
    print("\n💡 SOLUTIONS:")
    print("   1. Windows Firewall:")
    print("      - Open Windows Defender Firewall")
    print("      - Click 'Allow an app through firewall'")
    print("      - Find Python and check both Private and Public")
    print("\n   2. Antivirus Software:")
    print("      - Check if antivirus is blocking Python")
    print("      - Add exception for Python.exe")
    print("\n   3. Corporate/School Network:")
    print("      - Contact network admin")
    print("      - May need to use different network")
    print("\n   4. VPN:")
    print("      - If using VPN, try disabling it")
    print("      - Some VPNs block API requests")
else:
    print("   ✅ HTTPS port accessible")

# Test 4: Specific Gemini API Endpoint
print("\n4️⃣ Testing Gemini API Endpoint (142.250.202.74:443)...")
gemini_ip_ok = test_port('142.250.202.74', 443)

if not gemini_ip_ok:
    print("\n⚠️ Gemini API server unreachable")
    print("   • This is the exact error you're experiencing")
    print("   • Server may be temporarily down")
    print("   • Or network is blocking this specific IP")

# Final Diagnosis
print("\n" + "=" * 70)
print("📋 DIAGNOSIS SUMMARY")
print("=" * 70)

all_ok = basic_ok and api_dns_ok and port_ok and gemini_ip_ok

if all_ok:
    print("✅ All network tests passed!")
    print("   • Network connectivity is good")
    print("   • Problem may be:")
    print("     - API key issue")
    print("     - API quota exceeded")
    print("     - Temporary Google service outage")
    print("\n💡 Next steps:")
    print("   - Run: python test_gemini_connection.py")
    print("   - Verify API key at https://makersuite.google.com/")
else:
    print("❌ Network issues detected!")
    print("\n🎯 PRIMARY ISSUE:")
    
    if not basic_ok:
        print("   → No internet connection")
        print("   → Check WiFi/Ethernet connection first")
    elif not api_dns_ok:
        print("   → Google API domains are blocked")
        print("   → Change DNS settings or contact network admin")
    elif not port_ok:
        print("   → Port 443 (HTTPS) is blocked by firewall")
        print("   → Configure Windows Firewall to allow Python")
    elif not gemini_ip_ok:
        print("   → Gemini API servers are unreachable")
        print("   → Try different network (mobile hotspot)")
    
    print("\n💡 QUICK FIX:")
    print("   1. Try mobile hotspot to bypass network restrictions")
    print("   2. Disable VPN if active")
    print("   3. Check Windows Firewall settings")
    print("   4. Contact your network administrator")

print("\n" + "=" * 70)
