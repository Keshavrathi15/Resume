#!/usr/bin/env python3
"""
Quick test to verify local operation works
"""

from recommender import CropRecommender

print("🧪 Testing local crop recommendation system...")

# Initialize recommender
recommender = CropRecommender()

# Test sample
sample = {
    'N': 90, 'P': 42, 'K': 43, 
    'temperature': 20.9, 'humidity': 82, 
    'pH': 6.5, 'rainfall': 202.9
}

# Get prediction
result = recommender.predict_crop(sample)

print(f"✅ Local prediction successful!")
print(f"   Result keys: {list(result.keys())}")
print(f"   Result: {result}")

crop = result.get('recommended_crop', 'Unknown')
confidence = result.get('confidence', 0)

print(f"   Recommended Crop: {crop}")
print(f"   Confidence: {confidence:.1f}%")
print(f"   Model: {recommender.model_name}")
print(f"   Alternatives: {len(result.get('alternatives', []))} crops")

print("\n🎉 System is ready for local-only operation!")