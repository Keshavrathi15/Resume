# 🧪 Testing Scripts

This folder contains all testing, debugging, and analysis scripts.

## Test Scripts

### Model Testing
- **test_model.py** - Test crop classifier predictions
- **test_yield_ml.py** - Test yield prediction model
- **check_model.py** - Verify model loading and features
- **compare_models.py** - Compare performance of different models

### Feature Testing
- **test_explainability.py** - Test explainability engine
- **test_whatif.py** - Test what-if scenario simulator
- **test_local.py** - Local testing without web interface

### Analysis Scripts
- **analyze_dataset.py** - Analyze dataset statistics and distributions
- **show_model_features.py** - Display model feature importance
- **generate_ranges.py** - Generate optimal crop-specific ranges

## Usage

### Test Classifier
```bash
cd testing_scripts
python test_model.py
```

### Test Yield Prediction
```bash
cd testing_scripts
python test_yield_ml.py
```

### Analyze Features
```bash
cd testing_scripts
python show_model_features.py
```

### Test Explainability
```bash
cd testing_scripts
python test_explainability.py
```

## What These Scripts Do

### Model Validation
- Verify model accuracy on test data
- Check prediction consistency
- Validate feature engineering
- Test edge cases

### Feature Analysis
- Display feature importance rankings
- Generate crop-specific optimal ranges
- Analyze dataset distributions
- Validate explainability accuracy

### Debugging
- Identify model loading issues
- Check feature computation
- Verify prediction pipeline
- Test error handling

## Notes

⚠️ **These scripts are NOT needed to run the app**
- Use only for development, testing, and debugging
- Require access to models in `../app/`
- May need datasets from `../training_scripts/`
- Helpful for validating changes and improvements

## Requirements

Most scripts require:
- Python 3.8+
- scikit-learn, pandas, numpy
- Access to trained models (`../app/*.pkl`)
- Some may need datasets from `../training_scripts/`
