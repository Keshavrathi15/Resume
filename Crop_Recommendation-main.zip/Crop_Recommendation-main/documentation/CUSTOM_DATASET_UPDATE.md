# ✅ Custom Dataset Support Added!

## What's New

Your crop recommendation system now supports training with your own datasets!

---

## 🎯 Quick Usage

### Basic Command
```powershell
cd app
python train_model.py --dataset "your_data.csv"
```

### With Custom Output Name
```powershell
python train_model.py --dataset "my_crops.csv" --output "my_model.pkl"
```

### View Help
```powershell
python train_model.py --help
```

---

## 📋 What You Need

### Required CSV Columns:
- `N` - Nitrogen (kg/ha)
- `P` - Phosphorus (kg/ha)  
- `K` - Potassium (kg/ha)
- `temperature` - Temperature (°C)
- `humidity` - Humidity (%)
- `pH` (or `ph`) - Soil pH
- `rainfall` - Rainfall (mm)
- `label` - Crop name

### Example CSV:
```csv
N,P,K,temperature,humidity,pH,rainfall,label
90,42,43,20.88,82.00,6.50,202.94,rice
85,58,41,21.77,80.32,7.04,226.66,rice
77,48,30,24.13,60.40,6.79,89.56,maize
```

📄 **Sample template included:** `app/sample_dataset.csv`

---

## 🎨 Features Added

✅ **Command-line arguments** for dataset path
✅ **Custom output path** for trained model
✅ **Automatic column validation** with helpful errors
✅ **pH column variation handling** (pH, ph, PH all work)
✅ **Fallback to synthetic data** if file not found
✅ **Detailed error messages** for troubleshooting
✅ **Help text** with examples

---

## 📚 Documentation

- **Complete Guide**: [CUSTOM_DATASET_GUIDE.md](../CUSTOM_DATASET_GUIDE.md)
- **README Updated**: See main [README.md](../README.md)
- **Quick Start Updated**: See [QUICKSTART.md](../QUICKSTART.md)

---

## 🧪 Test It Now

### 1. Try the sample dataset:
```powershell
cd app
python train_model.py --dataset "sample_dataset.csv"
```

### 2. Use your own data:
```powershell
python train_model.py --dataset "C:\path\to\your_crop_data.csv"
```

### 3. Verify it works:
```powershell
python recommender.py
```

---

## 🔄 Modified Files

1. **train_model.py**
   - Added `argparse` for command-line arguments
   - Added `--dataset` and `--output` options
   - Enhanced column validation
   - Better error messages

2. **CUSTOM_DATASET_GUIDE.md** (NEW)
   - Complete usage guide
   - CSV format examples
   - Troubleshooting tips
   - Best practices

3. **sample_dataset.csv** (NEW)
   - Template file with sample data
   - Shows proper CSV format

4. **README.md**
   - Updated training section
   - Added custom dataset info
   - Link to guide

5. **QUICKSTART.md**
   - Added custom dataset option
   - Link to guide

---

## 💡 Pro Tips

- **Minimum 50 samples per crop** for good accuracy
- **Balance your classes** (equal samples per crop)
- **Use UTF-8 encoding** for CSV files
- **No special characters** in crop names
- **Backup your model** before retraining

---

## 🎉 Ready to Use!

Your system is now fully customizable. Train with your real-world data and get accurate predictions specific to your region!

```powershell
# Full workflow
python train_model.py --dataset "my_data.csv"
streamlit run streamlit_app.py
```

**Enjoy! 🌾**
