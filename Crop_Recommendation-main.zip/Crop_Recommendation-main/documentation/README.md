# 📚 Documentation

This folder contains comprehensive documentation for the Crop Detection system.

## Files

### Main Documentation
- **CUSTOM_DATASET_GUIDE.md** - Guide for creating and using custom datasets
- **CUSTOM_DATASET_UPDATE.md** - Updates and changes to custom dataset handling
- **FEATURE_ENGINEERING.md** - Detailed explanation of feature engineering pipeline
- **feature_engineering_explained.md** - Additional feature engineering documentation
- **NEW_FEATURES.md** - Documentation of new features added to the system
- **QUICKSTART.md** - Quick start guide for getting started
- **YIELD_PREDICTION_README.md** - Complete guide to the yield prediction system
- **overfitting_analysis.md** - Analysis of overfitting and model validation

## Related Documentation

Main documentation files in root directory:
- `../README.md` - Main project README
- `../PROJECT_PRESENTATION_REPORT.md` - Comprehensive technical presentation and report

## Purpose

These documents provide:
- Implementation guides
- Technical explanations
- Feature documentation
- Best practices
- Troubleshooting tips

## Usage

Read these documents to understand:
1. How the system works internally
2. How to customize and extend features
3. Training procedures and methodologies
4. Performance optimization techniques
