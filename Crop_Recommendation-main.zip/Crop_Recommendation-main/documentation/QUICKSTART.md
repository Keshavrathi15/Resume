# Quick Start Guide

## Setup and Run in 3 Steps

### 1️⃣ Install Dependencies
```powershell
cd app
pip install -r requirements.txt
```

### 2️⃣ Train the Model

**Use synthetic data (demo):**
```powershell
python train_model.py
```

**Or use your own dataset:**
```powershell
python train_model.py --dataset "path/to/your_data.csv"
```

Wait for training to complete (~1-2 minutes). The best model will be saved automatically.

📖 **Have your own dataset?** See [CUSTOM_DATASET_GUIDE.md](CUSTOM_DATASET_GUIDE.md)

### 3️⃣ Run the Application

**Option A: Streamlit UI (Recommended for Beginners)**
```powershell
streamlit run streamlit_app.py
```
Open browser: http://localhost:8501

**Option B: FastAPI Backend**
```powershell
python fastapi_app.py
```
API Docs: http://localhost:8000/docs

**Option C: Direct Testing**
```powershell
# Test recommender
python recommender.py

# Test AI planner
python ai_planner.py
```

---

## Example Input

Use these sample values in Streamlit:

- **N**: 90 kg/ha
- **P**: 42 kg/ha
- **K**: 43 kg/ha
- **Temperature**: 20.5°C
- **Humidity**: 82%
- **pH**: 6.5
- **Rainfall**: 202 mm
- **City**: Mumbai

Click **"Run Full Smart Analysis"** to see everything!

---

## Troubleshooting

**Q: Model not found error?**  
A: Run `python train_model.py` first

**Q: Package import errors?**  
A: Run `pip install -r requirements.txt`

**Q: Weather data not working?**  
A: System will use mock data if API key is missing (works fine!)

**Q: AI plans seem generic?**  
A: Set OPENAI_API_KEY or GEMINI_API_KEY for LLM-powered plans

---

See **README.md** for full documentation.
