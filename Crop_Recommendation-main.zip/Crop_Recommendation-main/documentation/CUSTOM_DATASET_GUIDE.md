# Custom Dataset Guide

## 📊 Using Your Own Dataset

The system now supports training with your own crop dataset!

---

## 📋 Dataset Requirements

### Required Columns:
Your CSV file **must** have these columns (case-insensitive):

| Column | Description | Range | Unit |
|--------|-------------|-------|------|
| `N` | Nitrogen content | 0-300 | kg/ha |
| `P` | Phosphorus content | 0-300 | kg/ha |
| `K` | Potassium content | 0-300 | kg/ha |
| `temperature` | Average temperature | 0-60 | °C |
| `humidity` | Relative humidity | 0-100 | % |
| `ph` or `pH` | Soil pH level | 0-14 | - |
| `rainfall` | Monthly rainfall | 0-500 | mm |
| `label` | Crop name | - | text |

---

## 📝 Example CSV Format

```csv
N,P,K,temperature,humidity,pH,rainfall,label
90,42,43,20.879744,82.002744,6.502985,202.935536,rice
85,58,41,21.770462,80.319644,7.038096,226.655537,rice
60,55,44,23.004459,82.320763,7.840207,263.964248,rice
74,35,40,26.491096,80.158363,6.980401,242.864034,rice
78,42,42,20.130175,81.604873,7.628473,262.717340,rice
69,37,42,23.052771,83.683779,7.073270,251.446072,maize
77,48,45,27.752983,80.159682,6.842095,197.872702,cotton
...
```

---

## 🚀 How to Use Your Dataset

### Option 1: Command Line (Recommended)

```powershell
# Navigate to app directory
cd app

# Train with your dataset
python train_model.py --dataset "path/to/your_data.csv"

# Or with custom output name
python train_model.py --dataset "my_crops.csv" --output "my_model.pkl"
```

### Option 2: Place in App Directory

```powershell
# Copy your CSV to the app folder
Copy-Item "C:\path\to\your_data.csv" "app\crop_data.csv"

# Train using it
cd app
python train_model.py --dataset "crop_data.csv"
```

### Option 3: Use Absolute Path

```powershell
python train_model.py --dataset "C:\Users\YourName\Documents\crop_dataset.csv"
```

---

## 🔍 Command Line Options

```powershell
python train_model.py --help
```

**Available options:**

| Option | Short | Description | Default |
|--------|-------|-------------|---------|
| `--dataset` | `-d` | Path to your CSV dataset | None (synthetic) |
| `--output` | `-o` | Output model filename | crop_model.pkl |

**Examples:**

```powershell
# Use synthetic data (default)
python train_model.py

# Use your dataset
python train_model.py -d my_data.csv

# Use your dataset with custom output
python train_model.py -d my_data.csv -o custom_model.pkl

# Full path example
python train_model.py --dataset "C:\Data\crops.csv" --output "production_model.pkl"
```

---

## ✅ Validation & Error Handling

The system automatically:

✓ **Validates column names** (case-insensitive)  
✓ **Checks for missing columns** and shows helpful error  
✓ **Handles pH/ph/PH variations**  
✓ **Removes duplicates** automatically  
✓ **Drops missing values**  
✓ **Encodes crop labels** automatically  
✓ **Falls back to synthetic data** if file not found

---

## 📊 Sample Datasets

### Example 1: Basic Rice Dataset

```csv
N,P,K,temperature,humidity,pH,rainfall,label
90,42,43,21,82,6.5,200,rice
85,58,41,22,80,7.0,225,rice
60,55,44,23,82,7.8,260,rice
```

### Example 2: Multi-Crop Dataset

```csv
N,P,K,temperature,humidity,pH,rainfall,label
90,42,43,21,82,6.5,200,rice
75,50,45,18,65,6.8,100,wheat
70,48,30,25,60,6.5,80,maize
110,40,45,25,80,6.8,90,cotton
180,100,80,30,75,6.5,180,sugarcane
```

---

## 🐛 Common Issues & Solutions

### Issue 1: Missing Columns Error

```
ERROR: Missing required columns: ['temperature', 'humidity']
```

**Solution:** Check your CSV has all required columns. Column names are case-insensitive.

### Issue 2: File Not Found

```
WARNING: Dataset file not found: my_data.csv
```

**Solution:** 
- Use absolute path: `--dataset "C:\full\path\to\data.csv"`
- Or place file in `app` directory

### Issue 3: pH Column Not Recognized

```
ERROR: Missing required columns: ['ph']
```

**Solution:** Rename your column to `pH`, `ph`, or `PH` (all accepted)

### Issue 4: Invalid Data Values

```
ValueError: could not convert string to float
```

**Solution:** Ensure all numeric columns contain only numbers (no text except in 'label' column)

---

## 🎯 Best Practices

1. **Data Quality**
   - Remove outliers and invalid values
   - Ensure consistent units (same as training data)
   - Balance classes (similar number of samples per crop)

2. **Sample Size**
   - Minimum: 50 samples per crop
   - Recommended: 100+ samples per crop
   - More data = better accuracy

3. **File Format**
   - Use UTF-8 encoding
   - Use comma (`,`) as delimiter
   - Include header row with column names

4. **Column Names**
   - Keep names simple and lowercase
   - No special characters (except pH)
   - Match required names exactly

---

## 📈 After Training

Once training completes:

1. **Model is saved** to specified output path
2. **Accuracy is reported** for all 3 models
3. **Best model is auto-selected**
4. **Classification report** shows per-crop performance

The saved model can be used immediately with:
- `recommender.py`
- `fastapi_app.py`
- `streamlit_app.py`

---

## 💡 Tips for Better Results

### Improve Accuracy:
- Collect more diverse samples
- Balance crop distribution
- Include various soil conditions
- Add seasonal variations

### Feature Engineering:
- Consider adding: season, location, soil type
- Normalize extreme values
- Handle missing data properly

### Model Tuning:
- Adjust hyperparameters in `train_model.py`
- Try different train/test split ratios
- Use cross-validation for small datasets

---

## 🔄 Updating Your Model

To retrain with new data:

```powershell
# Backup old model
Copy-Item "crop_model.pkl" "crop_model_backup.pkl"

# Train with new data
python train_model.py --dataset "new_data.csv"

# Test the new model
python recommender.py
```

---

## 📞 Need Help?

If your dataset has different structure or columns:

1. Check this guide first
2. Ensure CSV format is correct
3. Validate column names match requirements
4. Check data types (numbers for features, text for labels)

---

## 🌾 Example: Complete Workflow

```powershell
# 1. Prepare your dataset
# Create crops.csv with required columns

# 2. Train the model
cd app
python train_model.py --dataset "crops.csv"

# 3. Verify it works
python recommender.py

# 4. Run the web interface
streamlit run streamlit_app.py
```

**That's it! Your custom model is ready to use.**
