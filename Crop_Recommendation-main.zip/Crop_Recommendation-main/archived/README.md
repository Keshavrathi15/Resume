# 📦 Archived Files

This folder contains deprecated or archived files not currently used in the project.

## Files

- **PROJECT_OVERVIEW.py** - Legacy project overview script
- **yield_model_analysis.png** - Yield model performance visualization
- **catboost_info/** - CatBoost training information and logs

## Purpose

These files are preserved for:
- Historical reference
- Potential future use
- Documentation of previous approaches
- Analysis artifacts

## Status

❌ **Not needed for running the application**
- These files are not imported by any active code
- Safe to delete if needed
- Kept for reference only

## Notes

- **catboost_info/** contains detailed logs from CatBoost training
- **yield_model_analysis.png** shows training/validation curves
- **PROJECT_OVERVIEW.py** was used for early project documentation

If you need to clean up space, this folder can be safely removed.
