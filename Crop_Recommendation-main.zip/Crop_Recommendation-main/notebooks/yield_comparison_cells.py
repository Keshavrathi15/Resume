"""
Add Yield Model Comparison to Existing Colab Notebook
"""

# The yield model comparison code to add
yield_comparison_cells = [
    {
        "type": "markdown",
        "content": """## 📊 Step 16.5: Compare Multiple Yield Regression Models

Compare different regression algorithms to find the best yield predictor:
- Random Forest Regressor
- Gradient Boosting Regressor
- XGBoost Regressor  
- CatBoost Regressor
- Decision Tree Regressor
- Ridge Regression
- Linear Regression"""
    },
    {
        "type": "code",
        "content": """from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.svm import SVR
from xgboost import XGBRegressor
from catboost import CatBoostRegressor
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error, mean_absolute_percentage_error

print("\\n🔬 YIELD MODEL COMPARISON - TRAINING MULTIPLE REGRESSORS")
print("="*70)

# Define models to compare
yield_models = {
    'Random Forest': RandomForestRegressor(
        n_estimators=200,
        max_depth=20,
        min_samples_split=5,
        min_samples_leaf=2,
        random_state=42,
        n_jobs=-1
    ),
    'Gradient Boosting': GradientBoostingRegressor(
        n_estimators=200,
        max_depth=10,
        learning_rate=0.1,
        random_state=42
    ),
    'XGBoost': XGBRegressor(
        n_estimators=200,
        max_depth=10,
        learning_rate=0.1,
        random_state=42,
        n_jobs=-1,
        verbosity=0
    ),
    'CatBoost': CatBoostRegressor(
        iterations=200,
        depth=10,
        learning_rate=0.1,
        random_state=42,
        verbose=0
    ),
    'Decision Tree': DecisionTreeRegressor(
        max_depth=20,
        min_samples_split=10,
        min_samples_leaf=5,
        random_state=42
    ),
    'Ridge Regression': Ridge(
        alpha=1.0,
        random_state=42
    ),
    'Linear Regression': LinearRegression()
}

# Train and evaluate all models
yield_results = []

for name, model in yield_models.items():
    print(f"\\n⏳ Training {name}...")
    start_time = time.time()
    
    # Train
    model.fit(X_yield_train, y_yield_train)
    train_time = time.time() - start_time
    
    # Predictions
    y_train_pred = model.predict(X_yield_train)
    y_test_pred = model.predict(X_yield_test)
    
    # Metrics
    train_r2 = r2_score(y_yield_train, y_train_pred)
    test_r2 = r2_score(y_yield_test, y_test_pred)
    test_rmse = np.sqrt(mean_squared_error(y_yield_test, y_test_pred))
    test_mae = mean_absolute_error(y_yield_test, y_test_pred)
    test_mape = mean_absolute_percentage_error(y_yield_test, y_test_pred) * 100
    
    yield_results.append({
        'Model': name,
        'Train R²': train_r2,
        'Test R²': test_r2,
        'RMSE (q/ha)': test_rmse,
        'MAE (q/ha)': test_mae,
        'MAPE (%)': test_mape,
        'Overfitting': train_r2 - test_r2,
        'Training Time (s)': train_time,
        'model_object': model
    })
    
    print(f"   ✅ Test R²: {test_r2:.4f} | RMSE: {test_rmse:.2f} q/ha | Time: {train_time:.1f}s")

print("\\n" + "="*70)
print("📊 YIELD MODEL COMPARISON RESULTS")
print("="*70)"""
    },
    {
        "type": "code",
        "content": """# Create comparison DataFrame
yield_comparison_df = pd.DataFrame(yield_results)
yield_comparison_df = yield_comparison_df.sort_values('Test R²', ascending=False)

# Display results table
print("\\n📋 Performance Ranking (sorted by Test R²):\\n")
display_df = yield_comparison_df[[
    'Model', 'Train R²', 'Test R²', 'RMSE (q/ha)', 
    'MAE (q/ha)', 'MAPE (%)', 'Overfitting', 'Training Time (s)'
]].copy()

for col in ['Train R²', 'Test R²', 'Overfitting']:
    display_df[col] = display_df[col].apply(lambda x: f"{x:.4f}")
for col in ['RMSE (q/ha)', 'MAE (q/ha)', 'Training Time (s)']:
    display_df[col] = display_df[col].apply(lambda x: f"{x:.2f}")
display_df['MAPE (%)'] = display_df['MAPE (%)'].apply(lambda x: f"{x:.2f}%")

print(tabulate(display_df, headers='keys', tablefmt='grid', showindex=False))

# Best model
best_yield_model_name = yield_comparison_df.iloc[0]['Model']
best_yield_model = yield_comparison_df.iloc[0]['model_object']
best_yield_r2 = yield_comparison_df.iloc[0]['Test R²']
best_yield_rmse = yield_comparison_df.iloc[0]['RMSE (q/ha)']

print(f"\\n🏆 BEST YIELD MODEL: {best_yield_model_name}")
print(f"   • R² Score: {best_yield_r2:.4f} ({best_yield_r2*100:.2f}% variance explained)")
print(f"   • RMSE: {best_yield_rmse:.2f} q/ha")
print(f"   • Overfitting: {yield_comparison_df.iloc[0]['Overfitting']:.4f}")"""
    },
    {
        "type": "code",
        "content": """# Visualize model comparison
fig, axes = plt.subplots(2, 2, figsize=(16, 12))

# 1. R² Score comparison
ax1 = axes[0, 0]
models_list = yield_comparison_df['Model'].values
train_r2_list = [float(x) for x in yield_comparison_df['Train R²'].values]
test_r2_list = [float(x) for x in yield_comparison_df['Test R²'].values]

x_pos = np.arange(len(models_list))
width = 0.35

ax1.barh(x_pos - width/2, train_r2_list, width, label='Train R²', color='#4CAF50', alpha=0.8)
ax1.barh(x_pos + width/2, test_r2_list, width, label='Test R²', color='#2196F3', alpha=0.8)
ax1.set_yticks(x_pos)
ax1.set_yticklabels(models_list)
ax1.set_xlabel('R² Score', fontweight='bold')
ax1.set_title('R² Score Comparison (Yield Models)', fontweight='bold', fontsize=12)
ax1.legend()
ax1.grid(axis='x', alpha=0.3)
ax1.axvline(x=0.95, color='red', linestyle='--', alpha=0.5)

# 2. RMSE comparison
ax2 = axes[0, 1]
rmse_list = [float(x) for x in yield_comparison_df['RMSE (q/ha)'].values]
colors_rmse = ['#FF6B6B' if x == min(rmse_list) else '#95A5A6' for x in rmse_list]
ax2.barh(models_list, rmse_list, color=colors_rmse, alpha=0.8)
ax2.set_xlabel('RMSE (q/ha)', fontweight='bold')
ax2.set_title('Root Mean Squared Error (Lower is Better)', fontweight='bold', fontsize=12)
ax2.grid(axis='x', alpha=0.3)
for i, v in enumerate(rmse_list):
    ax2.text(v + 0.5, i, f'{v:.2f}', va='center')

# 3. MAPE comparison
ax3 = axes[1, 0]
mape_list = [float(x) for x in yield_comparison_df['MAPE (%)'].values]
colors_mape = ['#4CAF50' if x == min(mape_list) else '#95A5A6' for x in mape_list]
ax3.barh(models_list, mape_list, color=colors_mape, alpha=0.8)
ax3.set_xlabel('MAPE (%)', fontweight='bold')
ax3.set_title('Mean Absolute Percentage Error (Lower is Better)', fontweight='bold', fontsize=12)
ax3.grid(axis='x', alpha=0.3)
for i, v in enumerate(mape_list):
    ax3.text(v + 0.3, i, f'{v:.1f}%', va='center')

# 4. Training time comparison
ax4 = axes[1, 1]
train_time_list = [float(x) for x in yield_comparison_df['Training Time (s)'].values]
colors_time = ['#FFC107' if x == min(train_time_list) else '#95A5A6' for x in train_time_list]
ax4.barh(models_list, train_time_list, color=colors_time, alpha=0.8)
ax4.set_xlabel('Training Time (seconds)', fontweight='bold')
ax4.set_title('Training Time (Lower is Better)', fontweight='bold', fontsize=12)
ax4.grid(axis='x', alpha=0.3)
for i, v in enumerate(train_time_list):
    ax4.text(v + max(train_time_list)*0.02, i, f'{v:.1f}s', va='center')

plt.tight_layout()
plt.savefig('yield_models_comparison.png', dpi=300, bbox_inches='tight')
print("\\n✅ Saved comparison chart as 'yield_models_comparison.png'")
plt.show()"""
    },
    {
        "type": "code",
        "content": """# Scatter plot: Actual vs Predicted (Best Model)
print(f"\\n📊 Generating Actual vs Predicted plot for {best_yield_model_name}...")

y_best_pred = best_yield_model.predict(X_yield_test)

fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# Scatter plot
ax1 = axes[0]
scatter = ax1.scatter(y_yield_test, y_best_pred, 
                     c=y_best_pred, 
                     cmap='viridis', 
                     alpha=0.6, 
                     s=50,
                     edgecolors='white',
                     linewidth=0.5)

# Perfect prediction line
min_val = min(y_yield_test.min(), y_best_pred.min())
max_val = max(y_yield_test.max(), y_best_pred.max())
ax1.plot([min_val, max_val], [min_val, max_val], 
         'r--', linewidth=2, label='Perfect Prediction', alpha=0.8)

ax1.set_xlabel('Actual Yield (q/ha)', fontsize=12, fontweight='bold')
ax1.set_ylabel('Predicted Yield (q/ha)', fontsize=12, fontweight='bold')
ax1.set_title(f'Actual vs Predicted Yield - {best_yield_model_name}', 
              fontsize=14, fontweight='bold', pad=15)
ax1.legend(fontsize=10)
ax1.grid(True, alpha=0.3)

# Add colorbar
cbar = plt.colorbar(scatter, ax=ax1)
cbar.set_label('Predicted Yield (q/ha)', fontsize=10)

# Add metrics text box
textstr = f'R² = {best_yield_r2:.4f}\\nRMSE = {best_yield_rmse:.2f} q/ha\\nSamples = {len(y_yield_test):,}'
props = dict(boxstyle='round', facecolor='wheat', alpha=0.8)
ax1.text(0.05, 0.95, textstr, transform=ax1.transAxes, fontsize=10,
        verticalalignment='top', bbox=props)

# Residual plot
ax2 = axes[1]
residuals = y_yield_test - y_best_pred
ax2.hist(residuals, bins=30, color='#FF6B6B', alpha=0.7, edgecolors='white', linewidth=1)
ax2.axvline(x=0, color='red', linestyle='--', linewidth=2, alpha=0.8, label='Zero Error')
ax2.set_xlabel('Residual Error (q/ha)', fontsize=12, fontweight='bold')
ax2.set_ylabel('Frequency', fontsize=12, fontweight='bold')
ax2.set_title('Residual Distribution', fontsize=14, fontweight='bold', pad=15)
ax2.legend(fontsize=10)
ax2.grid(True, alpha=0.3, axis='y')

# Add residual statistics
residual_mean = residuals.mean()
residual_std = residuals.std()
textstr2 = f'Mean = {residual_mean:.2f}\\nStd Dev = {residual_std:.2f}'
props2 = dict(boxstyle='round', facecolor='lightblue', alpha=0.8)
ax2.text(0.72, 0.95, textstr2, transform=ax2.transAxes, fontsize=10,
        verticalalignment='top', bbox=props2)

plt.tight_layout()
plt.savefig('yield_actual_vs_predicted.png', dpi=300, bbox_inches='tight')
print("✅ Saved scatter plot as 'yield_actual_vs_predicted.png'")
plt.show()"""
    },
    {
        "type": "code",
        "content": """# Use the best model for final yield predictor
print(f"\\n🎯 Using {best_yield_model_name} as final yield model")
yield_model = best_yield_model"""
    }
]

print("=" * 70)
print("📝 YIELD MODEL COMPARISON CELLS")
print("=" * 70)
print("\n✨ Copy and paste these cells into your Google Colab notebook")
print("   Insert them BEFORE Step 16 (Train Yield Regression Model)")
print("\n" + "=" * 70)

for i, cell in enumerate(yield_comparison_cells, 1):
    print(f"\n### CELL {i} ({cell['type'].upper()}) ###\n")
    print(cell['content'])
    print("\n" + "-" * 70)

print("\n✅ Total cells to add: {}\n".format(len(yield_comparison_cells)))
