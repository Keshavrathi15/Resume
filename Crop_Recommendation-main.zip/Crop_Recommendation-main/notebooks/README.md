# 📓 Jupyter Notebooks

This folder contains Google Colab notebooks for model training and comparison.

## Files

- **crop_model_training_colab.ipynb** - Complete model training pipeline in Google Colab
- **model_comparison_colab.ipynb** - Comparison of different ML models (RandomForest, XGBoost, CatBoost)

## Purpose

These notebooks provide:
- Interactive training environment
- Model comparison and evaluation
- Visualization of training results
- Easy experimentation with hyperparameters

## How to Use

### Option 1: Google Colab (Recommended)
1. Upload the `.ipynb` file to Google Colab
2. Connect to a runtime (GPU recommended for CatBoost)
3. Upload `smartcrop_cleaned.csv` from `../training_scripts/`
4. Run all cells sequentially

### Option 2: Local Jupyter
```bash
pip install jupyter notebook
jupyter notebook
# Open the .ipynb file and run cells
```

## What You'll Get

- Trained model files (.pkl)
- Performance metrics (accuracy, precision, recall, F1)
- Confusion matrices
- Feature importance visualizations
- Cross-validation results

## Notes

- Colab provides free GPU/TPU which speeds up training
- All notebooks are self-contained with explanations
- Results can be downloaded and used in the main app
